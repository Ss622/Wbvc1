# Application Screens & Viva Demonstration Guide (`docs/screenshots/README.md`)

When preparing your printed **BCSP-064 Final Project Report** for IGNOU evaluation, capture browser screenshots of the following 10 live screens after starting XAMPP and logging in with the demonstration accounts:

1. **01_login_screen.png** — `http://localhost/Web_Based_Virtual_Classroom_System/public/index.php?r=login` (Show/Hide Password + Quick-Fill Demo Credentials).
2. **02_admin_dashboard.png** — `index.php?r=admin/dashboard` (Database-driven statistic cards, course table, notices, and activity logs).
3. **03_admin_user_management.png** — `index.php?r=admin/users` (Create/Edit user form, role/status filters, and user table).
4. **04_admin_course_and_enrollment.png** — `index.php?r=admin/courses` and `index.php?r=admin/enrollments`.
5. **05_admin_reports_csv.png** — `index.php?r=admin/reports` (Consolidated Academic Performance Report with CSV export & Print buttons).
6. **06_teacher_dashboard_and_materials.png** — `index.php?r=teacher/dashboard` and `index.php?r=teacher/materials`.
7. **07_teacher_submission_evaluation.png** — `index.php?r=teacher/submissions` (Awarding marks & publishing faculty feedback).
8. **08_teacher_attendance_sheet.png** — `index.php?r=teacher/attendance` (Marking Present/Absent and viewing cumulative attendance %).
9. **09_student_quiz_interface.png** — `index.php?r=student/quizzes/take&quiz_id=3` (Live countdown timer and multiple-choice options).
10. **10_student_results_transcript.png** — `index.php?r=student/results` (Consolidated course results, grades, and published feedback).
