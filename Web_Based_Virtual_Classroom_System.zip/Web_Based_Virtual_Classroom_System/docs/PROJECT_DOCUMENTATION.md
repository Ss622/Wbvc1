# BCSP-064 Academic Project Documentation (`docs/PROJECT_DOCUMENTATION.md`)

---

## TITLE PAGE TEMPLATE

**INDIRA GANDHI NATIONAL OPEN UNIVERSITY (IGNOU)**  
*School of Computer and Information Sciences (SOCIS)*

**PROJECT REPORT ON**  
### **WEB-BASED VIRTUAL CLASSROOM SYSTEM**

Submitted in partial fulfilment of the requirements for the award of the degree of  
**Bachelor of Computer Applications (BCA)**  
**Course Code:** `BCSP-064`

**Submitted By:**  
- **Learner Name:** Sahil Alam  
- **Enrolment No.:** `2200080265`  
- **Regional Centre:** Patna  
- **Study Centre:** `0500`  

**Under the Guidance of:**  
- **Project Guide:** Krishan Dev Mishra  
- **Qualification:** B.Tech  
- **Academic Session:** `2026–2027`

*(Note: Official signed Certificate of Originality and Approved Proposal Proforma should be attached by the learner and Project Guide prior to physical/portal submission.)*

---

## 1. ABSTRACT
The **Web-Based Virtual Classroom System** is a centralized educational web application designed and implemented to streamline online teaching, learning, assessment, and academic record management. The platform provides three distinct role-based interfaces—**Administrator**, **Teacher**, and **Student**—backed by a normalized 18-table **MySQL** relational database. Core modules include secure authentication, user and course management, student enrollment, protected learning material distribution, assignment creation and submission grading, timed online objective quizzes with automated server-side scoring, date-wise attendance tracking, institutional and course notices, and consolidated result reporting with CSV export. Developed following an Incremental Software Development Life Cycle (SDLC) using **HTML5, CSS3, JavaScript ES6+, PHP 8.2 (MVC), and MySQL (PDO)**, the system eliminates fragmented record-keeping for colleges, study centres, and coaching institutes.

---

## 2. INTRODUCTION & PROBLEM STATEMENT

### 2.1 Introduction
Modern educational institutions and open-university study centres coordinate numerous academic workflows across courses, faculty counsellors, and learners. While individual tools exist for file sharing or messaging, academic integrity requires connecting every learning resource, assignment, quiz attempt, and attendance entry to a central course and student record.

### 2.2 Problem Statement
In many small colleges and study centres, academic operations suffer from six core limitations:
1. **Scattered Learning Materials:** Study notes and syllabi distributed over messaging groups are difficult to organize course-wise.
2. **Disconnected Assignment Workflows:** Collecting submissions via email or paper and recording marks in separate spreadsheets leads to tracking errors.
3. **Manual Attendance Calculation:** Paper registers provide students with no real-time visibility into their attendance percentage.
4. **Repetitive Quiz Grading:** Manually grading objective multiple-choice tests consumes valuable faculty time.
5. **Delayed Result Consolidation:** Combining assignment marks, quiz scores, and attendance into student progress reports requires repetitive manual calculation.
6. **Lack of Role-Based Data Isolation:** Shared spreadsheets risk exposing private student evaluations.

---

## 3. AIM, OBJECTIVES, SCOPE & STAKEHOLDERS

### 3.1 Aim
To design, develop, test, and document a secure, centralized **Web-Based Virtual Classroom System** that manages essential teaching, learning, and assessment workflows through role-based access control and a normalized relational database.

### 3.2 Objectives
- Implement secure session authentication (`password_hash()` / `password_verify()`) and strict server-side Role-Based Access Control (RBAC).
- Enable Administrators to manage users, courses, teacher assignments, student enrollments, notices, and institutional reports.
- Enable Teachers to upload learning materials, create and evaluate assignments, conduct timed objective quizzes, and record attendance for their assigned courses.
- Enable Students to access enrolled course materials, submit assignments, attempt online quizzes with instant automated scoring, and view published results and attendance summaries.

### 3.3 Scope & Out-of-Scope Boundaries
- **In Scope:** Authentication, RBAC, User Management, Course & Enrollment Management, Protected Learning Materials, Assignments & Evaluations, Timed Objective Quizzes & Question Bank, Attendance Management, Notices, Consolidated Results, and CSV/Printable Reports.
- **Outside Initial Prototype Scope:** Large-scale built-in live video streaming servers, biometric attendance hardware, online fee payment gateways, AI proctoring, and multi-region cloud clusters.

### 3.4 Stakeholders
| Stakeholder | Primary Responsibilities & Interests |
| :--- | :--- |
| **Administrator** | Institutional governance, user lifecycle, course catalog, enrollments, notices, audit logs, and reports. |
| **Teacher** | Course delivery, study material uploads, assignment evaluation, quiz authoring, attendance, and student progress. |
| **Student** | Accessing enrolled courses, downloading notes, submitting assignments, taking quizzes, and tracking attendance/results. |

---

## 4. FEASIBILITY STUDY
- **Technical Feasibility:** Built on industry-standard open-source technologies (Apache, PHP 8.2, MySQL/MariaDB, HTML5/CSS3/JS) that run reliably on any standard personal computer via XAMPP.
- **Economic Feasibility:** Zero licensing cost; uses free open-source runtime and development tools (XAMPP, VS Code, Git).
- **Operational Feasibility:** Intuitive role-specific sidebars, clear status badges, confirmation dialogs, and one-click CSV/Print reports make operation straightforward for staff and learners.
- **Schedule Feasibility:** Delivered across 8 structured SDLC phases (Requirements, Database/Architecture, UI/UX, Backend Modules, Integration, Testing, Documentation, Packaging).

---

## 5. REQUIREMENTS ANALYSIS

### 5.1 Functional Requirements
| ID | Requirement | Implemented Module |
| :--- | :--- | :--- |
| **FR-01** | Verify credentials against MySQL and establish secure PHP sessions | `AuthController`, `Session`, `UserModel` |
| **FR-02** | Restrict routes and data access by role (`ADMIN`, `TEACHER`, `STUDENT`) | `RoleMiddleware`, Controller ownership guards |
| **FR-03** | Create, edit, search, filter, activate/deactivate, and reset user accounts | `AdminController::users`, `UserModel` |
| **FR-04** | Create, edit, publish, archive courses and assign faculty teachers | `AdminController::courses`, `CourseModel` |
| **FR-05** | Enroll students into courses and prevent duplicate enrollments | `AdminController::enrollments`, `EnrollmentModel` |
| **FR-06** | Upload validated learning materials and stream protected downloads | `TeacherController::materials`, `FileUpload`, `DownloadController` |
| **FR-07** | Create assignments, accept student submissions, and evaluate/publish marks | `AssignmentModel`, `SubmissionModel` |
| **FR-08** | Author MCQ quizzes/questions, enforce timers/attempt limits, and score server-side | `QuizModel`, `QuestionModel`, `QuizScoringService` |
| **FR-09** | Record date-wise attendance and compute course-wise attendance percentages | `AttendanceModel` |
| **FR-10** | Publish institution-wide, role-based, and course-specific announcements | `NoticeModel` |
| **FR-11** | Consolidate and display published assessment results and grades | `ResultCalculationService`, `ResultModel` |
| **FR-12** | Generate printer-friendly and CSV-exportable academic reports | `AdminController::reports`, `CsvExporter` |

### 5.2 Non-Functional Requirements
- **Security:** Bcrypt password hashing, PDO prepared statements, CSRF tokens, XSS escaping, MIME-validated uploads, and non-public file storage.
- **Reliability & Integrity:** Foreign key constraints, composite unique indexes, and database transactions (`BEGIN` / `COMMIT` / `ROLLBACK`) for quiz scoring and batch attendance.
- **Usability & Responsiveness:** Responsive CSS Grid/Flexbox layout supporting desktop, tablet, and mobile viewports plus `@media print` report formatting.

---

## 6. SYSTEM ARCHITECTURE, DFD & ER DESIGN

*(Full editable Mermaid source files are located in `docs/architecture/01_three_tier_architecture.mmd` through `11_database_relationship_overview.mmd`.)*

### 6.1 Three-Tier Architecture
1. **Presentation Tier:** Responsive HTML5, CSS3, and ES6 JavaScript views rendered per role.
2. **Application Tier:** Front-Controller (`public/index.php`), Router (`routes/web.php`), Security Middleware (`AuthMiddleware`, `RoleMiddleware`, `CsrfMiddleware`), Controllers, Domain Services (`QuizScoringService`, `ResultCalculationService`), and PDO Models.
3. **Data & Storage Tier:** Normalized MySQL database (`virtual_classroom_db`) and protected file storage (`storage/uploads/`).

### 6.2 Context-Level DFD (Level 0) & Level 1 DFD
- **Level 0:** Administrator, Teacher, and Student interact with the central `0.0 Web-Based Virtual Classroom System`.
- **Level 1:** Decomposes into 8 internal processes (`P1 Authentication`, `P2 User/Course/Enrollment`, `P3 Materials`, `P4 Assignments & Submissions`, `P5 Quizzes & Scoring`, `P6 Attendance`, `P7 Notices`, `P8 Results & Reporting`) connected to relational data stores `D1–D8`.

---

## 7. DATABASE DESIGN & DATA DICTIONARY (`virtual_classroom_db`)

The database is normalized to **Third Normal Form (3NF)** across **18 tables**:

| # | Table Name | Primary Key | Foreign Keys & Key Constraints | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| 1 | `roles` | `role_id` | `UNIQUE(role_name)`, `UNIQUE(role_slug)` | Role definitions (`ADMIN`, `TEACHER`, `STUDENT`) |
| 2 | `users` | `user_id` | `FK(role_id)`, `UNIQUE(email)`, `UNIQUE(enrollment_no)` | User accounts and bcrypt password hashes |
| 3 | `courses` | `course_id` | `FK(teacher_id)`, `UNIQUE(course_code)` | Academic courses and assigned teacher |
| 4 | `enrollments` | `enrollment_id` | `FK(student_id)`, `FK(course_id)`, `UNIQUE(student_id, course_id)` | Student-course enrollment junction |
| 5 | `materials` | `material_id` | `FK(course_id)`, `FK(uploaded_by)` | Course study material metadata and storage path |
| 6 | `assignments` | `assignment_id` | `FK(course_id)`, `FK(created_by)`, `CHECK(max_marks > 0)` | Course assignments and due dates |
| 7 | `submissions` | `submission_id` | `FK(assignment_id)`, `FK(student_id)`, `UNIQUE(assignment_id, student_id)` | Student submissions, marks, and feedback |
| 8 | `quizzes` | `quiz_id` | `FK(course_id)`, `FK(created_by)` | Online quiz configurations and attempt limits |
| 9 | `questions` | `question_id` | `FK(quiz_id)`, `FK(course_id)` | Multiple-choice questions and correct option |
| 10 | `question_options` | `option_id` | `FK(question_id)`, `UNIQUE(question_id, option_label)` | Options `A`, `B`, `C`, `D` per question |
| 11 | `attempts` | `attempt_id` | `FK(quiz_id)`, `FK(student_id)`, `UNIQUE(quiz_id, student_id, attempt_number)` | Student quiz attempts and server-calculated scores |
| 12 | `attempt_answers` | `attempt_answer_id` | `FK(attempt_id)`, `FK(question_id)`, `UNIQUE(attempt_id, question_id)` | Student answer choices per question |
| 13 | `attendance` | `attendance_id` | `FK(course_id)`, `FK(student_id)`, `UNIQUE(course_id, student_id, class_date)` | Date-wise student attendance |
| 14 | `notices` | `notice_id` | `FK(author_id)`, `FK(course_id)` | Institution-wide and course announcements |
| 15 | `results` | `result_id` | `FK(student_id)`, `FK(course_id)`, `UNIQUE(student_id, course_id)` | Consolidated course-wise academic results |
| 16 | `activity_logs` | `log_id` | `FK(user_id)` | System audit trail |
| 17 | `settings` | `setting_id` | `UNIQUE(setting_key)` | Institutional & grading configuration |
| 18 | `login_attempts` | `id` | Indexed by `(email, attempted_at)` and `(ip_address, attempted_at)` | Brute-force login rate limiting |

---

## 8. MODULE DESCRIPTIONS & ALGORITHMIC LOGIC

1. **Attendance Percentage Formula (`AttendanceModel` & `ResultCalculationService`):**
   $$\text{Attendance Percentage} = \left( \frac{\text{Number of Present Classes}}{\text{Total Recorded Classes}} \right) \times 100$$
2. **Overall Course Assessment Percentage (`ResultCalculationService`):**
   $$\text{Overall Percentage} = \left( \frac{\text{Published Assignment Marks} + \text{Best Quiz Marks}}{\text{Assignment Max Marks} + \text{Quiz Max Marks}} \right) \times 100$$
3. **IGNOU Grade Mapping:**
   - `>= 80%`: **A+** (Distinction)
   - `70% – 79.99%`: **A** (First Division)
   - `60% – 69.99%`: **B** (Second Division)
   - `50% – 59.99%`: **C** (Pass)
   - `40% – 49.99%`: **D** (Pass — Minimum Qualifying Grade)
   - `< 40%`: **F** (Needs Improvement)

---

## 9. TESTING STRATEGY & SUMMARY OF RESULTS
Testing was performed across Unit, Integration (Workflows A–F), Database Constraint, and Security levels. All **20 executed test suites (`TC-01` to `TC-20`) passed**. Full tabular test logs are documented in [`docs/TEST_REPORT.md`](TEST_REPORT.md).

---

## 10. LIMITATIONS & FUTURE ENHANCEMENTS

### 10.1 Current Limitations
- Does not include built-in WebRTC video conferencing or live streaming servers.
- Objective quizzes currently evaluate single-correct multiple-choice questions (`A/B/C/D`); descriptive essay questions are handled via the Assignments module.
- Email/SMS push alerts require external SMTP/SMS gateway configuration in production.

### 10.2 Future Enhancements
- Integration with Google Meet / Zoom APIs for live scheduled virtual classes.
- Automated PDF certificate and grade-card generation with QR verification.
- Email and WhatsApp/SMS deadline notifications.
- Mobile companion application using REST APIs.

---

## 11. CONCLUSION & REFERENCES

### 11.1 Conclusion
The **Web-Based Virtual Classroom System (`BCSP-064`)** successfully fulfills the objectives of the IGNOU BCA project proposal by delivering a secure, modular, database-driven academic platform. It demonstrates practical application of software engineering, relational database normalization, object-oriented PHP programming, and defense-in-depth web security.

### 11.2 References
1. Indira Gandhi National Open University (IGNOU), *BCSP-064 Project Guidelines*, School of Computer and Information Sciences (SOCIS).
2. Pressman, R. S., & Maxim, B. R., *Software Engineering: A Practitioner's Approach*, McGraw-Hill Education.
3. Sommerville, I., *Software Engineering*, Pearson Education.
4. Elmasri, R., & Navathe, S. B., *Fundamentals of Database Systems*, Pearson Education.
5. PHP Official Documentation — *PDO Prepared Statements, Password Hashing & Session Security* (`https://www.php.net/manual/en/`).
