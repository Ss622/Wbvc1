# Comprehensive User Manual (`docs/USER_GUIDE.md`)

This manual provides step-by-step operating instructions for all three user roles in the **Web-Based Virtual Classroom System (BCSP-064)**.

---

## Part 1: Administrator User Guide

### 1.1 Signing In & Dashboard Overview
1. Open the login page and sign in with `admin@ignou-vc.edu.in` / `Admin@123`.
2. The **Administrator Dashboard** displays live database counts for Total Students, Total Teachers, Administrators, Published Courses, Active Enrollments, Assignments, Quizzes, Recent Institutional Notices, and Recent System Activity Logs.

### 1.2 Managing Users, Teachers & Students
1. Click **User Management** (or **Student Management** / **Teacher Management**) in the left navy sidebar.
2. **To Create a User:** Fill in the left-hand form (*Account Role*, *Enrolment/Staff ID*, *Full Name*, *Email Address*, *Phone*, *Qualification*, *Department*, and *Initial Password*) and click **Create User Account**.
3. **To Search & Filter:** Use the filter bar above the user table to search by name/email/enrolment number or filter by Role (`ADMIN`, `TEACHER`, `STUDENT`) and Status (`Active`, `Inactive`).
4. **To Edit, Reset Password, or Deactivate:** Click **Edit** to modify user details or reset their password, or click **Deactivate / Activate** to toggle account access.

### 1.3 Managing Courses & Assigning Faculty
1. Click **Course Management** in the sidebar.
2. Enter the *Course Code* (e.g., `BCS-051`), *Credits*, *Course Title*, *Semester*, *Status* (`Published`, `Draft`, `Archived`), select the *Assigned Faculty Teacher*, enter the *Syllabus Description*, and click **Save & Publish Course**.

### 1.4 Enrolling Students in Courses
1. Click **Enrollment Management** in the sidebar.
2. Select an active student and a course from the dropdowns and click **Enroll Student**.
3. Duplicate enrollments for the same student and course are automatically blocked by both backend validation and the `UNIQUE(student_id, course_id)` database constraint.

### 1.5 Publishing Notices & Exporting Reports
1. Under **Notices**, create announcements targeted at *All Users*, *Students Only*, *Teachers Only*, or a *Specific Course* with *Normal*, *Important*, or *Urgent* priority.
2. Under **Reports & CSV**, choose from 8 report types (*Academic Performance*, *Student Directory*, *Teacher Directory*, *Course Catalogue*, *Enrollment Registry*, *Attendance Summary*, *Assignment Status*, or *Quiz Score Report*) and click **Download CSV** or **Print Report**.

---

## Part 2: Teacher (Faculty Counsellor) User Guide

### 2.1 Viewing Assigned Courses & Enrolled Rosters
1. Sign in with `krishan.mishra@ignou-vc.edu.in` / `Teacher@123`.
2. Navigate to **My Courses** and click **View Roster** on any assigned course to inspect enrolled students.

### 2.2 Uploading Learning Materials
1. Open **Course Materials** in the sidebar.
2. Select one of your assigned courses, enter a *Resource Title*, select a *Category* (*Lecture Notes*, *Syllabus*, *Lab Manual*, etc.), attach a permitted file (`PDF`, `DOCX`, `PPTX`, `XLSX`, `TXT`, `JPG`, `PNG` up to 10 MB), and click **Upload & Publish Material**.

### 2.3 Creating Assignments & Evaluating Student Submissions
1. Open **Assignments** and create a new assignment with *Course*, *Title*, *Maximum Marks*, *Issue Date*, *Due Date*, and optional reference document.
2. Open **Student Submissions** to view submitted work and download student attachments.
3. Enter awarded marks (validated between `0` and `max_marks`), type constructive feedback, choose **Publish Marks** (or **Save Draft Evaluation**), and click **Save**.
   - Publishing marks automatically updates the student's consolidated course record in the `results` table.

### 2.4 Managing Online Quizzes & Question Bank
1. Open **Quiz Management** to create an objective quiz with *Duration (minutes)*, *Allowed Attempts*, and *Start/End Date-Time*.
2. Click **+ Questions** (or open **Question Bank**) to add single-correct multiple-choice questions with Options `A`, `B`, `C`, `D`, marks, and an optional answer explanation.

### 2.5 Recording Date-Wise Attendance
1. Open **Attendance**, select an assigned course and class date, and click **Load Class Sheet**.
2. Mark each enrolled student **Present** or **Absent** with optional remarks and click **Save Attendance Records**.

---

## Part 3: Student (Learner) User Guide

### 3.1 Accessing Enrolled Courses & Downloading Study Materials
1. Sign in with `sahil.alam@ignou-vc.edu.in` (or Enrolment No. `2200080265`) and password `Student@123`.
2. Open **My Courses** or **Learning Materials** to browse and download authorized study files for your enrolled courses.

### 3.2 Submitting Course Assignments
1. Open **Assignments** to view open assignments, deadlines, maximum marks, and reference attachments.
2. Type your written response and/or attach your solution file and click **Submit Assignment**.
3. Track evaluation status, published marks, and teacher feedback under **My Submissions**.

### 3.3 Attempting Online Objective Quizzes
1. Open **Online Quizzes** and click **Start Quiz** on an available quiz.
2. Select answers for each multiple-choice question before the sticky countdown timer reaches `00:00` and click **Submit Quiz & View Score**.
3. View your instant server-calculated score and question-by-question answer key under **Quiz Results**.

### 3.4 Checking Attendance & Academic Results
1. Open **Attendance** to view course-wise attendance percentages and date-by-date class history.
2. Open **My Results** to view your consolidated course-wise marks, overall percentages, IGNOU grades, and click **Print Grade Card** for a printer-friendly transcript.
