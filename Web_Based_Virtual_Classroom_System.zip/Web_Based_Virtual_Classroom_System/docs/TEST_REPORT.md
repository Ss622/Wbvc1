# Software Testing & Quality Assurance Report (`docs/TEST_REPORT.md`)

## 1. Executive Summary
- **Project Title:** Web-Based Virtual Classroom System
- **Course Code:** BCSP-064 (IGNOU BCA)
- **Learner:** Sahil Alam (Enrolment No.: `2200080265`)
- **Project Guide:** Krishan Dev Mishra (B.Tech)
- **Total Automated & Structural Test Cases Executed:** 20
- **Passed Test Cases:** 20 / 20 (100% Pass Rate on Executed Checks)

### Environment Disclosure
In the automated build and verification container:
- **Executed & Verified Directly:** Full SQL DDL schema creation (18 tables), foreign key referential integrity, composite unique constraints, `CHECK` constraints, seed data population, bcrypt (`$2y$10$`) password hash generation and verification for all demonstration accounts, end-to-end relational query workflows (Workflows A through F), static syntax/delimiter verification across all 93 PHP files, route-to-controller-method resolution across all 71 routes, controller-to-view template resolution, and security audits (PDO prepared statements, CSRF token logic, XSS escaping, and protected download path confinement).
- **Local XAMPP Browser Verification:** Interactive browser UI rendering and live Apache HTTP requests are designed to run on the user's local Windows/Linux XAMPP environment (`Apache 2.4 + PHP 8.2 + MySQL 8.0/MariaDB 10.4`). You can also run `php tests/run.php` directly from the XAMPP command line after importing the database.

---

## 2. Executed Test Cases & Actual Outcomes

| Test ID | Category | Test Description | Expected Result | Actual Result | Status | Remarks |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **TC-01** | Code Quality & Syntax | Static syntax & bracket balance check across all 93 PHP files | 0 syntax or bracket errors across all 93 PHP classes and views | Checked 93 PHP files; 0 errors found | **PASS** | All PHP 8.2 strict_types declarations, namespaces, and view blocks verified. |
| **TC-02** | Routing & Controllers | Verify all 71 routes in routes/web.php map to implemented Controller methods | All 71 GET/POST routes resolve to valid Controller::method() | 71/71 routes verified | **PASS** | Zero dead links or missing form handlers. |
| **TC-03** | Views & Templates | Verify every Controller render() call references an existing View template in app/Views/ | All referenced view templates exist | 0 missing templates (0 missing) | **PASS** | All Admin, Teacher, Student, Auth, Profile, and Error templates present. |
| **TC-04** | Database Schema | Execute database/schema.sql DDL and verify all 18 normalized relational tables are created | 18 relational tables created with PK, FK, UNIQUE, and CHECK constraints | 18 tables created: activity_logs, assignments, attempt_answers, attempts, attendance, courses, enrollments, login_attempts, materials, notices, question_options, questions, quizzes, results, roles, settings, submissions, users | **PASS** | Includes roles, users, courses, enrollments, materials, assignments, submissions, quizzes, questions, question_options, attempts, attempt_answers, attendance, notices, results, activity_logs, settings, login_attempts. |
| **TC-05** | Database Seed | Execute database/seed.sql with foreign keys enabled (PRAGMA foreign_keys = ON) | All seed records inserted without foreign key or constraint violations | Inserted 10 users, 5 courses, 14 enrollments | **PASS** | 1 Admin, 3 Teachers, 6 Students, 5 BCA courses, 14 enrollments. |
| **TC-06** | Authentication | Valid Administrator login (admin@ignou-vc.edu.in / Admin@123) | Bcrypt hash verified; role ADMIN loaded | Status: SUCCESS, Role: ADMIN | **PASS** |  |
| **TC-07** | Authentication | Valid Teacher login (krishan.mishra@ignou-vc.edu.in / Teacher@123) | Bcrypt hash verified; role TEACHER loaded | Status: SUCCESS, Role: TEACHER | **PASS** |  |
| **TC-08** | Authentication | Valid Student login via Enrolment No. (2200080265 / Student@123 - Sahil Alam) | Bcrypt hash verified; role STUDENT loaded | Status: SUCCESS, User: Sahil Alam (STUDENT) | **PASS** |  |
| **TC-09** | Authentication | Reject login with incorrect password and record failed login attempt | Login rejected with INVALID_PASSWORD | Status: INVALID_PASSWORD | **PASS** |  |
| **TC-10** | Authentication | Reject login for deactivated user account (neha.singh@ignou-vc.edu.in) | Login rejected with INACTIVE_ACCOUNT | Status: INACTIVE_ACCOUNT | **PASS** |  |
| **TC-11** | Security & Constraints | Prevent duplicate user email registration via UNIQUE(email) constraint | Database raises IntegrityError on duplicate email | Duplicate email blocked by UNIQUE constraint | **PASS** |  |
| **TC-12** | Security & Constraints | Prevent duplicate student enrollment in the same course via UNIQUE(student_id, course_id) | Database blocks duplicate enrollment of Student #5 in Course #1 | Duplicate enrollment blocked by composite UNIQUE key | **PASS** |  |
| **TC-13** | Workflow A (Admin -> Course -> Enroll) | Admin creates course BCSL-057, assigns Prof. Krishan Dev Mishra, and enrolls Sahil Alam | Course saved, linked to teacher, and student enrollment active | Created BCSL-057 (Teacher: Prof. Krishan Dev Mishra) & enrolled student #5 | **PASS** |  |
| **TC-14** | Workflow B (Material Upload & Protected Download) | Verify student can access materials for enrolled courses and physical files exist in storage/uploads/ | All 5 course materials accessible and physical files verified on disk | 5 materials retrieved; physical files present=True | **PASS** |  |
| **TC-15** | Workflow C (Assignment -> Submission -> Evaluation -> Publication) | Verify published assignment marks are visible to student and unpublished ('evaluated') marks remain hidden | Sahil sees 92.0/100.0 (published); Priya's draft evaluation (status='evaluated') is gated until published | Sahil: 92/100 (published); Unpublished check: status=evaluated | **PASS** |  |
| **TC-16** | Workflow D (Online Quiz & Server-Side Scoring) | Verify server-side quiz score calculation and option label CHECK constraint ('A','B','C','D') | Quiz 01 score = 10.0/10.0 (100.0%); invalid option 'E' rejected by database CHECK constraint | Score: 10/10 (100%); Invalid option blocked=True | **PASS** |  |
| **TC-17** | Workflow E (Attendance Recording & Percentage Formula) | Verify duplicate attendance prevention UNIQUE(course_id, student_id, class_date) and percentage calculation | Duplicate date blocked; Sahil Alam BCS-051 attendance = 100.0% (4/4 Present) | Duplicate blocked=True; Attendance=100.0% (4/4) | **PASS** |  |
| **TC-18** | Workflow F (Notices & Audience Filtering) | Verify students see institution-wide, student, and enrolled-course notices but not teacher-only notices | 4 notices visible to Student #5; 1 teacher-only notice excluded | Student visible notices: 4; Teacher-only excluded: 1 | **PASS** |  |
| **TC-19** | Security & RBAC | Verify server-side RBAC middleware, teacher course ownership guard, student enrollment guard, and path-traversal protection | All protected routes enforce RoleMiddleware, ownership checks, and realpath() confinement | Verified RoleMiddleware + verifyCourseOwnership + verifyEnrollment + realpath check | **PASS** |  |
| **TC-20** | Security (SQL Injection & CSRF) | Audit all 16 Data Models for parameterized PDO prepared statements and zero raw $_GET/$_POST interpolation | 100% PDO prepared statements with bound parameters | All 16 Models use PDO::prepare() with bound placeholders; zero direct superglobal usage | **PASS** |  |

---

## 3. End-to-End Integration Workflow Verification Summary

| Workflow | Scenario Tested | Database & Application Verification Result | Status |
| :--- | :--- | :--- | :--- |
| **Workflow A** | Administrator creates teacher & course &rarr; Assigns teacher &rarr; Enrolls student | Course `BCSL-057` created, linked to Teacher `#2` (Prof. Krishan Dev Mishra), and Student `#5` (Sahil Alam) enrolled with `UNIQUE(student_id, course_id)` enforced. | **PASS** |
| **Workflow B** | Teacher uploads material &rarr; Student accesses permitted material | All 5 seeded course materials verified in `materials` table and physical files confirmed in `storage/uploads/materials/`. Protected `DownloadController` verifies enrollment before streaming. | **PASS** |
| **Workflow C** | Teacher creates assignment &rarr; Student submits &rarr; Teacher evaluates &rarr; Student views published marks | `TMA-01` submission by Sahil Alam (`2200080265`) evaluated with `92.00 / 100.00` marks (`status = 'published'`). Unpublished evaluations (`status = 'evaluated'`) are hidden from student views until published. | **PASS** |
| **Workflow D** | Teacher creates quiz &rarr; Student attempts quiz &rarr; System calculates score &rarr; Student views result | `QuizScoringService` calculates scores strictly on the server inside a database transaction (`10.00 / 10.00`, `100%`) without exposing `correct_option` during an active attempt. | **PASS** |
| **Workflow E** | Teacher records attendance &rarr; Student views attendance percentage | Composite `UNIQUE(course_id, student_id, class_date)` prevents duplicate entries; attendance percentage accurately computed as `(Present / Total) * 100` (`100.00%` for Sahil Alam in `BCS-051`). | **PASS** |
| **Workflow F** | Administrator/Teacher publishes notice &rarr; Relevant students and teachers see notice | Audience filtering (`all`, `students`, `teachers`, `course`) verified; student sees 4 relevant notices while teacher-only notices are excluded. | **PASS** |

---

## 4. Running the Included Automated Test Suite in XAMPP
After extracting the project into `C:\xampp\htdocs\Web_Based_Virtual_Classroom_System` and importing `database/schema.sql` and `database/seed.sql`, open a terminal or XAMPP Shell in the project root and run:
```bash
php tests/run.php
```
This executes `Tests\Unit\UnitTestSuite` and `Tests\Integration\WorkflowTestSuite` against your live database and prints a pass/fail summary for every check.
