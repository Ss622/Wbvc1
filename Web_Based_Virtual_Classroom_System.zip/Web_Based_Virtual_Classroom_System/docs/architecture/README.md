# System Architecture & Technical Diagrams (`docs/architecture/`)

This directory contains all 11 technical diagrams in editable Mermaid (`.mmd`) format for the **Web-Based Virtual Classroom System (BCSP-064)**.

## 01 Three Tier Architecture (`01_three_tier_architecture.mmd`)

```mermaid
%% 1. Three-Tier System Architecture Diagram
%% Project: Web-Based Virtual Classroom System (BCSP-064)
flowchart TB
    subgraph Tier1["Presentation Tier (Client Browser)"]
        UI_Admin["Administrator Panel UI<br/>(HTML5, CSS3, Bootstrap 5, ES6 JS)"]
        UI_Teacher["Teacher Panel UI<br/>(Course, Material, Quiz & Attendance UI)"]
        UI_Student["Student Panel UI<br/>(Learning, Submission, Quiz Timer & Results UI)"]
    end

    subgraph Tier2["Application Tier (Apache + PHP 8.2 MVC Engine)"]
        Router["Front Controller & Router<br/>(public/index.php, routes/web.php)"]
        MW["Security Middleware<br/>(Auth, RBAC Role Guard, CSRF Guard, Session Timeout)"]
        Controllers["Controllers<br/>(Auth, Admin, Teacher, Student, Profile, Download)"]
        Services["Domain Services & Validators<br/>(QuizScoringService, ResultCalculationService, FileUpload)"]
        Models["Data Access Models (PDO Prepared Statements)<br/>(User, Course, Enrollment, Material, Assignment, Quiz, Attendance, Notice, Result)"]
    end

    subgraph Tier3["Data & Storage Tier (MySQL 8.0 / MariaDB + Protected Filesystem)"]
        DB[("MySQL Relational Database<br/>(virtual_classroom_db - 18 Normalized Tables)")]
        FS[("Protected File Storage<br/>(storage/uploads/ outside public web root)")]
    end

    UI_Admin -->|HTTPS / HTTP Requests| Router
    UI_Teacher -->|HTTPS / HTTP Requests| Router
    UI_Student -->|HTTPS / HTTP Requests| Router
    Router --> MW
    MW --> Controllers
    Controllers --> Services
    Services --> Models
    Controllers --> Models
    Models -->|PDO Parameterized SQL| DB
    Services -->|Validated Stream I/O| FS
```

## 02 System Context Dfd Level0 (`02_system_context_dfd_level0.mmd`)

```mermaid
%% 2. System Context Diagram (DFD Level 0)
%% Project: Web-Based Virtual Classroom System (BCSP-064)
flowchart LR
    Admin["ADMINISTRATOR<br/>(External Entity)"]
    Teacher["TEACHER<br/>(External Entity)"]
    Student["STUDENT<br/>(External Entity)"]

    System(("0.0<br/>WEB-BASED VIRTUAL<br/>CLASSROOM SYSTEM<br/>(BCSP-064)"))

    Admin -->|"User Accounts, Courses, Teacher Assignments,<br/>Student Enrollments, System Notices"| System
    System -->|"Institutional Dashboards, Activity Logs,<br/>Academic & Attendance Reports (CSV/Print)"| Admin

    Teacher -->|"Learning Materials, Assignments, Evaluations,<br/>Quizzes, Questions, Attendance, Course Notices"| System
    System -->|"Assigned Courses, Student Submissions,<br/>Quiz Attempt Scores, Performance Summaries"| Teacher

    Student -->|"Login Credentials, Assignment Submissions,<br/>Quiz Answers, Profile Updates"| System
    System -->|"Enrolled Courses, Protected Study Materials,<br/>Published Marks, Quiz Results, Attendance %"| Student
```

## 03 Dfd Level1 (`03_dfd_level1.mmd`)

```mermaid
%% 3. Data Flow Diagram — Level 1 (Major Internal Processes)
%% Project: Web-Based Virtual Classroom System (BCSP-064)
flowchart TB
    Admin["Administrator"]
    Teacher["Teacher"]
    Student["Student"]

    P1(["P1: Authentication &<br/>Session Security"])
    P2(["P2: User, Course &<br/>Enrollment Management"])
    P3(["P3: Learning Material<br/>Management"])
    P4(["P4: Assignment &<br/>Submission Evaluation"])
    P5(["P5: Online Quiz &<br/>Automated Scoring"])
    P6(["P6: Attendance<br/>Management"])
    P7(["P7: Notice &<br/>Announcement Publishing"])
    P8(["P8: Consolidated Results &<br/>Academic Reporting"])

    D1[("D1: users & roles")]
    D2[("D2: courses & enrollments")]
    D3[("D3: materials")]
    D4[("D4: assignments & submissions")]
    D5[("D5: quizzes, questions & attempts")]
    D6[("D6: attendance")]
    D7[("D7: notices")]
    D8[("D8: results & activity_logs")]

    Admin -->|Credentials| P1
    Teacher -->|Credentials| P1
    Student -->|Credentials| P1
    P1 <--> D1

    Admin -->|Manage Users/Courses/Enrollments| P2
    P2 <--> D1
    P2 <--> D2

    Teacher -->|Upload Resource Metadata & File| P3
    P3 <--> D3
    D3 -->|Authorized Download| Student

    Teacher -->|Create Assignment & Evaluate| P4
    Student -->|Submit Work| P4
    P4 <--> D4

    Teacher -->|Create Quiz & Questions| P5
    Student -->|Submit Quiz Answers| P5
    P5 <--> D5

    Teacher -->|Mark Date-Wise Presence| P6
    P6 <--> D6
    D6 -->|Attendance Summary| Student

    Admin -->|Publish Notice| P7
    Teacher -->|Course Notice| P7
    P7 <--> D7
    D7 -->|Announcements| Student

    D4 --> P8
    D5 --> P8
    D6 --> P8
    P8 <--> D8
    P8 -->|Reports & Transcripts| Admin
    P8 -->|Course Performance| Teacher
    P8 -->|Published Results| Student
```

## 04 Entity Relationship Diagram (`04_entity_relationship_diagram.mmd`)

```mermaid
%% 4. Entity Relationship Diagram (ERD)
%% Project: Web-Based Virtual Classroom System (BCSP-064)
erDiagram
    ROLES ||--o{ USERS : "assigns"
    USERS ||--o{ COURSES : "teaches (teacher_id)"
    USERS ||--o{ ENROLLMENTS : "enrolls in (student_id)"
    COURSES ||--o{ ENROLLMENTS : "contains"
    COURSES ||--o{ MATERIALS : "has"
    USERS ||--o{ MATERIALS : "uploads"
    COURSES ||--o{ ASSIGNMENTS : "includes"
    ASSIGNMENTS ||--o{ SUBMISSIONS : "receives"
    USERS ||--o{ SUBMISSIONS : "submits (student_id)"
    COURSES ||--o{ QUIZZES : "offers"
    QUIZZES ||--o{ QUESTIONS : "contains"
    QUESTIONS ||--o{ QUESTION_OPTIONS : "has options"
    QUIZZES ||--o{ ATTEMPTS : "attempted via"
    USERS ||--o{ ATTEMPTS : "takes (student_id)"
    ATTEMPTS ||--o{ ATTEMPT_ANSWERS : "records"
    QUESTIONS ||--o{ ATTEMPT_ANSWERS : "answered in"
    COURSES ||--o{ ATTENDANCE : "tracks"
    USERS ||--o{ ATTENDANCE : "marked for (student_id)"
    COURSES ||--o{ NOTICES : "announces"
    USERS ||--o{ NOTICES : "authors"
    COURSES ||--o{ RESULTS : "summarizes"
    USERS ||--o{ RESULTS : "achieves"
    USERS ||--o{ ACTIVITY_LOGS : "generates"

    ROLES {
        int role_id PK
        varchar role_name UK
        varchar role_slug UK
    }
    USERS {
        int user_id PK
        int role_id FK
        varchar enrollment_no UK
        varchar name
        varchar email UK
        varchar password_hash
        enum status
    }
    COURSES {
        int course_id PK
        varchar course_code UK
        varchar course_name
        int teacher_id FK
        enum status
    }
    ENROLLMENTS {
        int enrollment_id PK
        int student_id FK
        int course_id FK
        enum enrollment_status
    }
    MATERIALS {
        int material_id PK
        int course_id FK
        int uploaded_by FK
        varchar title
        varchar file_path
    }
    ASSIGNMENTS {
        int assignment_id PK
        int course_id FK
        varchar title
        decimal max_marks
        date due_date
        enum status
    }
    SUBMISSIONS {
        int submission_id PK
        int assignment_id FK
        int student_id FK
        decimal marks
        enum status
    }
    QUIZZES {
        int quiz_id PK
        int course_id FK
        varchar title
        decimal total_marks
        int duration_minutes
        int allowed_attempts
    }
    QUESTIONS {
        int question_id PK
        int quiz_id FK
        int course_id FK
        text question_text
        char correct_option
        decimal marks
    }
    QUESTION_OPTIONS {
        int option_id PK
        int question_id FK
        char option_label
        varchar option_text
        boolean is_correct
    }
    ATTEMPTS {
        int attempt_id PK
        int quiz_id FK
        int student_id FK
        decimal score
        decimal percentage
        enum status
    }
    ATTEMPT_ANSWERS {
        int attempt_answer_id PK
        int attempt_id FK
        int question_id FK
        char selected_option
        decimal marks_awarded
    }
    ATTENDANCE {
        int attendance_id PK
        int course_id FK
        int student_id FK
        date class_date
        enum status
    }
    NOTICES {
        int notice_id PK
        int author_id FK
        int course_id FK
        varchar title
        enum audience
        enum priority
    }
    RESULTS {
        int result_id PK
        int student_id FK
        int course_id FK
        decimal overall_percentage
        varchar grade
    }
```

## 05 Admin Use Case Diagram (`05_admin_use_case_diagram.mmd`)

```mermaid
%% 5. Administrator Use-Case Diagram
%% Project: Web-Based Virtual Classroom System (BCSP-064)
flowchart LR
    Admin(["Administrator Actor"])

    subgraph AdminPortal["Administrator Panel Use Cases"]
        UC1(["Authenticate & View System Statistics Dashboard"])
        UC2(["Create, Edit, Search, Filter & Activate/Deactivate Users"])
        UC3(["Manage Teachers & Students Registry"])
        UC4(["Create, Edit, Publish, Archive & Assign Courses"])
        UC5(["Enroll Students in Courses & Prevent Duplicates"])
        UC6(["Publish Institution-Wide & Role-Specific Notices"])
        UC7(["Generate & Export CSV / Printable Academic Reports"])
        UC8(["Inspect System Audit & Activity Logs"])
        UC9(["Configure Institutional & Grading Settings"])
    end

    Admin --> UC1
    Admin --> UC2
    Admin --> UC3
    Admin --> UC4
    Admin --> UC5
    Admin --> UC6
    Admin --> UC7
    Admin --> UC8
    Admin --> UC9
```

## 06 Teacher Use Case Diagram (`06_teacher_use_case_diagram.mmd`)

```mermaid
%% 6. Teacher Use-Case Diagram
%% Project: Web-Based Virtual Classroom System (BCSP-064)
flowchart LR
    Teacher(["Teacher Actor"])

    subgraph TeacherPortal["Teacher Panel Use Cases"]
        UC1(["View Assigned Courses & Enrolled Students"])
        UC2(["Upload, Categorize, Edit & Delete Course Materials"])
        UC3(["Create, Publish & Manage Course Assignments"])
        UC4(["Review Student Submissions, Grade & Publish Marks"])
        UC5(["Create Objective Quizzes & Configure Duration/Attempts"])
        UC6(["Manage Reusable Course Question Bank (MCQ Options)"])
        UC7(["Record & Update Date-Wise Student Attendance"])
        UC8(["Publish Course-Specific Announcements"])
        UC9(["Monitor Student Performance & Export Reports"])
    end

    Teacher --> UC1
    Teacher --> UC2
    Teacher --> UC3
    Teacher --> UC4
    Teacher --> UC5
    Teacher --> UC6
    Teacher --> UC7
    Teacher --> UC8
    Teacher --> UC9
```

## 07 Student Use Case Diagram (`07_student_use_case_diagram.mmd`)

```mermaid
%% 7. Student Use-Case Diagram
%% Project: Web-Based Virtual Classroom System (BCSP-064)
flowchart LR
    Student(["Student Actor"])

    subgraph StudentPortal["Student Panel Use Cases"]
        UC1(["View Personal Academic Dashboard & Deadlines"])
        UC2(["Browse Enrolled Courses & Syllabus Details"])
        UC3(["Download Authorized Learning Materials"])
        UC4(["Submit Assignment Text & File Attachments"])
        UC5(["Attempt Timed Online Objective Quizzes"])
        UC6(["View Published Assignment Marks & Teacher Feedback"])
        UC7(["View Quiz Attempt Scores & Explanations"])
        UC8(["Track Course-Wise Attendance Percentage & History"])
        UC9(["View Consolidated Course Results & Print Transcript"])
        UC10(["Read Institutional & Course Notices"])
    end

    Student --> UC1
    Student --> UC2
    Student --> UC3
    Student --> UC4
    Student --> UC5
    Student --> UC6
    Student --> UC7
    Student --> UC8
    Student --> UC9
    Student --> UC10
```

## 08 Assignment Submission Workflow (`08_assignment_submission_workflow.mmd`)

```mermaid
%% 8. Assignment Creation, Submission & Evaluation Workflow
%% Project: Web-Based Virtual Classroom System (BCSP-064)
sequenceDiagram
    autonumber
    actor Teacher
    participant System as Virtual Classroom Backend
    database DB as MySQL Database
    actor Student

    Teacher->>System: Create Assignment (Course, Title, Max Marks, Due Date)
    System->>System: Validate Teacher Ownership & Date Range
    System->>DB: INSERT INTO assignments (status='open')
    Student->>System: Open Enrolled Course Assignments
    System->>DB: SELECT assignments & student submission status
    Student->>System: Submit Response + Optional Attachment (CSRF Verified)
    System->>System: Verify Enrollment, Deadline/Late Rule, MIME Type & Size
    System->>DB: INSERT/UPDATE submissions (status='submitted' or 'late')
    Teacher->>System: Open Submissions List & Grade Student Work
    System->>System: Validate 0 <= Marks <= Max Marks
    System->>DB: UPDATE submissions (marks, feedback, status='published')
    System->>DB: Recalculate & UPSERT results table for Student + Course
    Student->>System: View My Submissions & My Results
    System->>DB: SELECT published marks & feedback
    System-->>Student: Display Awarded Marks, Percentage, Grade & Feedback
```

## 09 Online Quiz Workflow (`09_online_quiz_workflow.mmd`)

```mermaid
%% 9. Online Objective Quiz & Automated Server-Side Scoring Workflow
%% Project: Web-Based Virtual Classroom System (BCSP-064)
sequenceDiagram
    autonumber
    actor Teacher
    participant System as Virtual Classroom Backend
    database DB as MySQL Database
    actor Student

    Teacher->>System: Create Quiz + Add MCQ Questions & Options (A/B/C/D)
    System->>DB: INSERT INTO quizzes, questions, question_options
    Student->>System: Click "Start Quiz"
    System->>DB: Check Enrollment, Quiz Window & Attempt Count <= allowed_attempts
    System->>DB: INSERT INTO attempts (status='in_progress', started_at=NOW())
    System-->>Student: Render Questions & Options (WITHOUT exposing correct_option)
    Student->>System: Select Answers & Submit Quiz before Timer Expiry
    System->>System: Verify CSRF Token & Server-Side Elapsed Time
    System->>DB: BEGIN TRANSACTION
    System->>DB: Compare answers against questions.correct_option on Server
    System->>DB: INSERT INTO attempt_answers & UPDATE attempts (score, percentage, status='completed')
    System->>DB: Recalculate & UPSERT results table
    System->>DB: COMMIT TRANSACTION
    System-->>Student: Display Score Breakdown & Result Summary
```

## 10 Attendance Workflow (`10_attendance_workflow.mmd`)

```mermaid
%% 10. Attendance Recording & Percentage Calculation Workflow
%% Project: Web-Based Virtual Classroom System (BCSP-064)
flowchart TD
    A(["Teacher Selects Assigned Course & Class Date"]) --> B{"Is Teacher Assigned<br/>to Course?"}
    B -- No --> C["Reject Request (403 Forbidden)"]
    B -- Yes --> D["Fetch Active Enrolled Students for Course"]
    D --> E["Load Existing Attendance for Date (if already recorded)"]
    E --> F["Teacher Marks Each Student Present or Absent & Submits Form"]
    F --> G["Validate CSRF Token & Date Format"]
    G --> H["Execute Transactional UPSERT into attendance Table<br/>UNIQUE(course_id, student_id, class_date)"]
    H --> I["Compute Attendance Percentage per Student:<br/>(Present Classes / Total Recorded Classes) * 100"]
    I --> J["Synchronize attendance_percentage in results Table"]
    J --> K(["Student Views Real-Time Course Attendance Summary & History"])
```

## 11 Database Relationship Overview (`11_database_relationship_overview.mmd`)

```mermaid
%% 11. Database Relationship Overview Diagram
%% Project: Web-Based Virtual Classroom System (BCSP-064)
flowchart LR
    subgraph Identity["Identity & Access"]
        R["roles (PK: role_id)"]
        U["users (PK: user_id, FK: role_id)"]
        LA["login_attempts (PK: id)"]
        AL["activity_logs (PK: log_id, FK: user_id)"]
    end

    subgraph AcademicCore["Academic Core"]
        C["courses (PK: course_id, FK: teacher_id)"]
        E["enrollments (PK: enrollment_id, FK: student_id, course_id)"]
        M["materials (PK: material_id, FK: course_id, uploaded_by)"]
        N["notices (PK: notice_id, FK: author_id, course_id)"]
    end

    subgraph Assessments["Assessments & Evaluations"]
        A["assignments (PK: assignment_id, FK: course_id)"]
        S["submissions (PK: submission_id, FK: assignment_id, student_id)"]
        Q["quizzes (PK: quiz_id, FK: course_id)"]
        QN["questions (PK: question_id, FK: quiz_id, course_id)"]
        QO["question_options (PK: option_id, FK: question_id)"]
        AT["attempts (PK: attempt_id, FK: quiz_id, student_id)"]
        AA["attempt_answers (PK: attempt_answer_id, FK: attempt_id, question_id)"]
    end

    subgraph Records["Attendance & Results"]
        ATD["attendance (PK: attendance_id, FK: course_id, student_id)"]
        RES["results (PK: result_id, FK: student_id, course_id)"]
        SET["settings (PK: setting_id)"]
    end

    R --> U
    U --> C
    U --> E
    C --> E
    C --> M
    C --> N
    C --> A
    A --> S
    U --> S
    C --> Q
    Q --> QN
    QN --> QO
    Q --> AT
    U --> AT
    AT --> AA
    QN --> AA
    C --> ATD
    U --> ATD
    C --> RES
    U --> RES
    U --> AL
```

