# Detailed Installation & Local Running Guide (`installation/INSTALLATION_GUIDE.md`)

This guide walks through setting up the **Web-Based Virtual Classroom System (BCSP-064)** on a fresh **Windows / Linux / macOS XAMPP** installation.

---

## Step 1: Extract the Project Package
1. Download `Web_Based_Virtual_Classroom_System.zip`.
2. Extract the archive so that the folder `Web_Based_Virtual_Classroom_System` is placed inside your XAMPP `htdocs` folder:
   - **Windows:** `C:\xampp\htdocs\Web_Based_Virtual_Classroom_System`
   - **Linux:** `/opt/lampp/htdocs/Web_Based_Virtual_Classroom_System`
   - **macOS:** `/Applications/XAMPP/htdocs/Web_Based_Virtual_Classroom_System`

---

## Step 2: Start Apache and MySQL in XAMPP
1. Launch the **XAMPP Control Panel**.
2. Click **Start** next to **Apache** and wait until the module indicator turns green.
3. Click **Start** next to **MySQL** and wait until the module indicator turns green (default port `3306`).

---

## Step 3: Import the Database Schema and Seed Data
1. Open your web browser and navigate to `http://localhost/phpmyadmin`.
2. Click the **Import** tab in the top toolbar.
3. Under **File to import**, click **Choose File** and select:
   ```text
   C:\xampp\htdocs\Web_Based_Virtual_Classroom_System\database\schema.sql
   ```
4. Scroll down and click **Import** (or **Go**).
   - This creates the database `virtual_classroom_db` and all 18 normalized relational tables.
5. In the left sidebar of phpMyAdmin, click on `virtual_classroom_db`.
6. Click the **Import** tab again, click **Choose File**, and select:
   ```text
   C:\xampp\htdocs\Web_Based_Virtual_Classroom_System\database\seed.sql
   ```
7. Click **Import** (or **Go**) to populate the demonstration accounts, IGNOU BCA courses, enrollments, study materials, assignments, quizzes, attendance records, and notices.

---

## Step 4: Verify Environment Configuration (`.env`)
- The system automatically reads `.env` (or falls back to `.env.example` if `.env` is not created).
- Default XAMPP credentials (`DB_HOST=127.0.0.1`, `DB_PORT=3306`, `DB_DATABASE=virtual_classroom_db`, `DB_USERNAME=root`, `DB_PASSWORD=""`) work out of the box on a fresh XAMPP setup.
- If you configured a MySQL root password, copy `.env.example` to `.env` and update `DB_PASSWORD`.

---

## Step 5: Open the Application & Log In
1. Open your browser and visit:
   ```text
   http://localhost/Web_Based_Virtual_Classroom_System/public/
   ```
   *(Visiting `http://localhost/Web_Based_Virtual_Classroom_System/` also redirects automatically.)*
2. Sign in with any of the three role demonstration accounts:
   - **Administrator:** `admin@ignou-vc.edu.in` / `Admin@123`
   - **Teacher:** `krishan.mishra@ignou-vc.edu.in` / `Teacher@123`
   - **Student:** `sahil.alam@ignou-vc.edu.in` (or Enrolment No. `2200080265`) / `Student@123`
