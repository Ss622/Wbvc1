# Database Setup Guide (`virtual_classroom_db`)

## 1. Overview
The **Web-Based Virtual Classroom System (BCSP-064)** uses a normalized relational database (`virtual_classroom_db`) designed for **MySQL 8.0+** or **MariaDB 10.4+** (bundled with XAMPP).

It contains **18 relational tables** enforcing third normal form (3NF), primary keys, foreign key referential integrity constraints, composite unique keys, and check constraints:
1. `roles` — Role definitions (`ADMIN`, `TEACHER`, `STUDENT`)
2. `users` — User accounts, unique email/enrolment identifiers, and bcrypt password hashes
3. `courses` — Course catalog and assigned teacher links
4. `enrollments` — Student-to-course many-to-many enrollment junction (`UNIQUE(student_id, course_id)`)
5. `materials` — Uploaded study material metadata and protected storage paths
6. `assignments` — Course assignments, due dates, maximum marks, and status
7. `submissions` — Student assignment submissions, teacher evaluations, marks, and publication status (`UNIQUE(assignment_id, student_id)`)
8. `quizzes` — Objective online quizzes, time limits, availability windows, and attempt limits
9. `questions` — Multiple-choice questions linked to courses and quizzes
10. `question_options` — Options (`A`, `B`, `C`, `D`) per question (`UNIQUE(question_id, option_label)`)
11. `attempts` — Student quiz attempts, timestamps, and server-computed scores
12. `attempt_answers` — Per-question student selections and awarded marks (`UNIQUE(attempt_id, question_id)`)
13. `attendance` — Date-wise student attendance records (`UNIQUE(course_id, student_id, class_date)`)
14. `notices` — Institution-wide, role-based, and course-specific announcements
15. `results` — Consolidated course-wise academic performance records (`UNIQUE(student_id, course_id)`)
16. `activity_logs` — Audit trail of user and administrative actions
17. `settings` — Institutional configuration and grading scale settings
18. `login_attempts` — Brute-force login rate-limiting tracker

---

## 2. Importing via phpMyAdmin (XAMPP)
1. Open the **XAMPP Control Panel** and start **Apache** and **MySQL**.
2. Open your browser and navigate to `http://localhost/phpmyadmin`.
3. Click the **Import** tab in the top navigation bar.
4. Click **Choose File**, select `database/schema.sql`, and click **Import** (or **Go**).
   - Note: `schema.sql` automatically creates the `virtual_classroom_db` database and all 18 tables.
5. Select `virtual_classroom_db` in the left sidebar, click **Import** again, choose `database/seed.sql`, and click **Import**.

---

## 3. Importing via MySQL Command Line (Alternative)
```bash
mysql -u root -p < database/schema.sql
mysql -u root -p virtual_classroom_db < database/seed.sql
```
*(On a fresh XAMPP installation on Windows, the default `root` password is empty—press Enter when prompted.)*
