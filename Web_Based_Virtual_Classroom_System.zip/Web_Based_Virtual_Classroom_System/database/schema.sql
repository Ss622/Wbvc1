-- ============================================================================
-- WEB-BASED VIRTUAL CLASSROOM SYSTEM (IGNOU BCA PROJECT: BCSP-064)
-- Relational Database Schema (MySQL 8.0+ / MariaDB 10.4+ Compatible)
-- Learner: Sahil Alam (2200080265) | Guide: Krishan Dev Mishra
-- ============================================================================

SET NAMES utf8mb4;
SET time_zone = '+05:30';
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `virtual_classroom_db`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `virtual_classroom_db`;

-- Drop tables in reverse dependency order for clean re-installation
DROP TABLE IF EXISTS `login_attempts`;
DROP TABLE IF EXISTS `settings`;
DROP TABLE IF EXISTS `activity_logs`;
DROP TABLE IF EXISTS `results`;
DROP TABLE IF EXISTS `notices`;
DROP TABLE IF EXISTS `attendance`;
DROP TABLE IF EXISTS `attempt_answers`;
DROP TABLE IF EXISTS `attempts`;
DROP TABLE IF EXISTS `question_options`;
DROP TABLE IF EXISTS `questions`;
DROP TABLE IF EXISTS `quizzes`;
DROP TABLE IF EXISTS `submissions`;
DROP TABLE IF EXISTS `assignments`;
DROP TABLE IF EXISTS `materials`;
DROP TABLE IF EXISTS `enrollments`;
DROP TABLE IF EXISTS `courses`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `roles`;

-- ----------------------------------------------------------------------------
-- 1. TABLE: roles
-- Stores user roles (ADMIN, TEACHER, STUDENT)
-- ----------------------------------------------------------------------------
CREATE TABLE `roles` (
    `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `role_name` VARCHAR(50) NOT NULL,
    `role_slug` VARCHAR(30) NOT NULL,
    `description` VARCHAR(255) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`role_id`),
    UNIQUE KEY `uq_roles_name` (`role_name`),
    UNIQUE KEY `uq_roles_slug` (`role_slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. TABLE: users
-- Stores Administrator, Teacher, and Student user accounts
-- ----------------------------------------------------------------------------
CREATE TABLE `users` (
    `user_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `role_id` INT UNSIGNED NOT NULL,
    `enrollment_no` VARCHAR(40) DEFAULT NULL,
    `name` VARCHAR(120) NOT NULL,
    `email` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(25) DEFAULT NULL,
    `department` VARCHAR(100) DEFAULT 'School of Computer and Information Sciences (SOCIS)',
    `qualification` VARCHAR(120) DEFAULT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    `last_login_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`),
    UNIQUE KEY `uq_users_email` (`email`),
    UNIQUE KEY `uq_users_enrollment_no` (`enrollment_no`),
    KEY `idx_users_role_status` (`role_id`, `status`),
    KEY `idx_users_name` (`name`),
    CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. TABLE: courses
-- Stores academic courses and assigned instructor
-- ----------------------------------------------------------------------------
CREATE TABLE `courses` (
    `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `course_code` VARCHAR(30) NOT NULL,
    `course_name` VARCHAR(160) NOT NULL,
    `description` TEXT NOT NULL,
    `credits` TINYINT UNSIGNED NOT NULL DEFAULT 4,
    `semester` VARCHAR(40) NOT NULL DEFAULT 'Semester VI',
    `teacher_id` INT UNSIGNED DEFAULT NULL,
    `status` ENUM('draft', 'published', 'archived') NOT NULL DEFAULT 'published',
    `created_by` INT UNSIGNED DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`course_id`),
    UNIQUE KEY `uq_courses_code` (`course_code`),
    KEY `idx_courses_teacher` (`teacher_id`),
    KEY `idx_courses_status` (`status`),
    CONSTRAINT `fk_courses_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_courses_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. TABLE: enrollments
-- Many-to-many association between Students and Courses
-- ----------------------------------------------------------------------------
CREATE TABLE `enrollments` (
    `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `student_id` INT UNSIGNED NOT NULL,
    `course_id` INT UNSIGNED NOT NULL,
    `enrolled_by` INT UNSIGNED DEFAULT NULL,
    `enrollment_status` ENUM('active', 'completed', 'dropped') NOT NULL DEFAULT 'active',
    `enrolled_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`enrollment_id`),
    UNIQUE KEY `uq_enrollment_student_course` (`student_id`, `course_id`),
    KEY `idx_enrollments_course` (`course_id`),
    KEY `idx_enrollments_status` (`enrollment_status`),
    CONSTRAINT `fk_enrollments_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_enrollments_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_enrollments_enrolled_by` FOREIGN KEY (`enrolled_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. TABLE: materials
-- Stores course learning materials and protected file metadata
-- ----------------------------------------------------------------------------
CREATE TABLE `materials` (
    `material_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `course_id` INT UNSIGNED NOT NULL,
    `uploaded_by` INT UNSIGNED NOT NULL,
    `title` VARCHAR(180) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `category` ENUM('Lecture Notes', 'Syllabus', 'Reference Book', 'Lab Manual', 'Presentation', 'Worksheet') NOT NULL DEFAULT 'Lecture Notes',
    `file_name` VARCHAR(255) NOT NULL,
    `original_name` VARCHAR(255) NOT NULL,
    `file_path` VARCHAR(255) NOT NULL,
    `file_type` VARCHAR(25) NOT NULL,
    `mime_type` VARCHAR(120) NOT NULL,
    `file_size` INT UNSIGNED NOT NULL DEFAULT 0,
    `download_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`material_id`),
    KEY `idx_materials_course` (`course_id`),
    KEY `idx_materials_uploader` (`uploaded_by`),
    KEY `idx_materials_category` (`category`),
    CONSTRAINT `fk_materials_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_materials_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. TABLE: assignments
-- Stores course assignments, deadlines, maximum marks, and status
-- ----------------------------------------------------------------------------
CREATE TABLE `assignments` (
    `assignment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `course_id` INT UNSIGNED NOT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `title` VARCHAR(180) NOT NULL,
    `description` TEXT NOT NULL,
    `max_marks` DECIMAL(6,2) NOT NULL DEFAULT 100.00,
    `issue_date` DATE NOT NULL,
    `due_date` DATE NOT NULL,
    `allow_late` TINYINT(1) NOT NULL DEFAULT 1,
    `attachment_path` VARCHAR(255) DEFAULT NULL,
    `attachment_name` VARCHAR(255) DEFAULT NULL,
    `status` ENUM('draft', 'published', 'open', 'due', 'closed') NOT NULL DEFAULT 'open',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`assignment_id`),
    KEY `idx_assignments_course` (`course_id`),
    KEY `idx_assignments_due_date` (`due_date`),
    KEY `idx_assignments_status` (`status`),
    CONSTRAINT `fk_assignments_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_assignments_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `chk_assignments_max_marks` CHECK (`max_marks` > 0 AND `max_marks` <= 1000)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 7. TABLE: submissions
-- Stores student assignment submissions, teacher evaluations, and marks
-- ----------------------------------------------------------------------------
CREATE TABLE `submissions` (
    `submission_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `assignment_id` INT UNSIGNED NOT NULL,
    `student_id` INT UNSIGNED NOT NULL,
    `text_response` TEXT DEFAULT NULL,
    `file_path` VARCHAR(255) DEFAULT NULL,
    `original_name` VARCHAR(255) DEFAULT NULL,
    `file_size` INT UNSIGNED DEFAULT 0,
    `is_late` TINYINT(1) NOT NULL DEFAULT 0,
    `status` ENUM('submitted', 'late', 'evaluated', 'published') NOT NULL DEFAULT 'submitted',
    `marks` DECIMAL(6,2) DEFAULT NULL,
    `feedback` TEXT DEFAULT NULL,
    `evaluated_by` INT UNSIGNED DEFAULT NULL,
    `submitted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `evaluated_at` DATETIME DEFAULT NULL,
    `published_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`submission_id`),
    UNIQUE KEY `uq_submission_assignment_student` (`assignment_id`, `student_id`),
    KEY `idx_submissions_student` (`student_id`),
    KEY `idx_submissions_status` (`status`),
    CONSTRAINT `fk_submissions_assignment` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`assignment_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_submissions_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_submissions_evaluator` FOREIGN KEY (`evaluated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `chk_submissions_marks` CHECK (`marks` IS NULL OR `marks` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 8. TABLE: quizzes
-- Stores objective online quizzes, duration, window, and attempt limits
-- ----------------------------------------------------------------------------
CREATE TABLE `quizzes` (
    `quiz_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `course_id` INT UNSIGNED NOT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `title` VARCHAR(180) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `total_marks` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
    `duration_minutes` INT UNSIGNED NOT NULL DEFAULT 20,
    `start_time` DATETIME NOT NULL,
    `end_time` DATETIME NOT NULL,
    `allowed_attempts` TINYINT UNSIGNED NOT NULL DEFAULT 1,
    `is_published` TINYINT(1) NOT NULL DEFAULT 1,
    `results_published` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`quiz_id`),
    KEY `idx_quizzes_course` (`course_id`),
    KEY `idx_quizzes_published` (`is_published`),
    CONSTRAINT `fk_quizzes_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_quizzes_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `chk_quizzes_duration` CHECK (`duration_minutes` > 0 AND `duration_minutes` <= 300),
    CONSTRAINT `chk_quizzes_attempts` CHECK (`allowed_attempts` >= 1 AND `allowed_attempts` <= 10)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 9. TABLE: questions
-- Stores objective multiple-choice questions for quizzes and question bank
-- ----------------------------------------------------------------------------
CREATE TABLE `questions` (
    `question_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `quiz_id` INT UNSIGNED DEFAULT NULL,
    `course_id` INT UNSIGNED NOT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `topic` VARCHAR(120) NOT NULL DEFAULT 'General',
    `question_text` TEXT NOT NULL,
    `marks` DECIMAL(5,2) NOT NULL DEFAULT 2.00,
    `correct_option` CHAR(1) NOT NULL,
    `explanation` TEXT DEFAULT NULL,
    `sort_order` INT UNSIGNED NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`question_id`),
    KEY `idx_questions_quiz` (`quiz_id`),
    KEY `idx_questions_course_topic` (`course_id`, `topic`),
    CONSTRAINT `fk_questions_quiz` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`quiz_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_questions_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_questions_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `chk_questions_correct_option` CHECK (`correct_option` IN ('A', 'B', 'C', 'D')),
    CONSTRAINT `chk_questions_marks` CHECK (`marks` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 10. TABLE: question_options
-- Stores options (A, B, C, D) for each multiple-choice question
-- ----------------------------------------------------------------------------
CREATE TABLE `question_options` (
    `option_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `question_id` INT UNSIGNED NOT NULL,
    `option_label` CHAR(1) NOT NULL,
    `option_text` VARCHAR(500) NOT NULL,
    `is_correct` TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (`option_id`),
    UNIQUE KEY `uq_question_option_label` (`question_id`, `option_label`),
    CONSTRAINT `fk_options_question` FOREIGN KEY (`question_id`) REFERENCES `questions` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `chk_option_label` CHECK (`option_label` IN ('A', 'B', 'C', 'D'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 11. TABLE: attempts
-- Stores student quiz attempt headers, timing, and server-calculated scores
-- ----------------------------------------------------------------------------
CREATE TABLE `attempts` (
    `attempt_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `quiz_id` INT UNSIGNED NOT NULL,
    `student_id` INT UNSIGNED NOT NULL,
    `attempt_number` TINYINT UNSIGNED NOT NULL DEFAULT 1,
    `started_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `submitted_at` DATETIME DEFAULT NULL,
    `score` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
    `total_marks` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
    `percentage` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `status` ENUM('in_progress', 'completed', 'expired') NOT NULL DEFAULT 'in_progress',
    PRIMARY KEY (`attempt_id`),
    UNIQUE KEY `uq_attempt_quiz_student_num` (`quiz_id`, `student_id`, `attempt_number`),
    KEY `idx_attempts_student` (`student_id`),
    KEY `idx_attempts_status` (`status`),
    CONSTRAINT `fk_attempts_quiz` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`quiz_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_attempts_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 12. TABLE: attempt_answers
-- Stores individual question responses within a quiz attempt
-- ----------------------------------------------------------------------------
CREATE TABLE `attempt_answers` (
    `attempt_answer_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `attempt_id` INT UNSIGNED NOT NULL,
    `question_id` INT UNSIGNED NOT NULL,
    `selected_option` CHAR(1) DEFAULT NULL,
    `is_correct` TINYINT(1) NOT NULL DEFAULT 0,
    `marks_awarded` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    PRIMARY KEY (`attempt_answer_id`),
    UNIQUE KEY `uq_attempt_question` (`attempt_id`, `question_id`),
    KEY `idx_attempt_answers_question` (`question_id`),
    CONSTRAINT `fk_attempt_answers_attempt` FOREIGN KEY (`attempt_id`) REFERENCES `attempts` (`attempt_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_attempt_answers_question` FOREIGN KEY (`question_id`) REFERENCES `questions` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 13. TABLE: attendance
-- Stores course-wise daily student attendance records
-- ----------------------------------------------------------------------------
CREATE TABLE `attendance` (
    `attendance_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `course_id` INT UNSIGNED NOT NULL,
    `student_id` INT UNSIGNED NOT NULL,
    `class_date` DATE NOT NULL,
    `status` ENUM('Present', 'Absent') NOT NULL DEFAULT 'Present',
    `remarks` VARCHAR(255) DEFAULT NULL,
    `recorded_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`attendance_id`),
    UNIQUE KEY `uq_attendance_course_student_date` (`course_id`, `student_id`, `class_date`),
    KEY `idx_attendance_student` (`student_id`),
    KEY `idx_attendance_date` (`class_date`),
    CONSTRAINT `fk_attendance_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_attendance_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_attendance_recorder` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 14. TABLE: notices
-- Stores institution-wide, role-specific, and course-specific announcements
-- ----------------------------------------------------------------------------
CREATE TABLE `notices` (
    `notice_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `title` VARCHAR(180) NOT NULL,
    `description` TEXT NOT NULL,
    `author_id` INT UNSIGNED NOT NULL,
    `audience` ENUM('all', 'students', 'teachers', 'course') NOT NULL DEFAULT 'all',
    `course_id` INT UNSIGNED DEFAULT NULL,
    `priority` ENUM('normal', 'important', 'urgent') NOT NULL DEFAULT 'normal',
    `status` ENUM('draft', 'published') NOT NULL DEFAULT 'published',
    `published_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`notice_id`),
    KEY `idx_notices_audience_status` (`audience`, `status`),
    KEY `idx_notices_course` (`course_id`),
    KEY `idx_notices_priority` (`priority`),
    CONSTRAINT `fk_notices_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_notices_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 15. TABLE: results
-- Stores consolidated course-wise academic performance records per student
-- ----------------------------------------------------------------------------
CREATE TABLE `results` (
    `result_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `student_id` INT UNSIGNED NOT NULL,
    `course_id` INT UNSIGNED NOT NULL,
    `assignment_marks_obtained` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
    `assignment_marks_Max` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
    `quiz_marks_obtained` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
    `quiz_marks_max` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
    `attendance_percentage` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `overall_percentage` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `grade` VARCHAR(10) NOT NULL DEFAULT 'In Progress',
    `remarks` VARCHAR(255) DEFAULT NULL,
    `is_published` TINYINT(1) NOT NULL DEFAULT 1,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`result_id`),
    UNIQUE KEY `uq_results_student_course` (`student_id`, `course_id`),
    KEY `idx_results_course` (`course_id`),
    CONSTRAINT `fk_results_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_results_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `chk_results_percentages` CHECK (
        `attendance_percentage` >= 0 AND `attendance_percentage` <= 100 AND
        `overall_percentage` >= 0 AND `overall_percentage` <= 100
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 16. TABLE: activity_logs
-- Audit log of authentication and administrative/academic actions
-- ----------------------------------------------------------------------------
CREATE TABLE `activity_logs` (
    `log_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED DEFAULT NULL,
    `action` VARCHAR(100) NOT NULL,
    `entity_type` VARCHAR(50) DEFAULT NULL,
    `entity_id` INT UNSIGNED DEFAULT NULL,
    `description` VARCHAR(500) NOT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`log_id`),
    KEY `idx_activity_logs_user` (`user_id`),
    KEY `idx_activity_logs_created` (`created_at`),
    CONSTRAINT `fk_activity_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 17. TABLE: settings
-- Stores global institutional and academic grading configuration
-- ----------------------------------------------------------------------------
CREATE TABLE `settings` (
    `setting_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `setting_key` VARCHAR(80) NOT NULL,
    `setting_value` TEXT NOT NULL,
    `description` VARCHAR(255) DEFAULT NULL,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`setting_id`),
    UNIQUE KEY `uq_settings_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 18. TABLE: login_attempts
-- Tracks failed login attempts for rate limiting / brute-force protection
-- ----------------------------------------------------------------------------
CREATE TABLE `login_attempts` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `email` VARCHAR(150) NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `attempted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_login_attempts_email_time` (`email`, `attempted_at`),
    KEY `idx_login_attempts_ip_time` (`ip_address`, `attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
