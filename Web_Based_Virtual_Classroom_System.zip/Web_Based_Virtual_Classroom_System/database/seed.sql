-- ============================================================================
-- WEB-BASED VIRTUAL CLASSROOM SYSTEM (IGNOU BCA PROJECT: BCSP-064)
-- Database Seed Data (Demonstration Accounts & Academic Records)
-- ============================================================================
-- Default Demonstration Credentials (All stored using PHP password_hash bcrypt):
--   Administrator : admin@ignou-vc.edu.in          | Admin@123
--   Teacher 1     : krishan.mishra@ignou-vc.edu.in | Teacher@123
--   Teacher 2     : shalini.verma@ignou-vc.edu.in  | Teacher@123
--   Teacher 3     : rakesh.sharma@ignou-vc.edu.in  | Teacher@123
--   Student 1     : sahil.alam@ignou-vc.edu.in     | Student@123
--   Student 2     : priya.kumari@ignou-vc.edu.in   | Student@123
--   Student 3     : rohit.sinha@ignou-vc.edu.in    | Student@123
--   Student 4     : ananya.gupta@ignou-vc.edu.in   | Student@123
--   Student 5     : vikram.patel@ignou-vc.edu.in   | Student@123
--   Student 6     : neha.singh@ignou-vc.edu.in     | Student@123
-- ============================================================================

USE `virtual_classroom_db`;

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Roles
INSERT INTO `roles` (`role_id`, `role_name`, `role_slug`, `description`) VALUES
(1, 'Administrator', 'ADMIN', 'Full institutional control over users, courses, enrollments, notices, settings, and reports.'),
(2, 'Teacher', 'TEACHER', 'Manages assigned courses, learning materials, assignments, evaluations, quizzes, and attendance.'),
(3, 'Student', 'STUDENT', 'Accesses enrolled courses, downloads study materials, submits assignments, attempts quizzes, and views results.');

-- 2. Users (1 Admin, 3 Teachers, 6 Students)
INSERT INTO `users` (`user_id`, `role_id`, `enrollment_no`, `name`, `email`, `phone`, `department`, `qualification`, `password_hash`, `status`, `last_login_at`) VALUES
(1, 1, 'ADM-0500-01', 'Dr. Arvind Narayan', 'admin@ignou-vc.edu.in', '9811023456', 'Regional Centre Administration (RC Patna)', 'Ph.D. (Computer Science)', '$2y$10$hZ8NOV1io0ylxLVbaohN9OHTvj3UzwQWTV2m35j3zSZMSeA5U7jZe', 'active', '2026-11-08 09:00:00'),
(2, 2, 'FAC-0500-101', 'Prof. Krishan Dev Mishra', 'krishan.mishra@ignou-vc.edu.in', '9431011223', 'School of Computer & Information Sciences', 'B.Tech, M.Tech (CSE)', '$2y$10$OgZe.kqqEGbiuTgv01fmce3Tb.gBwoZOnQnMCERrBe.oGv2zzwFji', 'active', '2026-11-08 09:30:00'),
(3, 2, 'FAC-0500-102', 'Dr. Shalini Verma', 'shalini.verma@ignou-vc.edu.in', '9431044556', 'School of Computer & Information Sciences', 'MCA, Ph.D.', '$2y$10$OgZe.kqqEGbiuTgv01fmce3Tb.gBwoZOnQnMCERrBe.oGv2zzwFji', 'active', '2026-11-07 16:20:00'),
(4, 2, 'FAC-0500-103', 'Mr. Rakesh Kumar Sharma', 'rakesh.sharma@ignou-vc.edu.in', '9431077889', 'School of Computer & Information Sciences', 'M.Sc. (IT), NET', '$2y$10$OgZe.kqqEGbiuTgv01fmce3Tb.gBwoZOnQnMCERrBe.oGv2zzwFji', 'active', '2026-11-06 14:10:00'),
(5, 3, '2200080265', 'Sahil Alam', 'sahil.alam@ignou-vc.edu.in', '6203677237', 'BCA Programme (Study Centre 0500)', 'BCA Semester VI', '$2y$10$ko6lZTvhGLL/2JGNZDwM6eGbaNt8ObQuW6k0Twpcpgh9I7T4tOtO2', 'active', '2026-11-08 10:15:00'),
(6, 3, '2200080266', 'Priya Kumari', 'priya.kumari@ignou-vc.edu.in', '9123456701', 'BCA Programme (Study Centre 0500)', 'BCA Semester VI', '$2y$10$ko6lZTvhGLL/2JGNZDwM6eGbaNt8ObQuW6k0Twpcpgh9I7T4tOtO2', 'active', '2026-11-08 08:45:00'),
(7, 3, '2200080267', 'Rohit Kumar Sinha', 'rohit.sinha@ignou-vc.edu.in', '9123456702', 'BCA Programme (Study Centre 0500)', 'BCA Semester VI', '$2y$10$ko6lZTvhGLL/2JGNZDwM6eGbaNt8ObQuW6k0Twpcpgh9I7T4tOtO2', 'active', '2026-11-07 19:00:00'),
(8, 3, '2200080268', 'Ananya Gupta', 'ananya.gupta@ignou-vc.edu.in', '9123456703', 'BCA Programme (Study Centre 0500)', 'BCA Semester VI', '$2y$10$ko6lZTvhGLL/2JGNZDwM6eGbaNt8ObQuW6k0Twpcpgh9I7T4tOtO2', 'active', '2026-11-07 11:30:00'),
(9, 3, '2200080269', 'Vikram Aditya Patel', 'vikram.patel@ignou-vc.edu.in', '9123456704', 'BCA Programme (Study Centre 0500)', 'BCA Semester VI', '$2y$10$ko6lZTvhGLL/2JGNZDwM6eGbaNt8ObQuW6k0Twpcpgh9I7T4tOtO2', 'active', '2026-11-05 17:15:00'),
(10, 3, '2200080270', 'Neha Singh', 'neha.singh@ignou-vc.edu.in', '9123456705', 'BCA Programme (Study Centre 0500)', 'BCA Semester VI', '$2y$10$ko6lZTvhGLL/2JGNZDwM6eGbaNt8ObQuW6k0Twpcpgh9I7T4tOtO2', 'inactive', NULL);

-- 3. Courses (5 IGNOU BCA Courses)
INSERT INTO `courses` (`course_id`, `course_code`, `course_name`, `description`, `credits`, `semester`, `teacher_id`, `status`, `created_by`) VALUES
(1, 'BCS-051', 'Introduction to Software Engineering', 'Covers Software Development Life Cycle (SDLC) models, IEEE Software Requirements Specification (SRS), Data Flow Diagrams (DFD), structured system design, testing strategies, and software maintenance.', 3, 'Semester V', 2, 'published', 1),
(2, 'MCS-023', 'Introduction to Database Management Systems', 'Comprehensive study of Relational Database Management Systems (RDBMS), Entity-Relationship (ER) modelling, functional dependencies, BCNF normalization, SQL queries, transactions, and concurrency control.', 3, 'Semester III', 2, 'published', 1),
(3, 'BCS-053', 'Web Programming', 'Client-server web architecture, semantic HTML5, responsive CSS3, JavaScript DOM scripting, object-oriented PHP backend programming, session management, PDO database connectivity, and web security.', 2, 'Semester V', 3, 'published', 1),
(4, 'BCS-062', 'E-Commerce and Digital Systems', 'Architecture of electronic commerce systems, digital payment workflows, public key cryptography, enterprise security controls, B2B/B2C portals, and regulatory compliance.', 2, 'Semester VI', 3, 'published', 1),
(5, 'MCS-022', 'Operating System Concepts and Networking Management', 'Process scheduling, memory management, file systems, TCP/IP protocol suite, network security administration, and Linux/Windows server configuration.', 4, 'Semester VI', 4, 'draft', 1);

-- 4. Enrollments (Students enrolled across published courses)
INSERT INTO `enrollments` (`enrollment_id`, `student_id`, `course_id`, `enrolled_by`, `enrollment_status`, `enrolled_at`) VALUES
(1, 5, 1, 1, 'active', '2026-09-01 10:00:00'),
(2, 5, 2, 1, 'active', '2026-09-01 10:01:00'),
(3, 5, 3, 1, 'active', '2026-09-01 10:02:00'),
(4, 5, 4, 1, 'active', '2026-09-01 10:03:00'),
(5, 6, 1, 1, 'active', '2026-09-01 10:05:00'),
(6, 6, 2, 1, 'active', '2026-09-01 10:06:00'),
(7, 6, 3, 1, 'active', '2026-09-01 10:07:00'),
(8, 7, 1, 1, 'active', '2026-09-02 11:00:00'),
(9, 7, 2, 1, 'active', '2026-09-02 11:01:00'),
(10, 8, 1, 1, 'active', '2026-09-02 11:10:00'),
(11, 8, 3, 1, 'active', '2026-09-02 11:11:00'),
(12, 8, 4, 1, 'active', '2026-09-02 11:12:00'),
(13, 9, 2, 1, 'active', '2026-09-03 09:30:00'),
(14, 9, 3, 1, 'active', '2026-09-03 09:31:00');

-- 5. Learning Materials (Connected to Courses 1, 2, 3, 4)
INSERT INTO `materials` (`material_id`, `course_id`, `uploaded_by`, `title`, `description`, `category`, `file_name`, `original_name`, `file_path`, `file_type`, `mime_type`, `file_size`, `download_count`, `created_at`) VALUES
(1, 1, 2, 'IEEE 830 SRS Standard & DFD Modelling Guide', 'Complete reference notes covering IEEE Software Requirements Specification structure, Context-Level (Level 0) and Level 1 Data Flow Diagrams with academic case studies.', 'Lecture Notes', 'seed_bcs051_srs_guide.txt', 'BCS051_IEEE_SRS_and_DFD_Guide.txt', 'materials/seed_bcs051_srs_guide.txt', 'txt', 'text/plain', 2480, 14, '2026-09-10 11:00:00'),
(2, 1, 2, 'Software Testing Methodologies & BVA Checklist', 'Equivalence partitioning, boundary value analysis (BVA), unit testing, integration testing, and system verification guidelines.', 'Lab Manual', 'seed_bcs051_testing_manual.txt', 'BCS051_Software_Testing_Manual.txt', 'materials/seed_bcs051_testing_manual.txt', 'txt', 'text/plain', 2150, 9, '2026-09-15 14:30:00'),
(3, 2, 2, 'Relational Database Normalization (1NF to BCNF) Notes', 'Step-by-step walkthrough of functional dependencies, candidate keys, 1NF, 2NF, 3NF, and Boyce-Codd Normal Form with SQL DDL examples.', 'Lecture Notes', 'seed_mcs023_normalization.txt', 'MCS023_Normalization_1NF_to_BCNF.txt', 'materials/seed_mcs023_normalization.txt', 'txt', 'text/plain', 2890, 19, '2026-09-12 10:15:00'),
(4, 3, 3, 'Secure PHP 8 & PDO Prepared Statements Handbook', 'Best practices for object-oriented PHP 8.2, PDO parameterized queries, password_hash() authentication, CSRF protection, and XSS escaping.', 'Lecture Notes', 'seed_bcs053_php_security.txt', 'BCS053_Secure_PHP_PDO_Handbook.txt', 'materials/seed_bcs053_php_security.txt', 'txt', 'text/plain', 3120, 22, '2026-09-18 16:00:00'),
(5, 4, 3, 'Digital Payment Security & TLS Architecture Syllabus', 'Overview of SSL/TLS handshake, public-key infrastructure, OWASP web security controls, and e-commerce transaction integrity.', 'Syllabus', 'seed_bcs062_ecommerce_syllabus.txt', 'BCS062_ECommerce_Syllabus_Unit1_4.txt', 'materials/seed_bcs062_ecommerce_syllabus.txt', 'txt', 'text/plain', 1940, 7, '2026-09-20 12:00:00');

-- 6. Assignments
INSERT INTO `assignments` (`assignment_id`, `course_id`, `created_by`, `title`, `description`, `max_marks`, `issue_date`, `due_date`, `allow_late`, `attachment_path`, `attachment_name`, `status`) VALUES
(1, 1, 2, 'TMA-01: Prepare SRS & Level-1 DFD for Virtual Classroom System', 'Develop a formal IEEE Software Requirements Specification (SRS) document along with Context-Level (Level 0) and Level-1 Data Flow Diagrams for a Web-Based Virtual Classroom System. Include functional requirements and test cases.', 100.00, '2026-09-15', '2026-12-15', 1, 'assignments/seed_assignment_1_spec.txt', 'BCS051_TMA01_Instructions.txt', 'open'),
(2, 2, 2, 'TMA-02: ER Diagram & 3NF Relational Schema Design', 'Design an Entity-Relationship (ER) diagram and normalized 3NF MySQL schema with primary keys, foreign keys, and unique constraints for an academic course management database.', 100.00, '2026-09-20', '2026-12-20', 1, 'assignments/seed_assignment_2_spec.txt', 'MCS023_TMA02_DBMS_Instructions.txt', 'open'),
(3, 3, 3, 'Lab Assignment: Role-Based Session Authentication & CSRF Guard', 'Implement a modular PHP authentication workflow using PDO prepared statements, password_hash(), session regeneration, and CSRF token verification.', 50.00, '2026-10-01', '2026-12-25', 1, NULL, NULL, 'open'),
(4, 4, 3, 'Case Study: E-Commerce Security Audit & OWASP Top 10 Report', 'Write an analytical case study evaluating authentication, access control, and cryptographic safeguards in modern web applications.', 50.00, '2026-10-10', '2026-12-30', 0, NULL, NULL, 'published');

-- 7. Submissions (Evaluated/Published and Pending submissions)
INSERT INTO `submissions` (`submission_id`, `assignment_id`, `student_id`, `text_response`, `file_path`, `original_name`, `file_size`, `is_late`, `status`, `marks`, `feedback`, `evaluated_by`, `submitted_at`, `evaluated_at`, `published_at`) VALUES
(1, 1, 5, 'Submitted full IEEE SRS, Context DFD (Level 0), Level-1 DFD with 8 processes, and 12 system test cases for the Web-Based Virtual Classroom System.', 'submissions/seed_sub_sahil_bcs051.txt', 'Sahil_Alam_2200080265_BCS051_SRS.txt', 1840, 0, 'published', 92.00, 'Excellent SRS structure and well-balanced DFD decomposition. Clear traceability between functional requirements and test cases.', 2, '2026-10-12 14:20:00', '2026-10-15 11:00:00', '2026-10-15 11:05:00'),
(2, 2, 5, 'Completed 18-table normalized 3NF relational schema with foreign keys, composite unique constraints on enrollments and attendance, and ER model.', 'submissions/seed_sub_sahil_mcs023.txt', 'Sahil_Alam_2200080265_MCS023_Schema.txt', 2110, 0, 'published', 89.00, 'Strong relational schema design. Composite unique keys on (student_id, course_id) and attendance dates are properly enforced.', 2, '2026-10-18 16:40:00', '2026-10-20 10:30:00', '2026-10-20 10:35:00'),
(3, 1, 6, 'Attached IEEE SRS and DFD diagrams for institutional course portal.', 'submissions/seed_sub_priya_bcs051.txt', 'Priya_Kumari_2200080266_BCS051.txt', 1520, 0, 'published', 85.00, 'Very good analysis of user requirements and DFD data stores.', 2, '2026-10-14 09:15:00', '2026-10-16 15:00:00', '2026-10-16 15:10:00'),
(4, 1, 7, 'Submitted SRS document covering functional and non-functional requirements.', NULL, NULL, 0, 0, 'submitted', NULL, NULL, NULL, '2026-11-05 18:10:00', NULL, NULL),
(5, 3, 6, 'Implemented AuthController, Session regeneration, and CSRF token verification middleware.', NULL, NULL, 0, 0, 'evaluated', 44.00, 'Clean PDO prepared statements and session handling. Ready for publication.', 3, '2026-11-04 12:30:00', '2026-11-06 17:00:00', NULL);

-- 8. Quizzes
INSERT INTO `quizzes` (`quiz_id`, `course_id`, `created_by`, `title`, `description`, `total_marks`, `duration_minutes`, `start_time`, `end_time`, `allowed_attempts`, `is_published`, `results_published`) VALUES
(1, 1, 2, 'Quiz 01: Software Engineering & SDLC Fundamentals', 'Objective evaluation covering SDLC models, IEEE SRS characteristics, Data Flow Diagrams, coupling/cohesion, and boundary value testing.', 10.00, 15, '2026-09-01 00:00:00', '2027-12-31 23:59:59', 2, 1, 1),
(2, 2, 2, 'Quiz 02: Relational DBMS, Normalization & SQL Constraints', 'Objective quiz on primary/foreign keys, BCNF normalization, ACID transaction properties, and SQL joins.', 10.00, 15, '2026-09-01 00:00:00', '2027-12-31 23:59:59', 2, 1, 1),
(3, 3, 3, 'Quiz 03: Web Programming, PHP Sessions & Application Security', 'Objective assessment on HTTP methods, PDO prepared statements, password hashing, CSRF tokens, and XSS prevention.', 10.00, 20, '2026-09-01 00:00:00', '2027-12-31 23:59:59', 2, 1, 1);

-- 9. Questions (5 questions per quiz = 15 questions)
INSERT INTO `questions` (`question_id`, `quiz_id`, `course_id`, `created_by`, `topic`, `question_text`, `marks`, `correct_option`, `explanation`, `sort_order`) VALUES
-- Quiz 1 (BCS-051)
(1, 1, 1, 2, 'SRS & Requirements', 'Which IEEE standard is widely used for organizing a Software Requirements Specification (SRS) document?', 2.00, 'B', 'IEEE Std 830 defines the recommended practice for Software Requirements Specifications.', 1),
(2, 1, 1, 2, 'Data Flow Diagrams', 'In a Context-Level Data Flow Diagram (Level 0 DFD), how is the entire software system represented?', 2.00, 'A', 'A Context-Level DFD represents the entire software system as a single central process interacting with external entities.', 2),
(3, 1, 1, 2, 'Modular Design', 'Which combination of coupling and cohesion represents the highest quality modular software design?', 2.00, 'C', 'Low coupling and high cohesion make modules independent, maintainable, and reusable.', 3),
(4, 1, 1, 2, 'Software Testing', 'Boundary Value Analysis (BVA) is primarily categorized under which software testing technique?', 2.00, 'D', 'Boundary Value Analysis is a black-box functional testing technique that tests input boundaries.', 4),
(5, 1, 1, 2, 'SDLC Models', 'Which SDLC model explicitly incorporates risk analysis during each iterative loop?', 2.00, 'B', 'Barry Boehm''s Spiral Model explicitly includes risk analysis and prototyping in every cycle.', 5),
-- Quiz 2 (MCS-023)
(6, 2, 2, 2, 'Relational Keys', 'Which database constraint ensures that a foreign key value in a child table always references an existing primary key in a parent table?', 2.00, 'A', 'Referential integrity ensures valid foreign-key references across related tables.', 1),
(7, 2, 2, 2, 'Normalization', 'A relation is in Third Normal Form (3NF) if it is in 2NF and contains no:', 2.00, 'C', '3NF eliminates transitive dependencies of non-prime attributes on the primary key.', 2),
(8, 2, 2, 2, 'Transactions', 'In database transaction processing, what does the letter "A" in ACID stand for?', 2.00, 'B', 'Atomicity ensures that all operations in a transaction succeed completely or roll back completely.', 3),
(9, 2, 2, 2, 'SQL Constraints', 'Which constraint prevents a student from being enrolled twice in the exact same course in the enrollments table?', 2.00, 'D', 'A composite UNIQUE constraint on (student_id, course_id) prevents duplicate enrollments.', 4),
(10, 2, 2, 2, 'ER Modelling', 'How is a many-to-many (M:N) relationship between Students and Courses resolved in a relational database schema?', 2.00, 'A', 'An associative junction table (such as enrollments) with foreign keys to both entities resolves M:N relationships.', 5),
-- Quiz 3 (BCS-053)
(11, 3, 3, 3, 'Authentication Security', 'Which built-in PHP function securely hashes passwords using strong one-way bcrypt/Argon2 algorithms?', 2.00, 'C', 'password_hash() generates a cryptographically salted one-way hash compatible with password_verify().', 1),
(12, 3, 3, 3, 'Database Security', 'What is the primary defense against SQL Injection attacks in PHP PDO database applications?', 2.00, 'A', 'Prepared statements with bound parameters separate SQL code structure from user-supplied data.', 2),
(13, 3, 3, 3, 'Session Security', 'Why should session_regenerate_id(true) be invoked immediately after a user logs in?', 2.00, 'B', 'Regenerating the session identifier prevents Session Fixation attacks.', 3),
(14, 3, 3, 3, 'XSS Prevention', 'Which PHP function escapes special HTML characters before rendering dynamic user content in a browser view?', 2.00, 'D', 'htmlspecialchars($val, ENT_QUOTES, "UTF-8") encodes <, >, &, ", and '' to prevent Cross-Site Scripting (XSS).', 4),
(15, 3, 3, 3, 'CSRF Defense', 'How does a synchronizer token pattern protect state-changing POST forms?', 2.00, 'B', 'A cryptographic per-session CSRF token is embedded in forms and verified server-side on POST submission.', 5);

-- 10. Question Options (4 options per question = 60 options)
INSERT INTO `question_options` (`question_id`, `option_label`, `option_text`, `is_correct`) VALUES
-- Q1
(1, 'A', 'IEEE Std 754', 0),
(1, 'B', 'IEEE Std 830', 1),
(1, 'C', 'IEEE Std 802.11', 0),
(1, 'D', 'ISO 9000-3', 0),
-- Q2
(2, 'A', 'As a single central process node interacting with external entities', 1),
(2, 'B', 'As multiple database tables joined by foreign keys', 0),
(2, 'C', 'As a sequence of source code classes and methods', 0),
(2, 'D', 'As a physical network topology diagram', 0),
-- Q3
(3, 'A', 'High coupling and low cohesion', 0),
(3, 'B', 'High coupling and high cohesion', 0),
(3, 'C', 'Low coupling and high cohesion', 1),
(3, 'D', 'Low coupling and low cohesion', 0),
-- Q4
(4, 'A', 'White-box path coverage testing', 0),
(4, 'B', 'Database schema migration', 0),
(4, 'C', 'Network packet sniffing', 0),
(4, 'D', 'Black-box functional testing', 1),
-- Q5
(5, 'A', 'Classical Waterfall Model', 0),
(5, 'B', 'Spiral Model', 1),
(5, 'C', 'Big-Bang Model', 0),
(5, 'D', 'Code-and-Fix Model', 0),
-- Q6
(6, 'A', 'Referential Integrity Constraint (Foreign Key)', 1),
(6, 'B', 'Check Constraint', 0),
(6, 'C', 'Default Value Constraint', 0),
(6, 'D', 'Full-Text Index', 0),
-- Q7
(7, 'A', 'Primary keys', 0),
(7, 'B', 'Foreign keys', 0),
(7, 'C', 'Transitive dependencies of non-prime attributes on the primary key', 1),
(7, 'D', 'Atomic column values', 0),
-- Q8
(8, 'A', 'Availability', 0),
(8, 'B', 'Atomicity', 1),
(8, 'C', 'Authentication', 0),
(8, 'D', 'Authorization', 0),
-- Q9
(9, 'A', 'AUTO_INCREMENT', 0),
(9, 'B', 'NOT NULL', 0),
(9, 'C', 'DEFAULT CURRENT_TIMESTAMP', 0),
(9, 'D', 'Composite UNIQUE constraint on (student_id, course_id)', 1),
-- Q10
(10, 'A', 'By creating a junction/associative table containing foreign keys to both tables', 1),
(10, 'B', 'By storing comma-separated course IDs in a single VARCHAR column', 0),
(10, 'C', 'By duplicating the users table for every course', 0),
(10, 'D', 'By removing primary keys from both tables', 0),
-- Q11
(11, 'A', 'md5()', 0),
(11, 'B', 'base64_encode()', 0),
(11, 'C', 'password_hash()', 1),
(11, 'D', 'crc32()', 0),
-- Q12
(12, 'A', 'PDO Prepared Statements with parameterized queries', 1),
(12, 'B', 'Client-side CSS styling', 0),
(12, 'C', 'Increasing PHP memory_limit', 0),
(12, 'D', 'Hiding form buttons with JavaScript', 0),
-- Q13
(13, 'A', 'To clear the MySQL query cache', 0),
(13, 'B', 'To prevent Session Fixation attacks upon privilege elevation', 1),
(13, 'C', 'To compress HTML output', 0),
(13, 'D', 'To reset the database auto-increment counter', 0),
-- Q14
(14, 'A', 'strtoupper()', 0),
(14, 'B', 'array_merge()', 0),
(14, 'C', 'json_decode()', 0),
(14, 'D', 'htmlspecialchars()', 1),
-- Q15
(15, 'A', 'By encrypting CSS stylesheets', 0),
(15, 'B', 'By validating a secret session-bound token submitted with every state-changing POST request', 1),
(15, 'C', 'By disabling browser cookies completely', 0),
(15, 'D', 'By renaming the database table', 0);

-- 11. Sample Quiz Attempts (Completed attempts by students)
INSERT INTO `attempts` (`attempt_id`, `quiz_id`, `student_id`, `attempt_number`, `started_at`, `submitted_at`, `score`, `total_marks`, `percentage`, `status`) VALUES
(1, 1, 5, 1, '2026-10-16 10:00:00', '2026-10-16 10:09:30', 10.00, 10.00, 100.00, 'completed'),
(2, 2, 5, 1, '2026-10-21 11:00:00', '2026-10-21 11:11:15', 8.00, 10.00, 80.00, 'completed'),
(3, 1, 6, 1, '2026-10-17 15:00:00', '2026-10-17 15:12:00', 8.00, 10.00, 80.00, 'completed'),
(4, 1, 7, 1, '2026-10-18 16:00:00', '2026-10-18 16:10:45', 6.00, 10.00, 60.00, 'completed');

-- 12. Attempt Answers
INSERT INTO `attempt_answers` (`attempt_id`, `question_id`, `selected_option`, `is_correct`, `marks_awarded`) VALUES
-- Attempt 1 (Sahil on Quiz 1 -> 10/10)
(1, 1, 'B', 1, 2.00),
(1, 2, 'A', 1, 2.00),
(1, 3, 'C', 1, 2.00),
(1, 4, 'D', 1, 2.00),
(1, 5, 'B', 1, 2.00),
-- Attempt 2 (Sahil on Quiz 2 -> 8/10)
(2, 6, 'A', 1, 2.00),
(2, 7, 'C', 1, 2.00),
(2, 8, 'B', 1, 2.00),
(2, 9, 'D', 1, 2.00),
(2, 10, 'B', 0, 0.00),
-- Attempt 3 (Priya on Quiz 1 -> 8/10)
(3, 1, 'B', 1, 2.00),
(3, 2, 'A', 1, 2.00),
(3, 3, 'C', 1, 2.00),
(3, 4, 'A', 0, 0.00),
(3, 5, 'B', 1, 2.00),
-- Attempt 4 (Rohit on Quiz 1 -> 6/10)
(4, 1, 'B', 1, 2.00),
(4, 2, 'A', 1, 2.00),
(4, 3, 'A', 0, 0.00),
(4, 4, 'D', 1, 2.00),
(4, 5, 'A', 0, 0.00);

-- 13. Attendance Records (Multiple class sessions across courses)
INSERT INTO `attendance` (`course_id`, `student_id`, `class_date`, `status`, `remarks`, `recorded_by`) VALUES
-- Course 1 (BCS-051) - 4 class dates for enrolled students (5, 6, 7, 8)
(1, 5, '2026-10-05', 'Present', 'On time', 2),
(1, 6, '2026-10-05', 'Present', 'On time', 2),
(1, 7, '2026-10-05', 'Present', 'On time', 2),
(1, 8, '2026-10-05', 'Absent', 'Medical leave informed', 2),
(1, 5, '2026-10-12', 'Present', 'Active in DFD session', 2),
(1, 6, '2026-10-12', 'Present', 'On time', 2),
(1, 7, '2026-10-12', 'Absent', NULL, 2),
(1, 8, '2026-10-12', 'Present', 'On time', 2),
(1, 5, '2026-10-19', 'Present', 'Presented SRS draft', 2),
(1, 6, '2026-10-19', 'Present', 'On time', 2),
(1, 7, '2026-10-19', 'Present', 'On time', 2),
(1, 8, '2026-10-19', 'Present', 'On time', 2),
(1, 5, '2026-10-26', 'Present', 'On time', 2),
(1, 6, '2026-10-26', 'Absent', NULL, 2),
(1, 7, '2026-10-26', 'Present', 'On time', 2),
(1, 8, '2026-10-26', 'Present', 'On time', 2),
-- Course 2 (MCS-023) - 3 class dates for enrolled students (5, 6, 7, 9)
(2, 5, '2026-10-06', 'Present', 'On time', 2),
(2, 6, '2026-10-06', 'Present', 'On time', 2),
(2, 7, '2026-10-06', 'Present', 'On time', 2),
(2, 9, '2026-10-06', 'Present', 'On time', 2),
(2, 5, '2026-10-13', 'Present', 'Completed SQL lab', 2),
(2, 6, '2026-10-13', 'Present', 'On time', 2),
(2, 7, '2026-10-13', 'Absent', NULL, 2),
(2, 9, '2026-10-13', 'Present', 'On time', 2),
(2, 5, '2026-10-20', 'Present', 'On time', 2),
(2, 6, '2026-10-20', 'Present', 'On time', 2),
(2, 7, '2026-10-20', 'Present', 'On time', 2),
(2, 9, '2026-10-20', 'Absent', NULL, 2),
-- Course 3 (BCS-053) - 2 class dates for enrolled students (5, 6, 8, 9)
(3, 5, '2026-10-08', 'Present', 'On time', 3),
(3, 6, '2026-10-08', 'Present', 'On time', 3),
(3, 8, '2026-10-08', 'Present', 'On time', 3),
(3, 9, '2026-10-08', 'Present', 'On time', 3),
(3, 5, '2026-10-15', 'Present', 'On time', 3),
(3, 6, '2026-10-15', 'Present', 'On time', 3),
(3, 8, '2026-10-15', 'Absent', NULL, 3),
(3, 9, '2026-10-15', 'Present', 'On time', 3);

-- 14. Notices & Announcements
INSERT INTO `notices` (`notice_id`, `title`, `description`, `author_id`, `audience`, `course_id`, `priority`, `status`, `published_at`) VALUES
(1, 'Welcome to IGNOU BCA Virtual Classroom Portal (2026-2027 Session)', 'All BCA learners and faculty counsellors of Regional Centre Patna (Study Centre 0500) are welcomed to the centralized Web-Based Virtual Classroom System. Please verify your enrolled courses, download study materials, and track assignment submission schedules regularly.', 1, 'all', NULL, 'important', 'published', '2026-09-05 09:00:00'),
(2, 'BCSP-064 Project Evaluation & Viva-Voce Guidelines', 'Final semester BCA learners are advised to ensure that their project implementation, SQL database schema, test case execution report, and signed project documentation strictly follow IGNOU SOCIS BCSP-064 guidelines.', 1, 'students', NULL, 'urgent', 'published', '2026-10-01 11:30:00'),
(3, 'BCS-051 TMA-01 Submission & Quiz-01 Schedule', 'Learners enrolled in BCS-051 (Introduction to Software Engineering) must complete Online Quiz 01 and upload their IEEE SRS assignment before the due date.', 2, 'course', 1, 'important', 'published', '2026-10-03 14:00:00'),
(4, 'MCS-023 Database Normalization Lab Doubt-Clearing Session', 'A special doubt-clearing session on BCNF normalization and foreign key constraints has been scheduled. Please review the uploaded Normalization Lecture Notes prior to the class.', 2, 'course', 2, 'normal', 'published', '2026-10-10 10:00:00'),
(5, 'Faculty Advisory: Publication of Evaluated Assignment Marks', 'All course teachers are requested to verify feedback remarks before switching assignment evaluations to the Published state.', 1, 'teachers', NULL, 'normal', 'published', '2026-10-12 16:00:00');

-- 15. Consolidated Results (Derived from published assignments, quiz scores, and attendance)
INSERT INTO `results` (`result_id`, `student_id`, `course_id`, `assignment_marks_obtained`, `assignment_marks_max`, `quiz_marks_obtained`, `quiz_marks_max`, `attendance_percentage`, `overall_percentage`, `grade`, `remarks`, `is_published`) VALUES
(1, 5, 1, 92.00, 100.00, 10.00, 10.00, 100.00, 92.73, 'A+', 'Distinction - Outstanding performance in SRS & SDLC', 1),
(2, 5, 2, 89.00, 100.00, 8.00, 10.00, 100.00, 88.18, 'A+', 'Distinction - Strong RDBMS and normalization skills', 1),
(3, 6, 1, 85.00, 100.00, 8.00, 10.00, 75.00, 84.55, 'A', 'First Division - Consistent academic progress', 1),
(4, 7, 1, 0.00, 100.00, 6.00, 10.00, 75.00, 60.00, 'B', 'Assignment submitted; evaluation pending', 1);

-- 16. Activity Logs
INSERT INTO `activity_logs` (`log_id`, `user_id`, `action`, `entity_type`, `entity_id`, `description`, `ip_address`, `created_at`) VALUES
(1, 1, 'SYSTEM_SEED', 'system', 1, 'Initialized institutional database with roles, courses, and sample academic records.', '127.0.0.1', '2026-09-01 09:00:00'),
(2, 1, 'COURSE_CREATE', 'course', 1, 'Created course BCS-051: Introduction to Software Engineering and assigned Prof. Krishan Dev Mishra.', '127.0.0.1', '2026-09-01 09:15:00'),
(3, 2, 'MATERIAL_UPLOAD', 'material', 1, 'Uploaded learning material: IEEE 830 SRS Standard & DFD Modelling Guide for BCS-051.', '127.0.0.1', '2026-09-10 11:00:00'),
(4, 5, 'ASSIGNMENT_SUBMIT', 'submission', 1, 'Student Sahil Alam (2200080265) submitted TMA-01 for BCS-051.', '127.0.0.1', '2026-10-12 14:20:00'),
(5, 2, 'SUBMISSION_EVALUATE', 'submission', 1, 'Prof. Krishan Dev Mishra evaluated and published marks (92/100) for Sahil Alam on TMA-01.', '127.0.0.1', '2026-10-15 11:05:00'),
(6, 5, 'QUIZ_ATTEMPT', 'attempt', 1, 'Student Sahil Alam completed Quiz 01 (BCS-051) with score 10.00/10.00 (100%).', '127.0.0.1', '2026-10-16 10:09:30');

-- 17. Application Settings
INSERT INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES
('institution_name', 'Indira Gandhi National Open University (IGNOU) - Study Centre 0500 (RC Patna)', 'Official institution title displayed across dashboards and reports'),
('academic_session', '2026-2027', 'Active academic session'),
('project_code', 'BCSP-064', 'BCA Final Semester Project Course Code'),
('min_attendance_percent', '75', 'Minimum recommended attendance percentage for learners'),
('pass_percentage', '40', 'Minimum overall percentage required to pass a course'),
('grading_scale_info', 'A+ (>=80%), A (70-79%), B (60-69%), C (50-59%), D (40-49%), F (<40%)', 'Documented IGNOU percentage-to-grade mapping used in result calculation'),
('allow_student_profile_edit', '1', 'Whether students can update their phone number and password');

SET FOREIGN_KEY_CHECKS = 1;
