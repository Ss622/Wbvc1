<?php
declare(strict_types=1);

/**
 * CLI Automated Test Runner for Web-Based Virtual Classroom System (BCSP-064)
 * Usage in XAMPP / PHP CLI:
 *   php tests/run.php
 */

use App\Core\Autoloader;
use App\Core\Env;
use Tests\Integration\WorkflowTestSuite;
use Tests\Unit\UnitTestSuite;

$root = dirname(__DIR__);
require_once $root . '/app/Core/Autoloader.php';
Autoloader::register();

require_once $root . '/app/Helpers/functions.php';
require_once __DIR__ . '/unit/UnitTestSuite.php';
require_once __DIR__ . '/integration/WorkflowTestSuite.php';

$envFile = is_file($root . '/.env') ? ($root . '/.env') : ($root . '/.env.example');
Env::load($envFile);

echo "========================================================================\n";
echo " WEB-BASED VIRTUAL CLASSROOM SYSTEM (BCSP-064) - AUTOMATED TEST RUNNER\n";
echo "========================================================================\n\n";

$unitResults = UnitTestSuite::run();
$passed = 0;
$total  = 0;

echo "--- 1. UNIT TESTS ---\n";
foreach ($unitResults as $r) {
    $total++;
    if ($r['passed']) {
        $passed++;
    }
    $badge = $r['passed'] ? '[PASS]' : '[FAIL]';
    printf("%s %-8s %s\n       Actual: %s\n", $badge, $r['id'], $r['name'], $r['actual']);
}

echo "\n--- 2. DATABASE INTEGRATION & WORKFLOW TESTS ---\n";
try {
    $intResults = WorkflowTestSuite::run();
    foreach ($intResults as $r) {
        $total++;
        if ($r['passed']) {
            $passed++;
        }
        $badge = $r['passed'] ? '[PASS]' : '[FAIL]';
        printf("%s %-8s %s\n       Actual: %s\n", $badge, $r['id'], $r['name'], $r['actual']);
    }
} catch (\Throwable $e) {
    echo "[INFO] Database integration suite requires active MySQL/SQLite connection: " . $e->getMessage() . "\n";
}

echo "\n========================================================================\n";
printf(" SUMMARY: %d / %d Automated Checks Passed\n", $passed, $total);
echo "========================================================================\n";
exit($passed === $total ? 0 : 1);
