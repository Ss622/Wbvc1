<?php
declare(strict_types=1);

namespace Tests\Unit;

use App\Core\Csrf;
use App\Services\ResultCalculationService;
use App\Validators\Validator;

/**
 * Unit Test Suite for Core Security, Validators, and Academic Calculation Logic.
 */
class UnitTestSuite
{
    public static function run(): array
    {
        $results = [];

        // UT-01: Password Hashing & Verification
        $hash = password_hash('Student@123', PASSWORD_DEFAULT);
        $passOk = password_verify('Student@123', $hash) && !password_verify('WrongPass', $hash);
        $results[] = [
            'id'       => 'UT-01',
            'name'     => 'Bcrypt password_hash() and password_verify() validation',
            'passed'   => $passOk,
            'expected' => 'Valid password returns true; wrong password returns false',
            'actual'   => $passOk ? 'Verified successfully' : 'Verification failed',
        ];

        // UT-02: CSRF Token Generation & Timing-Safe Verification
        $_SESSION = [];
        $token = Csrf::token();
        $csrfOk = (strlen($token) === 64) && Csrf::verify($token) && !Csrf::verify('invalid_token');
        $results[] = [
            'id'       => 'UT-02',
            'name'     => 'CSRF token generation and hash_equals() verification',
            'passed'   => $csrfOk,
            'expected' => '64-char hex token matches session and rejects forged token',
            'actual'   => $csrfOk ? '64-char token verified and forged token rejected' : 'CSRF check failed',
        ];

        // UT-03: Server-Side Input Validator (Required, Email, Numeric Range, Date Range)
        $v1 = new Validator([
            'name'       => 'Sahil Alam',
            'email'      => 'sahil.alam@ignou-vc.edu.in',
            'marks'      => '92',
            'issue_date' => '2026-09-15',
            'due_date'   => '2026-12-15',
        ]);
        $v1->required('name', 'Name')
           ->email('email', 'Email')
           ->numericRange('marks', 0, 100, 'Marks')
           ->dateAfterOrEqual('issue_date', 'due_date', 'Issue Date', 'Due Date');

        $v2 = new Validator([
            'name'       => '',
            'email'      => 'not-an-email',
            'marks'      => '140',
            'issue_date' => '2026-12-20',
            'due_date'   => '2026-10-01',
        ]);
        $v2->required('name', 'Name')
           ->email('email', 'Email')
           ->numericRange('marks', 0, 100, 'Marks')
           ->dateAfterOrEqual('issue_date', 'due_date', 'Issue Date', 'Due Date');

        $valOk = $v1->passes() && $v2->fails() && count($v2->errors()) === 4;
        $results[] = [
            'id'       => 'UT-03',
            'name'     => 'Validator class enforces required, email, max_marks, and date ranges',
            'passed'   => $valOk,
            'expected' => 'Valid payload passes; invalid payload catches all 4 field errors',
            'actual'   => $valOk ? 'All 4 validation rules enforced accurately' : 'Validator mismatch',
        ];

        // UT-04: Result Grade Mapping Formula
        [$g1] = ResultCalculationService::mapGrade(88.5, true);
        [$g2] = ResultCalculationService::mapGrade(74.0, true);
        [$g3] = ResultCalculationService::mapGrade(35.0, true);
        $gradeOk = ($g1 === 'A+' && $g2 === 'A' && $g3 === 'F');
        $results[] = [
            'id'       => 'UT-04',
            'name'     => 'IGNOU BCA percentage-to-grade mapping (A+, A, B, C, D, F)',
            'passed'   => $gradeOk,
            'expected' => '88.5% -> A+, 74.0% -> A, 35.0% -> F',
            'actual'   => "{$g1}, {$g2}, {$g3}",
        ];

        // UT-05: XSS Output Escaping Helper e()
        $malicious = '<script>alert("xss")</script>';
        $escaped = e($malicious);
        $xssOk = ($escaped === '&lt;script&gt;alert(&quot;xss&quot;)&lt;/script&gt;');
        $results[] = [
            'id'       => 'UT-05',
            'name'     => 'Output escaping helper e() neutralizes XSS payloads',
            'passed'   => $xssOk,
            'expected' => 'HTML entities encoded safely',
            'actual'   => $escaped,
        ];

        return $results;
    }
}
