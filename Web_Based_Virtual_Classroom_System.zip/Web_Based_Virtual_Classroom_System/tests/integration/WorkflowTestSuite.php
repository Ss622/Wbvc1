<?php
declare(strict_types=1);

namespace Tests\Integration;

use App\Core\Database;
use App\Models\AssignmentModel;
use App\Models\AttemptModel;
use App\Models\AttendanceModel;
use App\Models\CourseModel;
use App\Models\EnrollmentModel;
use App\Models\MaterialModel;
use App\Models\NoticeModel;
use App\Models\QuestionModel;
use App\Models\QuizModel;
use App\Models\ResultModel;
use App\Models\SubmissionModel;
use App\Models\UserModel;
use App\Services\QuizScoringService;
use App\Services\ResultCalculationService;

/**
 * Integration Test Suite executing Workflows A through F against the database.
 */
class WorkflowTestSuite
{
    public static function run(): array
    {
        $results = [];
        $db = Database::getConnection();

        // WORKFLOW A: Admin verifies teacher -> creates course -> assigns teacher -> enrolls student
        $userModel       = new UserModel();
        $courseModel     = new CourseModel();
        $enrollmentModel = new EnrollmentModel();

        $admin   = $userModel->findByEmailOrEnrollment('admin@ignou-vc.edu.in');
        $teacher = $userModel->findByEmailOrEnrollment('krishan.mishra@ignou-vc.edu.in');
        $student = $userModel->findByEmailOrEnrollment('sahil.alam@ignou-vc.edu.in');

        $wfA = ($admin !== null && $teacher !== null && $student !== null)
            && $enrollmentModel->isEnrolled((int) $student['user_id'], 1);
        $results[] = [
            'id'       => 'IT-WF-A',
            'name'     => 'Workflow A: Admin user/course setup, teacher assignment, and student enrollment',
            'passed'   => $wfA,
            'expected' => 'Admin, Teacher, and Student exist and Student is actively enrolled in BCS-051',
            'actual'   => $wfA ? 'Verified in relational database' : 'Failed',
        ];

        // WORKFLOW B: Teacher uploads material -> Student accesses permitted material
        $materialModel = new MaterialModel();
        $studentMats = $materialModel->getAll(['student_id' => (int) $student['user_id']]);
        $wfB = count($studentMats) >= 4;
        $results[] = [
            'id'       => 'IT-WF-B',
            'name'     => 'Workflow B: Teacher material upload and enrolled student material retrieval',
            'passed'   => $wfB,
            'expected' => 'Student retrieves materials only for enrolled published courses',
            'actual'   => count($studentMats) . ' authorized materials retrieved',
        ];

        // WORKFLOW C: Assignment -> Student submission -> Teacher evaluation -> Published result
        $subModel = new SubmissionModel();
        $sub = $subModel->findByAssignmentAndStudent(1, (int) $student['user_id']);
        $wfC = ($sub !== null && $sub['status'] === 'published' && (float) $sub['marks'] === 92.00);
        $results[] = [
            'id'       => 'IT-WF-C',
            'name'     => 'Workflow C: Assignment creation, student submission, teacher evaluation & mark publication',
            'passed'   => $wfC,
            'expected' => 'Sahil Alam TMA-01 submission evaluated and published with 92.00/100 marks',
            'actual'   => $wfC ? "Marks: {$sub['marks']}/100 (Status: {$sub['status']})" : 'Failed',
        ];

        // WORKFLOW D: Teacher creates quiz -> Student attempts quiz -> Backend calculates score
        $attemptModel = new AttemptModel();
        $attempts = $attemptModel->getAll(['student_id' => (int) $student['user_id'], 'quiz_id' => 1]);
        $wfD = !empty($attempts) && (float) $attempts[0]['score'] === 10.00;
        $results[] = [
            'id'       => 'IT-WF-D',
            'name'     => 'Workflow D: Objective quiz creation, student attempt, and server-side score calculation',
            'passed'   => $wfD,
            'expected' => 'Quiz 01 scored 10.00/10.00 (100%) on backend',
            'actual'   => $wfD ? "Score: {$attempts[0]['score']}/{$attempts[0]['total_marks']} ({$attempts[0]['percentage']}%)" : 'Failed',
        ];

        // WORKFLOW E: Teacher records attendance -> Student views attendance percentage
        $attModel = new AttendanceModel();
        $pct = $attModel->calculateStudentCoursePercentage((int) $student['user_id'], 1);
        $wfE = ($pct === 100.00);
        $results[] = [
            'id'       => 'IT-WF-E',
            'name'     => 'Workflow E: Attendance recording and student course attendance percentage calculation',
            'passed'   => $wfE,
            'expected' => '100.00% attendance across 4 recorded classes in BCS-051',
            'actual'   => "{$pct}%",
        ];

        // WORKFLOW F: Notice published -> Visible to target students and teachers
        $noticeModel = new NoticeModel();
        $stNotices = $noticeModel->getVisibleForStudent((int) $student['user_id']);
        $wfF = count($stNotices) >= 4;
        $results[] = [
            'id'       => 'IT-WF-F',
            'name'     => 'Workflow F: Institutional and course notice publication and role-filtered visibility',
            'passed'   => $wfF,
            'expected' => 'Student sees global, student-role, and enrolled-course notices (excludes teacher-only notices)',
            'actual'   => count($stNotices) . ' relevant notices visible',
        ];

        return $results;
    }
}
