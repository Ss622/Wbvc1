# Application Security Architecture (`SECURITY.md`)

The **Web-Based Virtual Classroom System (BCSP-064)** treats web application security and academic data privacy as core engineering requirements.

## 1. Implemented Security Controls

1. **Password Hashing (`password_hash` & `password_verify`):**
   - Passwords are never stored or logged in plaintext.
   - All passwords in `UserModel` and `database/seed.sql` use strong salted bcrypt hashes (`$2y$10$...`).
2. **Brute-Force Login Rate Limiting (`login_attempts`):**
   - Failed login attempts are recorded by email/identifier and IP address.
   - Exceeding `MAX_LOGIN_ATTEMPTS` (default: 5 attempts within 15 minutes) temporarily locks login attempts for that account/IP.
3. **Account Enumeration Prevention:**
   - Failed logins return a generic message (`Invalid login credentials...`) without revealing whether a specific email address or enrolment number exists.
4. **Session Hardening & Fixation Defense (`app/Core/Session.php`):**
   - Enables `session.use_strict_mode`, `session.use_only_cookies`, `HttpOnly`, and `SameSite=Lax`.
   - Calls `session_regenerate_id(true)` immediately upon login and enforces inactivity timeout (`SESSION_LIFETIME = 1800` seconds).
5. **Server-Side Role-Based Access Control (`RoleMiddleware` & Controller Guards):**
   - Every protected route in `routes/web.php` enforces `AuthMiddleware` and `RoleMiddleware` on the server.
   - **Teacher Isolation:** `TeacherController::verifyCourseOwnership()` verifies that `courses.teacher_id === Auth::id()` on every course, material, assignment, submission, quiz, question, attendance, and report operation.
   - **Student Isolation:** `StudentController::verifyEnrollment()` verifies active enrollment in `enrollments` and restricts submission, attendance, quiz attempt, and result queries to `student_id === Auth::id()`.
   - **Unpublished Marks Protection:** Student views strip `marks` and `feedback` from any assignment submission whose status is not `'published'`.
   - **Quiz Answer Protection:** `QuestionModel::getByQuiz($quizId, false)` strips `correct_option`, `explanation`, and `is_correct` before rendering quiz questions to a student.
6. **Synchronizer Token CSRF Protection (`Csrf` & `CsrfMiddleware`):**
   - Every state-changing `POST` request requires a per-session 256-bit cryptographic `_csrf_token` validated via `hash_equals()`.
7. **SQL Injection Prevention (PDO Prepared Statements):**
   - `Database.php` disables emulated prepares (`PDO::ATTR_EMULATE_PREPARES => false`) and all 16 Models use parameterized `PDO::prepare()` queries.
8. **XSS Output Escaping:**
   - All dynamic data rendered in HTML views is escaped through the `e()` helper (`htmlspecialchars(..., ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')`).
9. **Secure File Uploads & Protected Downloads (`FileUpload.php` & `DownloadController.php`):**
   - Validates extension whitelist, maximum file size (10 MB), and actual content MIME type via PHP `finfo(FILEINFO_MIME_TYPE)`.
   - Blocks executable double extensions (`.php`, `.phtml`, `.phar`, `.exe`, `.sh`, `.js`, etc.).
   - Generates random server-side filenames (`YYYYmmdd_HHMMSS_<24-hex>.ext`) stored outside `public/` inside `storage/uploads/` (protected by `.htaccess`).
   - Downloads are streamed through `DownloadController`, which verifies role/enrollment permissions and confines file paths via `realpath()`.

## 2. Production Deployment Responsibilities
When moving from a local XAMPP environment to an institutional production server:
- Enable HTTPS/TLS and set `APP_ENV="production"` and `APP_DEBUG="false"` in `.env`.
- Point Apache's `DocumentRoot` directly to the `public/` directory so `app/`, `config/`, `database/`, and `storage/` sit outside the web root even if `.htaccess` is disabled.
- Use a dedicated MySQL database user with strong credentials instead of `root`.
- Schedule automated daily `mysqldump` backups of `virtual_classroom_db` and `storage/uploads/`.
