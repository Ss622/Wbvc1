<?php
declare(strict_types=1);

namespace App\Validators;

/**
 * Reusable Server-Side Input Validator.
 */
class Validator
{
    private array $errors = [];
    private array $data;

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public function required(string $field, string $label): self
    {
        $val = trim((string) ($this->data[$field] ?? ''));
        if ($val === '') {
            $this->errors[$field] = "{$label} is required.";
        }
        return $this;
    }

    public function email(string $field, string $label = 'Email address'): self
    {
        $val = trim((string) ($this->data[$field] ?? ''));
        if ($val !== '' && !filter_var($val, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = "Please enter a valid {$label}.";
        }
        return $this;
    }

    public function minLength(string $field, int $min, string $label): self
    {
        $val = trim((string) ($this->data[$field] ?? ''));
        if ($val !== '' && mb_strlen($val) < $min) {
            $this->errors[$field] = "{$label} must be at least {$min} characters long.";
        }
        return $this;
    }

    public function maxLength(string $field, int $max, string $label): self
    {
        $val = trim((string) ($this->data[$field] ?? ''));
        if ($val !== '' && mb_strlen($val) > $max) {
            $this->errors[$field] = "{$label} must not exceed {$max} characters.";
        }
        return $this;
    }

    public function numericRange(string $field, float $min, float $max, string $label): self
    {
        $val = $this->data[$field] ?? '';
        if ($val === '' || !is_numeric($val)) {
            $this->errors[$field] = "{$label} must be a valid number.";
            return $this;
        }
        $num = (float) $val;
        if ($num < $min || $num > $max) {
            $this->errors[$field] = "{$label} must be between {$min} and {$max}.";
        }
        return $this;
    }

    public function inList(string $field, array $allowed, string $label): self
    {
        $val = (string) ($this->data[$field] ?? '');
        if ($val !== '' && !in_array($val, $allowed, true)) {
            $this->errors[$field] = "Invalid selection for {$label}.";
        }
        return $this;
    }

    public function date(string $field, string $label): self
    {
        $val = trim((string) ($this->data[$field] ?? ''));
        if ($val !== '' && strtotime($val) === false) {
            $this->errors[$field] = "{$label} must be a valid date.";
        }
        return $this;
    }

    public function dateAfterOrEqual(string $startField, string $endField, string $startLabel, string $endLabel): self
    {
        $s = strtotime((string) ($this->data[$startField] ?? ''));
        $e = strtotime((string) ($this->data[$endField] ?? ''));
        if ($s !== false && $e !== false && $e < $s) {
            $this->errors[$endField] = "{$endLabel} must be on or after {$startLabel}.";
        }
        return $this;
    }

    public function addError(string $field, string $message): void
    {
        $this->errors[$field] = $message;
    }

    public function passes(): bool
    {
        return empty($this->errors);
    }

    public function fails(): bool
    {
        return !empty($this->errors);
    }

    public function errors(): array
    {
        return $this->errors;
    }

    public function firstError(): string
    {
        return (string) (reset($this->errors) ?: 'Validation failed.');
    }
}
