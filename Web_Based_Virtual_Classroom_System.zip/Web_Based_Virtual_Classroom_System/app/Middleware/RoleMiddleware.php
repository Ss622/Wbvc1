<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Logger;
use App\Core\View;

/**
 * Enforces strict server-side Role-Based Access Control (RBAC).
 */
class RoleMiddleware
{
    public static function handle(array $allowedRoles): void
    {
        $currentRole = Auth::role();
        if ($currentRole === null || !in_array($currentRole, $allowedRoles, true)) {
            Logger::warning(sprintf(
                'Unauthorized access attempt by user_id=%s (role=%s) to route requiring [%s]',
                (string) Auth::id(),
                (string) $currentRole,
                implode(',', $allowedRoles)
            ));
            http_response_code(403);
            View::render('errors/403', [
                'pageTitle' => '403 — Unauthorized Access',
                'message'   => 'Access Denied: Your account role (' . htmlspecialchars((string) $currentRole) . ') is not permitted to perform this operation.',
            ], 'layouts/app');
            exit;
        }
    }
}
