<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Core\Csrf;
use App\Core\Flash;
use App\Core\Auth;

/**
 * Verifies CSRF token on all state-changing HTTP POST requests.
 */
class CsrfMiddleware
{
    public static function handle(): void
    {
        $token = $_POST['_csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
        if (!Csrf::verify(is_string($token) ? $token : null)) {
            http_response_code(419);
            Flash::set('danger', 'Security token validation failed or form session expired. Please try submitting the form again.');
            $fallback = Auth::check() ? Auth::dashboardRoute() : 'login';
            header('Location: ' . route_url($fallback));
            exit;
        }
    }
}
