<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Flash;

/**
 * Ensures the user is authenticated before accessing protected routes.
 */
class AuthMiddleware
{
    public static function handle(): void
    {
        if (!Auth::check()) {
            Flash::set('warning', 'Please sign in with your institutional account to access that page.');
            header('Location: ' . route_url('login'));
            exit;
        }
    }
}
