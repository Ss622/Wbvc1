<?php
declare(strict_types=1);

namespace App\Models;

class RoleModel extends BaseModel
{
    public function getAll(): array
    {
        $stmt = $this->db->query('SELECT * FROM roles ORDER BY role_id ASC');
        return $stmt->fetchAll();
    }

    public function findById(int $roleId): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM roles WHERE role_id = :id LIMIT 1');
        $stmt->execute(['id' => $roleId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }
}
