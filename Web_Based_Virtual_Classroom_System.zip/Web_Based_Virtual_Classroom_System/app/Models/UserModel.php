<?php
declare(strict_types=1);

namespace App\Models;

class UserModel extends BaseModel
{
    public function findByEmailOrEnrollment(string $identifier): ?array
    {
        $sql = 'SELECT u.*, r.role_name, r.role_slug
                FROM users u
                INNER JOIN roles r ON u.role_id = r.role_id
                WHERE u.email = :ident1 OR u.enrollment_no = :ident2
                LIMIT 1';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'ident1' => $identifier,
            'ident2' => $identifier,
        ]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function findById(int $userId): ?array
    {
        $sql = 'SELECT u.*, r.role_name, r.role_slug
                FROM users u
                INNER JOIN roles r ON u.role_id = r.role_id
                WHERE u.user_id = :id
                LIMIT 1';
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $userId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function emailExists(string $email, ?int $excludeUserId = null): bool
    {
        $sql = 'SELECT COUNT(*) FROM users WHERE email = :email';
        $params = ['email' => $email];
        if ($excludeUserId !== null) {
            $sql .= ' AND user_id != :uid';
            $params['uid'] = $excludeUserId;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return ((int) $stmt->fetchColumn()) > 0;
    }

    public function enrollmentNoExists(string $enrollmentNo, ?int $excludeUserId = null): bool
    {
        if (trim($enrollmentNo) === '') {
            return false;
        }
        $sql = 'SELECT COUNT(*) FROM users WHERE enrollment_no = :eno';
        $params = ['eno' => $enrollmentNo];
        if ($excludeUserId !== null) {
            $sql .= ' AND user_id != :uid';
            $params['uid'] = $excludeUserId;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return ((int) $stmt->fetchColumn()) > 0;
    }

    public function getAll(array $filters = []): array
    {
        $sql = 'SELECT u.*, r.role_name, r.role_slug
                FROM users u
                INNER JOIN roles r ON u.role_id = r.role_id
                WHERE 1=1';
        $params = [];

        if (!empty($filters['role_slug'])) {
            $sql .= ' AND r.role_slug = :role_slug';
            $params['role_slug'] = $filters['role_slug'];
        }
        if (!empty($filters['role_id'])) {
            $sql .= ' AND u.role_id = :role_id';
            $params['role_id'] = (int) $filters['role_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND u.status = :status';
            $params['status'] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (u.name LIKE :q1 OR u.email LIKE :q2 OR u.enrollment_no LIKE :q3 OR u.department LIKE :q4)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
            $params['q4'] = $term;
        }

        $sql .= ' ORDER BY u.role_id ASC, u.name ASC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getActiveTeachers(): array
    {
        return $this->getAll(['role_slug' => 'TEACHER', 'status' => 'active']);
    }

    public function getActiveStudents(): array
    {
        return $this->getAll(['role_slug' => 'STUDENT', 'status' => 'active']);
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO users (role_id, enrollment_no, name, email, phone, department, qualification, password_hash, status)
                VALUES (:role_id, :enrollment_no, :name, :email, :phone, :department, :qualification, :password_hash, :status)';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'role_id'       => (int) $data['role_id'],
            'enrollment_no' => !empty($data['enrollment_no']) ? trim($data['enrollment_no']) : null,
            'name'          => trim($data['name']),
            'email'         => strtolower(trim($data['email'])),
            'phone'         => !empty($data['phone']) ? trim($data['phone']) : null,
            'department'    => !empty($data['department']) ? trim($data['department']) : 'School of Computer and Information Sciences',
            'qualification' => !empty($data['qualification']) ? trim($data['qualification']) : null,
            'password_hash' => password_hash($data['password'], PASSWORD_DEFAULT),
            'status'        => $data['status'] ?? 'active',
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $userId, array $data): bool
    {
        $sql = 'UPDATE users
                SET role_id = :role_id,
                    enrollment_no = :enrollment_no,
                    name = :name,
                    email = :email,
                    phone = :phone,
                    department = :department,
                    qualification = :qualification,
                    status = :status,
                    updated_at = CURRENT_TIMESTAMP
                WHERE user_id = :user_id';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'role_id'       => (int) $data['role_id'],
            'enrollment_no' => !empty($data['enrollment_no']) ? trim($data['enrollment_no']) : null,
            'name'          => trim($data['name']),
            'email'         => strtolower(trim($data['email'])),
            'phone'         => !empty($data['phone']) ? trim($data['phone']) : null,
            'department'    => !empty($data['department']) ? trim($data['department']) : null,
            'qualification' => !empty($data['qualification']) ? trim($data['qualification']) : null,
            'status'        => $data['status'] ?? 'active',
            'user_id'       => $userId,
        ]);
    }

    public function updateProfile(int $userId, array $data): bool
    {
        $sql = 'UPDATE users
                SET name = :name,
                    phone = :phone,
                    department = :department,
                    qualification = :qualification,
                    updated_at = CURRENT_TIMESTAMP
                WHERE user_id = :user_id';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'name'          => trim($data['name']),
            'phone'         => !empty($data['phone']) ? trim($data['phone']) : null,
            'department'    => !empty($data['department']) ? trim($data['department']) : null,
            'qualification' => !empty($data['qualification']) ? trim($data['qualification']) : null,
            'user_id'       => $userId,
        ]);
    }

    public function updatePassword(int $userId, string $newPassword): bool
    {
        $stmt = $this->db->prepare('UPDATE users SET password_hash = :hash, updated_at = CURRENT_TIMESTAMP WHERE user_id = :id');
        return $stmt->execute([
            'hash' => password_hash($newPassword, PASSWORD_DEFAULT),
            'id'   => $userId,
        ]);
    }

    public function toggleStatus(int $userId): bool
    {
        $user = $this->findById($userId);
        if (!$user) {
            return false;
        }
        $next = ($user['status'] === 'active') ? 'inactive' : 'active';
        $stmt = $this->db->prepare('UPDATE users SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE user_id = :id');
        return $stmt->execute(['status' => $next, 'id' => $userId]);
    }

    public function delete(int $userId): bool
    {
        $stmt = $this->db->prepare('DELETE FROM users WHERE user_id = :id');
        return $stmt->execute(['id' => $userId]);
    }

    public function touchLastLogin(int $userId): void
    {
        $stmt = $this->db->prepare('UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE user_id = :id');
        $stmt->execute(['id' => $userId]);
    }

    public function countByRoleSlug(string $roleSlug): int
    {
        $stmt = $this->db->prepare(
            'SELECT COUNT(*) FROM users u INNER JOIN roles r ON u.role_id = r.role_id WHERE r.role_slug = :slug'
        );
        $stmt->execute(['slug' => $roleSlug]);
        return (int) $stmt->fetchColumn();
    }

    public function isLockedOut(string $email, string $ip, int $maxAttempts, int $lockoutMinutes): bool
    {
        $cutoff = date('Y-m-d H:i:s', time() - ($lockoutMinutes * 60));
        $stmt = $this->db->prepare(
            'SELECT COUNT(*) FROM login_attempts WHERE (email = :email OR ip_address = :ip) AND attempted_at >= :cutoff'
        );
        $stmt->execute([
            'email'  => strtolower($email),
            'ip'     => $ip,
            'cutoff' => $cutoff,
        ]);
        return ((int) $stmt->fetchColumn()) >= $maxAttempts;
    }

    public function recordFailedLogin(string $email, string $ip): void
    {
        $stmt = $this->db->prepare('INSERT INTO login_attempts (email, ip_address) VALUES (:email, :ip)');
        $stmt->execute([
            'email' => strtolower($email),
            'ip'    => $ip,
        ]);
    }

    public function clearFailedLogins(string $email, string $ip): void
    {
        $stmt = $this->db->prepare('DELETE FROM login_attempts WHERE email = :email OR ip_address = :ip');
        $stmt->execute([
            'email' => strtolower($email),
            'ip'    => $ip,
        ]);
    }
}
