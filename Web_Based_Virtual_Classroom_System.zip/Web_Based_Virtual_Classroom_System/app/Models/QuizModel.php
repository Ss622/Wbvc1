<?php
declare(strict_types=1);

namespace App\Models;

class QuizModel extends BaseModel
{
    public function getAll(array $filters = []): array
    {
        $sql = 'SELECT q.*,
                       c.course_code,
                       c.course_name,
                       c.teacher_id,
                       u.name AS creator_name,
                       (SELECT COUNT(*) FROM questions qn WHERE qn.quiz_id = q.quiz_id) AS question_count,
                       (SELECT COUNT(*) FROM attempts atp WHERE atp.quiz_id = q.quiz_id AND atp.status = 'completed') AS attempt_count
                FROM quizzes q
                INNER JOIN courses c ON q.course_id = c.course_id
                INNER JOIN users u ON q.created_by = u.user_id
                WHERE 1=1';
        $params = [];

        if (!empty($filters['course_id'])) {
            $sql .= ' AND q.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['teacher_id'])) {
            $sql .= ' AND c.teacher_id = :teacher_id';
            $params['teacher_id'] = (int) $filters['teacher_id'];
        }
        if (isset($filters['is_published']) && $filters['is_published'] !== '') {
            $sql .= ' AND q.is_published = :is_published';
            $params['is_published'] = (int) $filters['is_published'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (q.title LIKE :q1 OR q.description LIKE :q2 OR c.course_code LIKE :q3)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
        }

        $sql .= ' ORDER BY q.created_at DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getForStudent(int $studentId, array $filters = []): array
    {
        $sql = 'SELECT q.*,
                       c.course_code,
                       c.course_name,
                       (SELECT COUNT(*) FROM questions qn WHERE qn.quiz_id = q.quiz_id) AS question_count,
                       (SELECT COUNT(*) FROM attempts a WHERE a.quiz_id = q.quiz_id AND a.student_id = :sid1 AND a.status = 'completed') AS student_attempts,
                       (SELECT MAX(a2.score) FROM attempts a2 WHERE a2.quiz_id = q.quiz_id AND a2.student_id = :sid2 AND a2.status = 'completed') AS best_score
                FROM quizzes q
                INNER JOIN courses c ON q.course_id = c.course_id
                INNER JOIN enrollments e ON e.course_id = c.course_id AND e.student_id = :sid3 AND e.enrollment_status = 'active'
                WHERE q.is_published = 1
                  AND c.status = 'published'';
        $params = [
            'sid1' => $studentId,
            'sid2' => $studentId,
            'sid3' => $studentId,
        ];

        if (!empty($filters['course_id'])) {
            $sql .= ' AND q.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (q.title LIKE :q1 OR c.course_code LIKE :q2)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
        }

        $sql .= ' ORDER BY q.start_time DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function findById(int $quizId): ?array
    {
        $sql = 'SELECT q.*,
                       c.course_code,
                       c.course_name,
                       c.teacher_id,
                       (SELECT COUNT(*) FROM questions qn WHERE qn.quiz_id = q.quiz_id) AS question_count
                FROM quizzes q
                INNER JOIN courses c ON q.course_id = c.course_id
                WHERE q.quiz_id = :id
                LIMIT 1';
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $quizId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO quizzes (course_id, created_by, title, description, total_marks, duration_minutes, start_time, end_time, allowed_attempts, is_published, results_published)
                VALUES (:course_id, :created_by, :title, :description, :total_marks, :duration_minutes, :start_time, :end_time, :allowed_attempts, :is_published, :results_published)';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'course_id'         => (int) $data['course_id'],
            'created_by'        => (int) $data['created_by'],
            'title'             => trim($data['title']),
            'description'       => trim($data['description'] ?? ''),
            'total_marks'       => (float) ($data['total_marks'] ?? 0),
            'duration_minutes'  => (int) ($data['duration_minutes'] ?? 20),
            'start_time'        => $data['start_time'],
            'end_time'          => $data['end_time'],
            'allowed_attempts'  => (int) ($data['allowed_attempts'] ?? 1),
            'is_published'      => (int) ($data['is_published'] ?? 1),
            'results_published' => (int) ($data['results_published'] ?? 1),
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $quizId, array $data): bool
    {
        $sql = 'UPDATE quizzes
                SET course_id = :course_id,
                    title = :title,
                    description = :description,
                    duration_minutes = :duration_minutes,
                    start_time = :start_time,
                    end_time = :end_time,
                    allowed_attempts = :allowed_attempts,
                    is_published = :is_published,
                    results_published = :results_published,
                    updated_at = CURRENT_TIMESTAMP
                WHERE quiz_id = :id';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'course_id'         => (int) $data['course_id'],
            'title'             => trim($data['title']),
            'description'       => trim($data['description'] ?? ''),
            'duration_minutes'  => (int) $data['duration_minutes'],
            'start_time'        => $data['start_time'],
            'end_time'          => $data['end_time'],
            'allowed_attempts'  => (int) $data['allowed_attempts'],
            'is_published'      => (int) ($data['is_published'] ?? 1),
            'results_published' => (int) ($data['results_published'] ?? 1),
            'id'                => $quizId,
        ]);
    }

    public function syncTotalMarks(int $quizId): void
    {
        $stmt = $this->db->prepare('SELECT COALESCE(SUM(marks), 0) FROM questions WHERE quiz_id = :qid');
        $stmt->execute(['qid' => $quizId]);
        $total = (float) $stmt->fetchColumn();

        $upd = $this->db->prepare('UPDATE quizzes SET total_marks = :total WHERE quiz_id = :qid');
        $upd->execute(['total' => $total, 'qid' => $quizId]);
    }

    public function delete(int $quizId): bool
    {
        $stmt = $this->db->prepare('DELETE FROM quizzes WHERE quiz_id = :id');
        return $stmt->execute(['id' => $quizId]);
    }

    public function countAll(): int
    {
        return (int) $this->db->query('SELECT COUNT(*) FROM quizzes')->fetchColumn();
    }
}
