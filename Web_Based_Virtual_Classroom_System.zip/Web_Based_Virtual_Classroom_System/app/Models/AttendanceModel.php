<?php
declare(strict_types=1);

namespace App\Models;

class AttendanceModel extends BaseModel
{
    public function getRecordsForCourseAndDate(int $courseId, string $classDate): array
    {
        $stmt = $this->db->prepare('SELECT * FROM attendance WHERE course_id = :cid AND class_date = :cdate');
        $stmt->execute(['cid' => $courseId, 'cdate' => $classDate]);
        $rows = $stmt->fetchAll();
        $map = [];
        foreach ($rows as $row) {
            $map[(int) $row['student_id']] = $row;
        }
        return $map;
    }

    public function saveBatchAttendance(int $courseId, string $classDate, array $studentStatuses, array $remarks, int $recordedBy): void
    {
        $this->db->beginTransaction();
        try {
            $checkStmt = $this->db->prepare(
                'SELECT attendance_id FROM attendance WHERE course_id = :cid AND student_id = :sid AND class_date = :cdate LIMIT 1'
            );
            $insertStmt = $this->db->prepare(
                'INSERT INTO attendance (course_id, student_id, class_date, status, remarks, recorded_by)
                 VALUES (:cid, :sid, :cdate, :status, :remarks, :by)'
            );
            $updateStmt = $this->db->prepare(
                'UPDATE attendance
                 SET status = :status, remarks = :remarks, recorded_by = :by, updated_at = CURRENT_TIMESTAMP
                 WHERE attendance_id = :id'
            );

            foreach ($studentStatuses as $studentId => $status) {
                $sid = (int) $studentId;
                $cleanStatus = ($status === 'Absent') ? 'Absent' : 'Present';
                $note = isset($remarks[$sid]) ? trim((string) $remarks[$sid]) : null;

                $checkStmt->execute(['cid' => $courseId, 'sid' => $sid, 'cdate' => $classDate]);
                $existingId = $checkStmt->fetchColumn();

                if ($existingId) {
                    $updateStmt->execute([
                        'status'  => $cleanStatus,
                        'remarks' => $note,
                        'by'      => $recordedBy,
                        'id'      => (int) $existingId,
                    ]);
                } else {
                    $insertStmt->execute([
                        'cid'     => $courseId,
                        'sid'     => $sid,
                        'cdate'   => $classDate,
                        'status'  => $cleanStatus,
                        'remarks' => $note,
                        'by'      => $recordedBy,
                    ]);
                }
            }

            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function getCourseAttendanceSummary(int $courseId): array
    {
        $sql = 'SELECT u.user_id AS student_id,
                       u.name AS student_name,
                       u.enrollment_no,
                       u.email,
                       COUNT(a.attendance_id) AS total_classes,
                       SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_classes,
                       SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_classes
                FROM enrollments e
                INNER JOIN users u ON e.student_id = u.user_id
                LEFT JOIN attendance a ON a.course_id = e.course_id AND a.student_id = e.student_id
                WHERE e.course_id = :cid AND e.enrollment_status = 'active'
                GROUP BY u.user_id, u.name, u.enrollment_no, u.email
                ORDER BY u.name ASC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['cid' => $courseId]);
        $rows = $stmt->fetchAll();

        foreach ($rows as &$r) {
            $total = (int) $r['total_classes'];
            $present = (int) $r['present_classes'];
            $r['percentage'] = $total > 0 ? round(($present / $total) * 100, 2) : 0.00;
        }
        return $rows;
    }

    public function getStudentCourseSummary(int $studentId): array
    {
        $sql = 'SELECT c.course_id,
                       c.course_code,
                       c.course_name,
                       u.name AS teacher_name,
                       COUNT(a.attendance_id) AS total_classes,
                       SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_classes,
                       SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_classes
                FROM enrollments e
                INNER JOIN courses c ON e.course_id = c.course_id
                LEFT JOIN users u ON c.teacher_id = u.user_id
                LEFT JOIN attendance a ON a.course_id = c.course_id AND a.student_id = e.student_id
                WHERE e.student_id = :sid AND e.enrollment_status = 'active' AND c.status = 'published'
                GROUP BY c.course_id, c.course_code, c.course_name, u.name
                ORDER BY c.course_code ASC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['sid' => $studentId]);
        $rows = $stmt->fetchAll();

        foreach ($rows as &$r) {
            $total = (int) $r['total_classes'];
            $present = (int) $r['present_classes'];
            $r['percentage'] = $total > 0 ? round(($present / $total) * 100, 2) : 0.00;
        }
        return $rows;
    }

    public function getStudentAttendanceHistory(int $studentId, ?int $courseId = null): array
    {
        $sql = 'SELECT a.*, c.course_code, c.course_name, u.name AS recorded_by_name
                FROM attendance a
                INNER JOIN courses c ON a.course_id = c.course_id
                INNER JOIN users u ON a.recorded_by = u.user_id
                WHERE a.student_id = :sid';
        $params = ['sid' => $studentId];
        if ($courseId !== null && $courseId > 0) {
            $sql .= ' AND a.course_id = :cid';
            $params['cid'] = $courseId;
        }
        $sql .= ' ORDER BY a.class_date DESC, c.course_code ASC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function calculateStudentCoursePercentage(int $studentId, int $courseId): float
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present
             FROM attendance WHERE student_id = :sid AND course_id = :cid"
        );
        $stmt->execute(['sid' => $studentId, 'cid' => $courseId]);
        $row = $stmt->fetch();
        $total = (int) ($row['total'] ?? 0);
        $present = (int) ($row['present'] ?? 0);
        return $total > 0 ? round(($present / $total) * 100, 2) : 0.00;
    }

    public function calculateStudentOverallPercentage(int $studentId): float
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present
             FROM attendance WHERE student_id = :sid"
        );
        $stmt->execute(['sid' => $studentId]);
        $row = $stmt->fetch();
        $total = (int) ($row['total'] ?? 0);
        $present = (int) ($row['present'] ?? 0);
        return $total > 0 ? round(($present / $total) * 100, 2) : 0.00;
    }
}
