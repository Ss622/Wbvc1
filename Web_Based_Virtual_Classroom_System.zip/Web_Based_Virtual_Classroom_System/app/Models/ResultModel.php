<?php
declare(strict_types=1);

namespace App\Models;

class ResultModel extends BaseModel
{
    public function getAll(array $filters = []): array
    {
        $sql = 'SELECT r.*,
                       u.name AS student_name,
                       u.enrollment_no,
                       u.email AS student_email,
                       c.course_code,
                       c.course_name,
                       c.semester,
                       c.credits,
                       t.name AS teacher_name
                FROM results r
                INNER JOIN users u ON r.student_id = u.user_id
                INNER JOIN courses c ON r.course_id = c.course_id
                LEFT JOIN users t ON c.teacher_id = t.user_id
                WHERE 1=1';
        $params = [];

        if (!empty($filters['student_id'])) {
            $sql .= ' AND r.student_id = :student_id';
            $params['student_id'] = (int) $filters['student_id'];
        }
        if (!empty($filters['course_id'])) {
            $sql .= ' AND r.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['teacher_id'])) {
            $sql .= ' AND c.teacher_id = :teacher_id';
            $params['teacher_id'] = (int) $filters['teacher_id'];
        }
        if (isset($filters['is_published']) && $filters['is_published'] !== '') {
            $sql .= ' AND r.is_published = :is_published';
            $params['is_published'] = (int) $filters['is_published'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (u.name LIKE :q1 OR u.enrollment_no LIKE :q2 OR c.course_code LIKE :q3 OR c.course_name LIKE :q4)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
            $params['q4'] = $term;
        }

        $sql .= ' ORDER BY c.course_code ASC, u.name ASC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
