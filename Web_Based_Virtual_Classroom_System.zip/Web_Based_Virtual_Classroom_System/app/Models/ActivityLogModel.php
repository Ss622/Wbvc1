<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Auth;

class ActivityLogModel extends BaseModel
{
    public static function record(string $action, string $description, ?string $entityType = null, ?int $entityId = null, ?int $userId = null): void
    {
        try {
            $model = new self();
            $uid = $userId ?? Auth::id();
            $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $stmt = $model->db->prepare(
                'INSERT INTO activity_logs (user_id, action, entity_type, entity_id, description, ip_address)
                 VALUES (:uid, :action, :etype, :eid, :desc, :ip)'
            );
            $stmt->execute([
                'uid'    => $uid,
                'action' => $action,
                'etype'  => $entityType,
                'eid'    => $entityId,
                'desc'   => $description,
                'ip'     => $ip,
            ]);
        } catch (\Throwable) {
            // Do not interrupt user workflow if audit log write fails
        }
    }

    public function getRecent(int $limit = 50, string $search = ''): array
    {
        $sql = 'SELECT l.*, u.name AS user_name, u.email AS user_email, r.role_name
                FROM activity_logs l
                LEFT JOIN users u ON l.user_id = u.user_id
                LEFT JOIN roles r ON u.role_id = r.role_id
                WHERE 1=1';
        $params = [];
        if (trim($search) !== '') {
            $sql .= ' AND (l.action LIKE :q1 OR l.description LIKE :q2 OR u.name LIKE :q3)';
            $term = '%' . trim($search) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
        }
        $sql .= ' ORDER BY l.log_id DESC LIMIT ' . max(1, min(200, $limit));
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
