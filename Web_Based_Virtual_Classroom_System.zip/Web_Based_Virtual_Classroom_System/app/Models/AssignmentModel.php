<?php
declare(strict_types=1);

namespace App\Models;

class AssignmentModel extends BaseModel
{
    public function getAll(array $filters = []): array
    {
        $sql = 'SELECT a.*,
                       c.course_code,
                       c.course_name,
                       c.teacher_id,
                       u.name AS creator_name,
                       (SELECT COUNT(*) FROM submissions s WHERE s.assignment_id = a.assignment_id) AS submission_count,
                       (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = a.course_id AND e.enrollment_status = 'active') AS enrolled_count
                FROM assignments a
                INNER JOIN courses c ON a.course_id = c.course_id
                INNER JOIN users u ON a.created_by = u.user_id
                WHERE 1=1';
        $params = [];

        if (!empty($filters['course_id'])) {
            $sql .= ' AND a.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['teacher_id'])) {
            $sql .= ' AND c.teacher_id = :teacher_id';
            $params['teacher_id'] = (int) $filters['teacher_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND a.status = :status';
            $params['status'] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (a.title LIKE :q1 OR a.description LIKE :q2 OR c.course_code LIKE :q3 OR c.course_name LIKE :q4)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
            $params['q4'] = $term;
        }

        $sql .= ' ORDER BY a.due_date ASC, a.assignment_id DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getForStudent(int $studentId, array $filters = []): array
    {
        $sql = 'SELECT a.*,
                       c.course_code,
                       c.course_name,
                       u.name AS teacher_name,
                       s.submission_id,
                       s.status AS submission_status,
                       s.marks AS awarded_marks,
                       s.feedback,
                       s.submitted_at,
                       s.is_late
                FROM assignments a
                INNER JOIN courses c ON a.course_id = c.course_id
                INNER JOIN enrollments e ON e.course_id = c.course_id AND e.student_id = :sid1 AND e.enrollment_status = 'active'
                LEFT JOIN users u ON c.teacher_id = u.user_id
                LEFT JOIN submissions s ON s.assignment_id = a.assignment_id AND s.student_id = :sid2
                WHERE a.status != 'draft'
                  AND c.status = 'published'';
        $params = [
            'sid1' => $studentId,
            'sid2' => $studentId,
        ];

        if (!empty($filters['course_id'])) {
            $sql .= ' AND a.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (a.title LIKE :q1 OR c.course_code LIKE :q2 OR c.course_name LIKE :q3)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
        }

        $sql .= ' ORDER BY a.due_date ASC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function findById(int $assignmentId): ?array
    {
        $sql = 'SELECT a.*, c.course_code, c.course_name, c.teacher_id, u.name AS creator_name
                FROM assignments a
                INNER JOIN courses c ON a.course_id = c.course_id
                INNER JOIN users u ON a.created_by = u.user_id
                WHERE a.assignment_id = :id
                LIMIT 1';
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $assignmentId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO assignments (course_id, created_by, title, description, max_marks, issue_date, due_date, allow_late, attachment_path, attachment_name, status)
                VALUES (:course_id, :created_by, :title, :description, :max_marks, :issue_date, :due_date, :allow_late, :attachment_path, :attachment_name, :status)';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'course_id'       => (int) $data['course_id'],
            'created_by'      => (int) $data['created_by'],
            'title'           => trim($data['title']),
            'description'     => trim($data['description']),
            'max_marks'       => (float) $data['max_marks'],
            'issue_date'      => $data['issue_date'],
            'due_date'        => $data['due_date'],
            'allow_late'      => (int) ($data['allow_late'] ?? 1),
            'attachment_path' => $data['attachment_path'] ?? null,
            'attachment_name' => $data['attachment_name'] ?? null,
            'status'          => $data['status'] ?? 'open',
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $assignmentId, array $data): bool
    {
        $sql = 'UPDATE assignments
                SET course_id = :course_id,
                    title = :title,
                    description = :description,
                    max_marks = :max_marks,
                    issue_date = :issue_date,
                    due_date = :due_date,
                    allow_late = :allow_late,
                    status = :status,
                    updated_at = CURRENT_TIMESTAMP
                WHERE assignment_id = :id';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'course_id'   => (int) $data['course_id'],
            'title'       => trim($data['title']),
            'description' => trim($data['description']),
            'max_marks'   => (float) $data['max_marks'],
            'issue_date'  => $data['issue_date'],
            'due_date'    => $data['due_date'],
            'allow_late'  => (int) ($data['allow_late'] ?? 1),
            'status'      => $data['status'] ?? 'open',
            'id'          => $assignmentId,
        ]);
    }

    public function delete(int $assignmentId): bool
    {
        $stmt = $this->db->prepare('DELETE FROM assignments WHERE assignment_id = :id');
        return $stmt->execute(['id' => $assignmentId]);
    }

    public function countAll(): int
    {
        return (int) $this->db->query('SELECT COUNT(*) FROM assignments')->fetchColumn();
    }
}
