<?php
declare(strict_types=1);

namespace App\Models;

class AttemptModel extends BaseModel
{
    public function countStudentAttempts(int $quizId, int $studentId): int
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM attempts WHERE quiz_id = :qid AND student_id = :sid AND status = 'completed'"
        );
        $stmt->execute(['qid' => $quizId, 'sid' => $studentId]);
        return (int) $stmt->fetchColumn();
    }

    public function findActiveAttempt(int $quizId, int $studentId): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM attempts WHERE quiz_id = :qid AND student_id = :sid AND status = 'in_progress' ORDER BY attempt_id DESC LIMIT 1"
        );
        $stmt->execute(['qid' => $quizId, 'sid' => $studentId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function startAttempt(int $quizId, int $studentId, float $totalMarks): int
    {
        $existing = $this->findActiveAttempt($quizId, $studentId);
        if ($existing) {
            return (int) $existing['attempt_id'];
        }

        $stmtNum = $this->db->prepare('SELECT COALESCE(MAX(attempt_number), 0) + 1 FROM attempts WHERE quiz_id = :qid AND student_id = :sid');
        $stmtNum->execute(['qid' => $quizId, 'sid' => $studentId]);
        $nextNum = (int) $stmtNum->fetchColumn();

        $stmt = $this->db->prepare(
            "INSERT INTO attempts (quiz_id, student_id, attempt_number, started_at, total_marks, status)
             VALUES (:qid, :sid, :num, :started_at, :total, 'in_progress')"
        );
        $stmt->execute([
            'qid'        => $quizId,
            'sid'        => $studentId,
            'num'        => $nextNum,
            'started_at' => date('Y-m-d H:i:s'),
            'total'      => $totalMarks,
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function findByIdWithDetails(int $attemptId): ?array
    {
        $sql = 'SELECT a.*,
                       q.title AS quiz_title,
                       q.course_id,
                       q.duration_minutes,
                       q.results_published,
                       c.course_code,
                       c.course_name,
                       c.teacher_id,
                       u.name AS student_name,
                       u.enrollment_no
                FROM attempts a
                INNER JOIN quizzes q ON a.quiz_id = q.quiz_id
                INNER JOIN courses c ON q.course_id = c.course_id
                INNER JOIN users u ON a.student_id = u.user_id
                WHERE a.attempt_id = :id
                LIMIT 1';
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $attemptId]);
        $attempt = $stmt->fetch();
        if (!$attempt) {
            return null;
        }

        $ansSql = 'SELECT aa.*,
                          qn.question_text,
                          qn.marks AS max_question_marks,
                          qn.correct_option,
                          qn.explanation
                   FROM attempt_answers aa
                   INNER JOIN questions qn ON aa.question_id = qn.question_id
                   WHERE aa.attempt_id = :aid
                   ORDER BY qn.sort_order ASC, qn.question_id ASC';
        $ansStmt = $this->db->prepare($ansSql);
        $ansStmt->execute(['aid' => $attemptId]);
        $attempt['answers'] = $ansStmt->fetchAll();

        return $attempt;
    }

    public function getAll(array $filters = []): array
    {
        $sql = 'SELECT a.*,
                       q.title AS quiz_title,
                       q.course_id,
                       q.results_published,
                       c.course_code,
                       c.course_name,
                       c.teacher_id,
                       u.name AS student_name,
                       u.enrollment_no
                FROM attempts a
                INNER JOIN quizzes q ON a.quiz_id = q.quiz_id
                INNER JOIN courses c ON q.course_id = c.course_id
                INNER JOIN users u ON a.student_id = u.user_id
                WHERE a.status = 'completed'';
        $params = [];

        if (!empty($filters['quiz_id'])) {
            $sql .= ' AND a.quiz_id = :quiz_id';
            $params['quiz_id'] = (int) $filters['quiz_id'];
        }
        if (!empty($filters['course_id'])) {
            $sql .= ' AND q.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['teacher_id'])) {
            $sql .= ' AND c.teacher_id = :teacher_id';
            $params['teacher_id'] = (int) $filters['teacher_id'];
        }
        if (!empty($filters['student_id'])) {
            $sql .= ' AND a.student_id = :student_id';
            $params['student_id'] = (int) $filters['student_id'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (u.name LIKE :q1 OR u.enrollment_no LIKE :q2 OR q.title LIKE :q3 OR c.course_code LIKE :q4)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
            $params['q4'] = $term;
        }

        $sql .= ' ORDER BY a.submitted_at DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
