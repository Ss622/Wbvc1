<?php
declare(strict_types=1);

namespace App\Models;

class EnrollmentModel extends BaseModel
{
    public function getAll(array $filters = []): array
    {
        $sql = 'SELECT e.*,
                       s.name AS student_name,
                       s.email AS student_email,
                       s.enrollment_no,
                       c.course_code,
                       c.course_name,
                       c.semester,
                       t.name AS teacher_name
                FROM enrollments e
                INNER JOIN users s ON e.student_id = s.user_id
                INNER JOIN courses c ON e.course_id = c.course_id
                LEFT JOIN users t ON c.teacher_id = t.user_id
                WHERE 1=1';
        $params = [];

        if (!empty($filters['course_id'])) {
            $sql .= ' AND e.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['student_id'])) {
            $sql .= ' AND e.student_id = :student_id';
            $params['student_id'] = (int) $filters['student_id'];
        }
        if (!empty($filters['teacher_id'])) {
            $sql .= ' AND c.teacher_id = :teacher_id';
            $params['teacher_id'] = (int) $filters['teacher_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND e.enrollment_status = :status';
            $params['status'] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (s.name LIKE :q1 OR s.email LIKE :q2 OR s.enrollment_no LIKE :q3 OR c.course_code LIKE :q4 OR c.course_name LIKE :q5)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
            $params['q4'] = $term;
            $params['q5'] = $term;
        }

        $sql .= ' ORDER BY c.course_code ASC, s.name ASC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function isEnrolled(int $studentId, int $courseId): bool
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM enrollments WHERE student_id = :sid AND course_id = :cid AND enrollment_status = 'active'"
        );
        $stmt->execute(['sid' => $studentId, 'cid' => $courseId]);
        return ((int) $stmt->fetchColumn()) > 0;
    }

    public function existsAnyStatus(int $studentId, int $courseId): bool
    {
        $stmt = $this->db->prepare(
            'SELECT COUNT(*) FROM enrollments WHERE student_id = :sid AND course_id = :cid'
        );
        $stmt->execute(['sid' => $studentId, 'cid' => $courseId]);
        return ((int) $stmt->fetchColumn()) > 0;
    }

    public function enroll(int $studentId, int $courseId, int $enrolledBy): int
    {
        if ($this->existsAnyStatus($studentId, $courseId)) {
            $stmt = $this->db->prepare(
                "UPDATE enrollments SET enrollment_status = 'active', enrolled_by = :by, enrolled_at = CURRENT_TIMESTAMP WHERE student_id = :sid AND course_id = :cid"
            );
            $stmt->execute(['by' => $enrolledBy, 'sid' => $studentId, 'cid' => $courseId]);
            $idStmt = $this->db->prepare('SELECT enrollment_id FROM enrollments WHERE student_id = :sid AND course_id = :cid');
            $idStmt->execute(['sid' => $studentId, 'cid' => $courseId]);
            return (int) $idStmt->fetchColumn();
        }

        $stmt = $this->db->prepare(
            "INSERT INTO enrollments (student_id, course_id, enrolled_by, enrollment_status) VALUES (:sid, :cid, :by, 'active')"
        );
        $stmt->execute([
            'sid' => $studentId,
            'cid' => $courseId,
            'by'  => $enrolledBy,
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function remove(int $enrollmentId): bool
    {
        $stmt = $this->db->prepare('DELETE FROM enrollments WHERE enrollment_id = :id');
        return $stmt->execute(['id' => $enrollmentId]);
    }

    public function getStudentsByCourse(int $courseId): array
    {
        return $this->getAll(['course_id' => $courseId, 'status' => 'active']);
    }

    public function countAllActive(): int
    {
        return (int) $this->db->query("SELECT COUNT(*) FROM enrollments WHERE enrollment_status = 'active'")->fetchColumn();
    }
}
