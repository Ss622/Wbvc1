<?php
declare(strict_types=1);

namespace App\Models;

class NoticeModel extends BaseModel
{
    public function getAll(array $filters = []): array
    {
        $sql = 'SELECT n.*,
                       u.name AS author_name,
                       r.role_name AS author_role,
                       c.course_code,
                       c.course_name
                FROM notices n
                INNER JOIN users u ON n.author_id = u.user_id
                INNER JOIN roles r ON u.role_id = r.role_id
                LEFT JOIN courses c ON n.course_id = c.course_id
                WHERE 1=1';
        $params = [];

        if (!empty($filters['audience'])) {
            $sql .= ' AND n.audience = :audience';
            $params['audience'] = $filters['audience'];
        }
        if (!empty($filters['priority'])) {
            $sql .= ' AND n.priority = :priority';
            $params['priority'] = $filters['priority'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND n.status = :status';
            $params['status'] = $filters['status'];
        }
        if (!empty($filters['course_id'])) {
            $sql .= ' AND n.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (n.title LIKE :q1 OR n.description LIKE :q2 OR c.course_code LIKE :q3)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
        }

        $sql .= ' ORDER BY n.published_at DESC, n.notice_id DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getVisibleForTeacher(int $teacherId, array $filters = []): array
    {
        $sql = 'SELECT n.*, u.name AS author_name, c.course_code, c.course_name
                FROM notices n
                INNER JOIN users u ON n.author_id = u.user_id
                LEFT JOIN courses c ON n.course_id = c.course_id
                WHERE n.status = 'published'
                  AND (
                      n.audience IN ('all', 'teachers')
                      OR n.author_id = :tid1
                      OR (n.audience = 'course' AND c.teacher_id = :tid2)
                  )';
        $params = ['tid1' => $teacherId, 'tid2' => $teacherId];

        if (!empty($filters['priority'])) {
            $sql .= ' AND n.priority = :priority';
            $params['priority'] = $filters['priority'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (n.title LIKE :q1 OR n.description LIKE :q2)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
        }

        $sql .= ' ORDER BY n.published_at DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getVisibleForStudent(int $studentId, array $filters = []): array
    {
        $sql = 'SELECT n.*, u.name AS author_name, c.course_code, c.course_name
                FROM notices n
                INNER JOIN users u ON n.author_id = u.user_id
                LEFT JOIN courses c ON n.course_id = c.course_id
                WHERE n.status = 'published'
                  AND (
                      n.audience IN ('all', 'students')
                      OR (
                          n.audience = 'course'
                          AND EXISTS (
                              SELECT 1 FROM enrollments e
                              WHERE e.course_id = n.course_id
                                AND e.student_id = :sid
                                AND e.enrollment_status = 'active'
                          )
                      )
                  )';
        $params = ['sid' => $studentId];

        if (!empty($filters['course_id'])) {
            $sql .= ' AND n.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['priority'])) {
            $sql .= ' AND n.priority = :priority';
            $params['priority'] = $filters['priority'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (n.title LIKE :q1 OR n.description LIKE :q2 OR c.course_code LIKE :q3)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
        }

        $sql .= ' ORDER BY n.published_at DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function findById(int $noticeId): ?array
    {
        $stmt = $this->db->prepare('SELECT n.*, c.teacher_id FROM notices n LEFT JOIN courses c ON n.course_id = c.course_id WHERE n.notice_id = :id LIMIT 1');
        $stmt->execute(['id' => $noticeId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO notices (title, description, author_id, audience, course_id, priority, status, published_at)
                VALUES (:title, :description, :author_id, :audience, :course_id, :priority, :status, CURRENT_TIMESTAMP)';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'title'       => trim($data['title']),
            'description' => trim($data['description']),
            'author_id'   => (int) $data['author_id'],
            'audience'    => $data['audience'] ?? 'all',
            'course_id'   => !empty($data['course_id']) ? (int) $data['course_id'] : null,
            'priority'    => $data['priority'] ?? 'normal',
            'status'      => $data['status'] ?? 'published',
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $noticeId, array $data): bool
    {
        $sql = 'UPDATE notices
                SET title = :title,
                    description = :description,
                    audience = :audience,
                    course_id = :course_id,
                    priority = :priority,
                    status = :status,
                    updated_at = CURRENT_TIMESTAMP
                WHERE notice_id = :id';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'title'       => trim($data['title']),
            'description' => trim($data['description']),
            'audience'    => $data['audience'] ?? 'all',
            'course_id'   => !empty($data['course_id']) ? (int) $data['course_id'] : null,
            'priority'    => $data['priority'] ?? 'normal',
            'status'      => $data['status'] ?? 'published',
            'id'          => $noticeId,
        ]);
    }

    public function delete(int $noticeId): bool
    {
        $stmt = $this->db->prepare('DELETE FROM notices WHERE notice_id = :id');
        return $stmt->execute(['id' => $noticeId]);
    }
}
