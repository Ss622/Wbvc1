<?php
declare(strict_types=1);

namespace App\Models;

class QuestionModel extends BaseModel
{
    public function getByQuiz(int $quizId, bool $includeCorrectAnswer = true): array
    {
        $stmt = $this->db->prepare('SELECT * FROM questions WHERE quiz_id = :qid ORDER BY sort_order ASC, question_id ASC');
        $stmt->execute(['qid' => $quizId]);
        $questions = $stmt->fetchAll();

        foreach ($questions as &$q) {
            $optStmt = $this->db->prepare('SELECT option_id, question_id, option_label, option_text, is_correct FROM question_options WHERE question_id = :qid ORDER BY option_label ASC');
            $optStmt->execute(['qid' => $q['question_id']]);
            $options = $optStmt->fetchAll();

            if (!$includeCorrectAnswer) {
                unset($q['correct_option'], $q['explanation']);
                foreach ($options as &$opt) {
                    unset($opt['is_correct']);
                }
            }
            $q['options'] = $options;
        }

        return $questions;
    }

    public function getQuestionBank(array $filters = []): array
    {
        $sql = 'SELECT qn.*, c.course_code, c.course_name, q.title AS quiz_title
                FROM questions qn
                INNER JOIN courses c ON qn.course_id = c.course_id
                LEFT JOIN quizzes q ON qn.quiz_id = q.quiz_id
                WHERE 1=1';
        $params = [];

        if (!empty($filters['teacher_id'])) {
            $sql .= ' AND c.teacher_id = :teacher_id';
            $params['teacher_id'] = (int) $filters['teacher_id'];
        }
        if (!empty($filters['course_id'])) {
            $sql .= ' AND qn.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['quiz_id'])) {
            $sql .= ' AND qn.quiz_id = :quiz_id';
            $params['quiz_id'] = (int) $filters['quiz_id'];
        }
        if (!empty($filters['topic'])) {
            $sql .= ' AND qn.topic LIKE :topic';
            $params['topic'] = '%' . trim($filters['topic']) . '%';
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (qn.question_text LIKE :q1 OR qn.topic LIKE :q2 OR c.course_code LIKE :q3)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
        }

        $sql .= ' ORDER BY qn.course_id ASC, qn.quiz_id ASC, qn.sort_order ASC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $questions = $stmt->fetchAll();

        foreach ($questions as &$q) {
            $optStmt = $this->db->prepare('SELECT * FROM question_options WHERE question_id = :qid ORDER BY option_label ASC');
            $optStmt->execute(['qid' => $q['question_id']]);
            $q['options'] = $optStmt->fetchAll();
        }
        return $questions;
    }

    public function findById(int $questionId): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT qn.*, c.teacher_id, c.course_code FROM questions qn INNER JOIN courses c ON qn.course_id = c.course_id WHERE qn.question_id = :id LIMIT 1'
        );
        $stmt->execute(['id' => $questionId]);
        $q = $stmt->fetch();
        if (!$q) {
            return null;
        }
        $optStmt = $this->db->prepare('SELECT * FROM question_options WHERE question_id = :qid ORDER BY option_label ASC');
        $optStmt->execute(['qid' => $questionId]);
        $q['options'] = $optStmt->fetchAll();
        return $q;
    }

    public function createWithOptions(array $data, array $options): int
    {
        $this->db->beginTransaction();
        try {
            $sql = 'INSERT INTO questions (quiz_id, course_id, created_by, topic, question_text, marks, correct_option, explanation, sort_order)
                    VALUES (:quiz_id, :course_id, :created_by, :topic, :question_text, :marks, :correct_option, :explanation, :sort_order)';
            $stmt = $this->db->prepare($sql);
            $correct = strtoupper(trim($data['correct_option']));
            $stmt->execute([
                'quiz_id'        => !empty($data['quiz_id']) ? (int) $data['quiz_id'] : null,
                'course_id'      => (int) $data['course_id'],
                'created_by'     => (int) $data['created_by'],
                'topic'          => trim($data['topic'] ?? 'General'),
                'question_text'  => trim($data['question_text']),
                'marks'          => (float) ($data['marks'] ?? 2.00),
                'correct_option' => $correct,
                'explanation'    => trim($data['explanation'] ?? ''),
                'sort_order'     => (int) ($data['sort_order'] ?? 1),
            ]);
            $questionId = (int) $this->db->lastInsertId();

            $optStmt = $this->db->prepare(
                'INSERT INTO question_options (question_id, option_label, option_text, is_correct) VALUES (:qid, :label, :text, :is_correct)'
            );
            foreach (['A', 'B', 'C', 'D'] as $label) {
                $optStmt->execute([
                    'qid'        => $questionId,
                    'label'      => $label,
                    'text'       => trim((string) ($options[$label] ?? '')),
                    'is_correct' => ($label === $correct) ? 1 : 0,
                ]);
            }

            if (!empty($data['quiz_id'])) {
                (new QuizModel())->syncTotalMarks((int) $data['quiz_id']);
            }

            $this->db->commit();
            return $questionId;
        } catch (\Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function delete(int $questionId): bool
    {
        $q = $this->findById($questionId);
        if (!$q) {
            return false;
        }
        $stmt = $this->db->prepare('DELETE FROM questions WHERE question_id = :id');
        $ok = $stmt->execute(['id' => $questionId]);
        if ($ok && !empty($q['quiz_id'])) {
            (new QuizModel())->syncTotalMarks((int) $q['quiz_id']);
        }
        return $ok;
    }
}
