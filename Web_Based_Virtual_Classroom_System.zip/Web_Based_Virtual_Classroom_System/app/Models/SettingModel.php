<?php
declare(strict_types=1);

namespace App\Models;

class SettingModel extends BaseModel
{
    public function getAllKeyed(): array
    {
        $stmt = $this->db->query('SELECT setting_key, setting_value FROM settings');
        $rows = $stmt->fetchAll();
        $map = [];
        foreach ($rows as $r) {
            $map[$r['setting_key']] = $r['setting_value'];
        }
        return $map;
    }

    public function updateSettings(array $keyValuePairs): void
    {
        $stmt = $this->db->prepare(
            'UPDATE settings SET setting_value = :val, updated_at = CURRENT_TIMESTAMP WHERE setting_key = :key'
        );
        foreach ($keyValuePairs as $k => $v) {
            $stmt->execute([
                'val' => trim((string) $v),
                'key' => (string) $k,
            ]);
        }
    }
}
