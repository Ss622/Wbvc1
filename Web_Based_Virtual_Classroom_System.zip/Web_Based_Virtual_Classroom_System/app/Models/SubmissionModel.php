<?php
declare(strict_types=1);

namespace App\Models;

class SubmissionModel extends BaseModel
{
    public function getAll(array $filters = []): array
    {
        $sql = 'SELECT s.*,
                       a.title AS assignment_title,
                       a.max_marks,
                       a.due_date,
                       a.course_id,
                       c.course_code,
                       c.course_name,
                       c.teacher_id,
                       u.name AS student_name,
                       u.email AS student_email,
                       u.enrollment_no,
                       ev.name AS evaluator_name
                FROM submissions s
                INNER JOIN assignments a ON s.assignment_id = a.assignment_id
                INNER JOIN courses c ON a.course_id = c.course_id
                INNER JOIN users u ON s.student_id = u.user_id
                LEFT JOIN users ev ON s.evaluated_by = ev.user_id
                WHERE 1=1';
        $params = [];

        if (!empty($filters['assignment_id'])) {
            $sql .= ' AND s.assignment_id = :assignment_id';
            $params['assignment_id'] = (int) $filters['assignment_id'];
        }
        if (!empty($filters['course_id'])) {
            $sql .= ' AND a.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['teacher_id'])) {
            $sql .= ' AND c.teacher_id = :teacher_id';
            $params['teacher_id'] = (int) $filters['teacher_id'];
        }
        if (!empty($filters['student_id'])) {
            $sql .= ' AND s.student_id = :student_id';
            $params['student_id'] = (int) $filters['student_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND s.status = :status';
            $params['status'] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (u.name LIKE :q1 OR u.enrollment_no LIKE :q2 OR a.title LIKE :q3 OR c.course_code LIKE :q4)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
            $params['q4'] = $term;
        }

        $sql .= ' ORDER BY s.submitted_at DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function findById(int $submissionId): ?array
    {
        $sql = 'SELECT s.*,
                       a.title AS assignment_title,
                       a.max_marks,
                       a.due_date,
                       a.course_id,
                       c.course_code,
                       c.course_name,
                       c.teacher_id,
                       u.name AS student_name,
                       u.email AS student_email,
                       u.enrollment_no
                FROM submissions s
                INNER JOIN assignments a ON s.assignment_id = a.assignment_id
                INNER JOIN courses c ON a.course_id = c.course_id
                INNER JOIN users u ON s.student_id = u.user_id
                WHERE s.submission_id = :id
                LIMIT 1';
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $submissionId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function findByAssignmentAndStudent(int $assignmentId, int $studentId): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM submissions WHERE assignment_id = :aid AND student_id = :sid LIMIT 1'
        );
        $stmt->execute(['aid' => $assignmentId, 'sid' => $studentId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function createOrUpdateSubmission(array $data): int
    {
        $existing = $this->findByAssignmentAndStudent((int) $data['assignment_id'], (int) $data['student_id']);
        $status = !empty($data['is_late']) ? 'late' : 'submitted';

        if ($existing) {
            $sql = 'UPDATE submissions
                    SET text_response = :text_response,
                        file_path = COALESCE(:file_path, file_path),
                        original_name = COALESCE(:original_name, original_name),
                        file_size = CASE WHEN :file_size > 0 THEN :file_size2 ELSE file_size END,
                        is_late = :is_late,
                        status = :status,
                        submitted_at = CURRENT_TIMESTAMP
                    WHERE submission_id = :id';
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                'text_response' => $data['text_response'],
                'file_path'     => $data['file_path'] ?? null,
                'original_name' => $data['original_name'] ?? null,
                'file_size'     => (int) ($data['file_size'] ?? 0),
                'file_size2'    => (int) ($data['file_size'] ?? 0),
                'is_late'       => (int) ($data['is_late'] ?? 0),
                'status'        => $status,
                'id'            => (int) $existing['submission_id'],
            ]);
            return (int) $existing['submission_id'];
        }

        $sql = 'INSERT INTO submissions (assignment_id, student_id, text_response, file_path, original_name, file_size, is_late, status)
                VALUES (:assignment_id, :student_id, :text_response, :file_path, :original_name, :file_size, :is_late, :status)';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'assignment_id' => (int) $data['assignment_id'],
            'student_id'    => (int) $data['student_id'],
            'text_response' => $data['text_response'],
            'file_path'     => $data['file_path'] ?? null,
            'original_name' => $data['original_name'] ?? null,
            'file_size'     => (int) ($data['file_size'] ?? 0),
            'is_late'       => (int) ($data['is_late'] ?? 0),
            'status'        => $status,
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function evaluate(int $submissionId, float $marks, string $feedback, int $evaluatedBy, bool $publish = true): bool
    {
        $status = $publish ? 'published' : 'evaluated';
        $pubTime = $publish ? date('Y-m-d H:i:s') : null;
        $sql = 'UPDATE submissions
                SET marks = :marks,
                    feedback = :feedback,
                    evaluated_by = :evaluated_by,
                    status = :status,
                    evaluated_at = CURRENT_TIMESTAMP,
                    published_at = :published_at
                WHERE submission_id = :id';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'marks'        => $marks,
            'feedback'     => trim($feedback),
            'evaluated_by' => $evaluatedBy,
            'status'       => $status,
            'published_at' => $pubTime,
            'id'           => $submissionId,
        ]);
    }
}
