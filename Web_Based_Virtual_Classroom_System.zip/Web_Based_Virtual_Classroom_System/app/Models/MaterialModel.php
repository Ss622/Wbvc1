<?php
declare(strict_types=1);

namespace App\Models;

class MaterialModel extends BaseModel
{
    public function getAll(array $filters = []): array
    {
        $sql = 'SELECT m.*,
                       c.course_code,
                       c.course_name,
                       c.teacher_id,
                       u.name AS uploader_name
                FROM materials m
                INNER JOIN courses c ON m.course_id = c.course_id
                INNER JOIN users u ON m.uploaded_by = u.user_id
                WHERE 1=1';
        $params = [];

        if (!empty($filters['course_id'])) {
            $sql .= ' AND m.course_id = :course_id';
            $params['course_id'] = (int) $filters['course_id'];
        }
        if (!empty($filters['teacher_id'])) {
            $sql .= ' AND c.teacher_id = :teacher_id';
            $params['teacher_id'] = (int) $filters['teacher_id'];
        }
        if (!empty($filters['student_id'])) {
            $sql .= ' AND EXISTS (
                SELECT 1 FROM enrollments e
                WHERE e.course_id = m.course_id
                  AND e.student_id = :student_id
                  AND e.enrollment_status = 'active'
            ) AND c.status = 'published'';
            $params['student_id'] = (int) $filters['student_id'];
        }
        if (!empty($filters['category'])) {
            $sql .= ' AND m.category = :category';
            $params['category'] = $filters['category'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (m.title LIKE :q1 OR m.description LIKE :q2 OR c.course_code LIKE :q3 OR c.course_name LIKE :q4)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
            $params['q4'] = $term;
        }

        $sql .= ' ORDER BY m.created_at DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function findById(int $materialId): ?array
    {
        $sql = 'SELECT m.*, c.course_code, c.course_name, c.teacher_id, u.name AS uploader_name
                FROM materials m
                INNER JOIN courses c ON m.course_id = c.course_id
                INNER JOIN users u ON m.uploaded_by = u.user_id
                WHERE m.material_id = :id
                LIMIT 1';
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $materialId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO materials (course_id, uploaded_by, title, description, category, file_name, original_name, file_path, file_type, mime_type, file_size)
                VALUES (:course_id, :uploaded_by, :title, :description, :category, :file_name, :original_name, :file_path, :file_type, :mime_type, :file_size)';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'course_id'     => (int) $data['course_id'],
            'uploaded_by'   => (int) $data['uploaded_by'],
            'title'         => trim($data['title']),
            'description'   => trim($data['description'] ?? ''),
            'category'      => $data['category'] ?? 'Lecture Notes',
            'file_name'     => $data['file_name'],
            'original_name' => $data['original_name'],
            'file_path'     => $data['file_path'],
            'file_type'     => $data['file_type'],
            'mime_type'     => $data['mime_type'],
            'file_size'     => (int) $data['file_size'],
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function updateMetadata(int $materialId, array $data): bool
    {
        $sql = 'UPDATE materials
                SET course_id = :course_id,
                    title = :title,
                    description = :description,
                    category = :category,
                    updated_at = CURRENT_TIMESTAMP
                WHERE material_id = :id';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'course_id'   => (int) $data['course_id'],
            'title'       => trim($data['title']),
            'description' => trim($data['description'] ?? ''),
            'category'    => $data['category'] ?? 'Lecture Notes',
            'id'          => $materialId,
        ]);
    }

    public function incrementDownloadCount(int $materialId): void
    {
        $stmt = $this->db->prepare('UPDATE materials SET download_count = download_count + 1 WHERE material_id = :id');
        $stmt->execute(['id' => $materialId]);
    }

    public function delete(int $materialId): bool
    {
        $stmt = $this->db->prepare('DELETE FROM materials WHERE material_id = :id');
        return $stmt->execute(['id' => $materialId]);
    }
}
