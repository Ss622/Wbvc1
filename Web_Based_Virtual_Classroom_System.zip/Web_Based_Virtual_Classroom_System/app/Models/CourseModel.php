<?php
declare(strict_types=1);

namespace App\Models;

class CourseModel extends BaseModel
{
    public function getAll(array $filters = []): array
    {
        $sql = 'SELECT c.*,
                       u.name AS teacher_name,
                       u.email AS teacher_email,
                       (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.course_id AND e.enrollment_status = 'active') AS enrolled_count,
                       (SELECT COUNT(*) FROM materials m WHERE m.course_id = c.course_id) AS material_count,
                       (SELECT COUNT(*) FROM assignments a WHERE a.course_id = c.course_id) AS assignment_count,
                       (SELECT COUNT(*) FROM quizzes q WHERE q.course_id = c.course_id) AS quiz_count
                FROM courses c
                LEFT JOIN users u ON c.teacher_id = u.user_id
                WHERE 1=1';
        $params = [];

        if (!empty($filters['teacher_id'])) {
            $sql .= ' AND c.teacher_id = :teacher_id';
            $params['teacher_id'] = (int) $filters['teacher_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND c.status = :status';
            $params['status'] = $filters['status'];
        }
        if (!empty($filters['semester'])) {
            $sql .= ' AND c.semester = :semester';
            $params['semester'] = $filters['semester'];
        }
        if (!empty($filters['search'])) {
            $sql .= ' AND (c.course_code LIKE :q1 OR c.course_name LIKE :q2 OR c.description LIKE :q3 OR u.name LIKE :q4)';
            $term = '%' . trim($filters['search']) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
            $params['q4'] = $term;
        }

        $sql .= ' ORDER BY c.course_code ASC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function findById(int $courseId): ?array
    {
        $sql = 'SELECT c.*,
                       u.name AS teacher_name,
                       u.email AS teacher_email,
                       u.qualification AS teacher_qualification,
                       (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.course_id AND e.enrollment_status = 'active') AS enrolled_count
                FROM courses c
                LEFT JOIN users u ON c.teacher_id = u.user_id
                WHERE c.course_id = :id
                LIMIT 1';
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $courseId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function codeExists(string $courseCode, ?int $excludeCourseId = null): bool
    {
        $sql = 'SELECT COUNT(*) FROM courses WHERE course_code = :code';
        $params = ['code' => strtoupper(trim($courseCode))];
        if ($excludeCourseId !== null) {
            $sql .= ' AND course_id != :cid';
            $params['cid'] = $excludeCourseId;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return ((int) $stmt->fetchColumn()) > 0;
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO courses (course_code, course_name, description, credits, semester, teacher_id, status, created_by)
                VALUES (:course_code, :course_name, :description, :credits, :semester, :teacher_id, :status, :created_by)';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'course_code' => strtoupper(trim($data['course_code'])),
            'course_name' => trim($data['course_name']),
            'description' => trim($data['description']),
            'credits'     => (int) ($data['credits'] ?? 4),
            'semester'    => trim($data['semester'] ?? 'Semester VI'),
            'teacher_id'  => !empty($data['teacher_id']) ? (int) $data['teacher_id'] : null,
            'status'      => $data['status'] ?? 'published',
            'created_by'  => !empty($data['created_by']) ? (int) $data['created_by'] : null,
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $courseId, array $data): bool
    {
        $sql = 'UPDATE courses
                SET course_code = :course_code,
                    course_name = :course_name,
                    description = :description,
                    credits = :credits,
                    semester = :semester,
                    teacher_id = :teacher_id,
                    status = :status,
                    updated_at = CURRENT_TIMESTAMP
                WHERE course_id = :course_id';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'course_code' => strtoupper(trim($data['course_code'])),
            'course_name' => trim($data['course_name']),
            'description' => trim($data['description']),
            'credits'     => (int) ($data['credits'] ?? 4),
            'semester'    => trim($data['semester'] ?? 'Semester VI'),
            'teacher_id'  => !empty($data['teacher_id']) ? (int) $data['teacher_id'] : null,
            'status'      => $data['status'] ?? 'published',
            'course_id'   => $courseId,
        ]);
    }

    public function updateStatus(int $courseId, string $status): bool
    {
        $stmt = $this->db->prepare('UPDATE courses SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE course_id = :id');
        return $stmt->execute(['status' => $status, 'id' => $courseId]);
    }

    public function delete(int $courseId): bool
    {
        $stmt = $this->db->prepare('DELETE FROM courses WHERE course_id = :id');
        return $stmt->execute(['id' => $courseId]);
    }

    public function isAssignedToTeacher(int $courseId, int $teacherId): bool
    {
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM courses WHERE course_id = :cid AND teacher_id = :tid');
        $stmt->execute(['cid' => $courseId, 'tid' => $teacherId]);
        return ((int) $stmt->fetchColumn()) > 0;
    }

    public function getStudentEnrolledCourses(int $studentId, string $search = ''): array
    {
        $sql = 'SELECT c.*,
                       e.enrollment_id,
                       e.enrollment_status,
                       e.enrolled_at,
                       u.name AS teacher_name,
                       u.email AS teacher_email,
                       (SELECT COUNT(*) FROM materials m WHERE m.course_id = c.course_id) AS material_count,
                       (SELECT COUNT(*) FROM assignments a WHERE a.course_id = c.course_id AND a.status != 'draft') AS assignment_count,
                       (SELECT COUNT(*) FROM quizzes q WHERE q.course_id = c.course_id AND q.is_published = 1) AS quiz_count
                FROM enrollments e
                INNER JOIN courses c ON e.course_id = c.course_id
                LEFT JOIN users u ON c.teacher_id = u.user_id
                WHERE e.student_id = :student_id
                  AND e.enrollment_status = 'active'
                  AND c.status = 'published'';
        $params = ['student_id' => $studentId];

        if (trim($search) !== '') {
            $sql .= ' AND (c.course_code LIKE :q1 OR c.course_name LIKE :q2 OR u.name LIKE :q3)';
            $term = '%' . trim($search) . '%';
            $params['q1'] = $term;
            $params['q2'] = $term;
            $params['q3'] = $term;
        }

        $sql .= ' ORDER BY c.course_code ASC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function countAll(): int
    {
        return (int) $this->db->query('SELECT COUNT(*) FROM courses')->fetchColumn();
    }

    public function countPublished(): int
    {
        return (int) $this->db->query("SELECT COUNT(*) FROM courses WHERE status = 'published'")->fetchColumn();
    }
}
