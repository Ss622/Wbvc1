<?php
declare(strict_types=1);

namespace App\Helpers;

use RuntimeException;

/**
 * Secure File Upload Handler.
 * Validates extension, actual MIME type via finfo, file size, prevents executable uploads
 * and path traversal, and generates cryptographically random server-side filenames.
 */
class FileUpload
{
    public static function upload(array $file, string $subDirectory): array
    {
        if (!isset($file['error']) || is_array($file['error'])) {
            throw new RuntimeException('Invalid file upload parameters.');
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $msg = match ($file['error']) {
                UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'The uploaded file exceeds the maximum allowed size.',
                UPLOAD_ERR_PARTIAL => 'The file was only partially uploaded. Please try again.',
                UPLOAD_ERR_NO_FILE => 'No file was selected for upload.',
                default => 'File upload failed due to a server error.',
            };
            throw new RuntimeException($msg);
        }

        $appConfig = require dirname(__DIR__, 2) . '/config/app.php';
        $maxBytes = ((int) ($appConfig['max_upload_mb'] ?? 10)) * 1024 * 1024;
        $fileSize = (int) ($file['size'] ?? 0);

        if ($fileSize <= 0) {
            throw new RuntimeException('The uploaded file is empty.');
        }
        if ($fileSize > $maxBytes) {
            throw new RuntimeException('File size exceeds the maximum limit of ' . $appConfig['max_upload_mb'] . ' MB.');
        }

        $originalName = basename((string) ($file['name'] ?? 'document'));
        // Sanitize original display name
        $originalName = preg_replace('/[^a-zA-Z0-9._\- ]/', '_', $originalName) ?: 'document';

        // Block dangerous double extensions (e.g., .php.pdf, .phtml, .exe, .sh)
        if (preg_match('/\.(php[0-9]?|phtml|phar|exe|sh|bat|cmd|js|jsp|asp|aspx|cgi|pl|py)\b/i', $originalName)) {
            throw new RuntimeException('Security violation: Executable scripts are strictly prohibited.');
        }

        $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        $allowedExtensions = $appConfig['allowed_extensions'] ?? [];
        if ($ext === '' || !in_array($ext, $allowedExtensions, true)) {
            throw new RuntimeException(
                'Unsupported file extension (.' . htmlspecialchars($ext) . '). Allowed types: ' . strtoupper(implode(', ', $allowedExtensions))
            );
        }

        // Inspect actual MIME type using finfo
        $tmpName = (string) $file['tmp_name'];
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $detectedMime = (string) $finfo->file($tmpName);

        $allowedMimes = $appConfig['allowed_mimes'][$ext] ?? [];
        if (!empty($allowedMimes) && !in_array($detectedMime, $allowedMimes, true)) {
            // Also allow generic text/plain for txt or zip-based office containers
            if (!($ext === 'txt' && str_starts_with($detectedMime, 'text/'))) {
                throw new RuntimeException(
                    "File content MIME type ({$detectedMime}) does not match the .{$ext} extension."
                );
            }
        }

        $cleanSubDir = trim(preg_replace('/[^a-zA-Z0-9_\-]/', '', $subDirectory), '/');
        $storageRoot = dirname(__DIR__, 2) . '/storage/uploads/' . $cleanSubDir;
        if (!is_dir($storageRoot)) {
            mkdir($storageRoot, 0755, true);
        }

        $randomFileName = sprintf('%s_%s.%s', date('Ymd_His'), bin2hex(random_bytes(12)), $ext);
        $destination = $storageRoot . '/' . $randomFileName;

        if (!move_uploaded_file($tmpName, $destination)) {
            // Fallback for CLI automated test environment where move_uploaded_file is simulated
            if (PHP_SAPI === 'cli' && is_file($tmpName) && copy($tmpName, $destination)) {
                @unlink($tmpName);
            } else {
                throw new RuntimeException('Failed to store uploaded file in protected storage.');
            }
        }

        @chmod($destination, 0644);

        return [
            'file_name'     => $randomFileName,
            'original_name' => $originalName,
            'file_path'     => $cleanSubDir . '/' . $randomFileName,
            'file_type'     => $ext,
            'mime_type'     => $detectedMime,
            'file_size'     => $fileSize,
        ];
    }
}
