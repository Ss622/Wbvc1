<?php
declare(strict_types=1);

namespace App\Helpers;

/**
 * Streams tabular records as a RFC-4180 compliant CSV download with UTF-8 BOM for Excel compatibility.
 */
class CsvExporter
{
    public static function download(string $filename, array $headers, array $rows): never
    {
        $safeName = preg_replace('/[^a-zA-Z0-9_\-.]/', '_', $filename) ?: 'report.csv';
        if (!str_ends_with(strtolower($safeName), '.csv')) {
            $safeName .= '.csv';
        }

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $safeName . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $out = fopen('php://output', 'w');
        if ($out !== false) {
            // Write UTF-8 BOM for seamless Microsoft Excel opening
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, $headers);
            foreach ($rows as $row) {
                fputcsv($out, $row);
            }
            fclose($out);
        }
        exit;
    }
}
