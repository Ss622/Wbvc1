<?php
declare(strict_types=1);

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Router;

/**
 * Escapes output safely against XSS attacks.
 */
function e(mixed $value): string
{
    if ($value === null) {
        return '';
    }
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Generates an application URL compatible with XAMPP subdirectories with or without mod_rewrite.
 */
function base_url(string $path = ''): string
{
    $scriptName = $_SERVER['SCRIPT_NAME'] ?? '/public/index.php';
    $baseDir = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
    $path = ltrim($path, '/');
    return ($baseDir === '' ? '' : $baseDir) . ($path !== '' ? '/' . $path : '');
}

/**
 * Generates an internal route URL using ?r=route for 100% portable XAMPP navigation.
 */
function route_url(string $route, array $params = []): string
{
    $route = trim($route, '/');
    $query = array_merge(['r' => $route], $params);
    return base_url('index.php') . '?' . http_build_query($query);
}

/**
 * Checks if current active route starts with any of the given prefixes.
 */
function is_active_route(string|array $prefixes): string
{
    $current = Router::currentRoute();
    foreach ((array) $prefixes as $prefix) {
        if ($current === $prefix || str_starts_with($current, rtrim($prefix, '/') . '/')) {
            return 'active';
        }
    }
    return '';
}

/**
 * Outputs a hidden CSRF token input field.
 */
function csrf_field(): string
{
    return Csrf::field();
}

/**
 * Formats a date or datetime string cleanly for academic tables.
 */
function format_date(?string $dateStr, string $format = 'd M Y'): string
{
    if (empty($dateStr)) {
        return '—';
    }
    $ts = strtotime($dateStr);
    return $ts !== false ? date($format, $ts) : e($dateStr);
}

/**
 * Formats a datetime string with time.
 */
function format_datetime(?string $dateStr): string
{
    return format_date($dateStr, 'd M Y, h:i A');
}

/**
 * Formats file size in human-readable KB / MB.
 */
function format_bytes(int $bytes): string
{
    if ($bytes <= 0) {
        return '0 KB';
    }
    if ($bytes < 1024) {
        return $bytes . ' B';
    }
    if ($bytes < 1048576) {
        return round($bytes / 1024, 1) . ' KB';
    }
    return round($bytes / 1048576, 2) . ' MB';
}

/**
 * Maps status/priority keywords to semantic badge CSS classes.
 */
function status_badge_class(string $status): string
{
    return match (strtolower(trim($status))) {
        'active', 'published', 'present', 'completed', 'open', 'a+', 'a' => 'badge-success',
        'pending', 'submitted', 'in_progress', 'due', 'important', 'evaluated', 'b', 'c' => 'badge-warning',
        'inactive', 'absent', 'closed', 'urgent', 'late', 'dropped', 'expired', 'f' => 'badge-danger',
        'draft', 'archived', 'normal', 'd' => 'badge-neutral',
        default => 'badge-info',
    };
}
