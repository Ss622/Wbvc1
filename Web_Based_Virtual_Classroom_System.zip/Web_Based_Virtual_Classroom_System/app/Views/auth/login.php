<?php
declare(strict_types=1);
?>
<div class="auth-card">
    <div class="auth-header">
        <img src="<?= base_url('assets/images/logo.svg') ?>" alt="Virtual Classroom Logo">
        <h1 class="auth-title">Web-Based Virtual Classroom</h1>
        <p class="auth-subtitle">IGNOU BCA Project (BCSP-064) • Academic Portal</p>
    </div>

    <?php require dirname(__DIR__) . '/partials/flash.php'; ?>

    <form method="post" action="<?= route_url('login') ?>" autocomplete="on">
        <?= csrf_field() ?>

        <div class="form-group">
            <label for="identifier" class="form-label">Email Address or Enrolment / Staff ID <span class="req">*</span></label>
            <input type="text" id="identifier" name="identifier" class="form-control"
                   placeholder="e.g. sahil.alam@ignou-vc.edu.in or 2200080265" required autofocus>
        </div>

        <div class="form-group">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <label for="password" class="form-label">Password <span class="req">*</span></label>
                <button type="button" class="btn btn-sm btn-outline" style="padding:2px 8px; font-size:11px;"
                        data-toggle-password="password">Show</button>
            </div>
            <input type="password" id="password" name="password" class="form-control"
                   placeholder="Enter your account password" required>
        </div>

        <button type="submit" class="btn btn-primary" style="width:100%; padding:11px; margin-top:6px;">
            Sign In to Virtual Classroom
        </button>
    </form>

    <div class="demo-credentials-box">
        <h4>Quick-Fill Demonstration Accounts (Seed Data)</h4>
        <div class="demo-cred-row">
            <div>
                <strong>Admin:</strong> admin@ignou-vc.edu.in<br>
                <span style="color:var(--slate-500);">Pass: Admin@123</span>
            </div>
            <button type="button" class="btn btn-sm btn-outline"
                    data-fill-login data-email="admin@ignou-vc.edu.in" data-pass="Admin@123">Fill Admin</button>
        </div>
        <div class="demo-cred-row">
            <div>
                <strong>Teacher:</strong> krishan.mishra@ignou-vc.edu.in<br>
                <span style="color:var(--slate-500);">Pass: Teacher@123 (Prof. K. D. Mishra)</span>
            </div>
            <button type="button" class="btn btn-sm btn-outline"
                    data-fill-login data-email="krishan.mishra@ignou-vc.edu.in" data-pass="Teacher@123">Fill Teacher</button>
        </div>
        <div class="demo-cred-row">
            <div>
                <strong>Student:</strong> sahil.alam@ignou-vc.edu.in<br>
                <span style="color:var(--slate-500);">Pass: Student@123 (Enrol: 2200080265)</span>
            </div>
            <button type="button" class="btn btn-sm btn-outline"
                    data-fill-login data-email="sahil.alam@ignou-vc.edu.in" data-pass="Student@123">Fill Student</button>
        </div>
    </div>
</div>
