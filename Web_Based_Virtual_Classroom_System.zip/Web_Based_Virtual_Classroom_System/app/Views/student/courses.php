<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">My Enrolled Courses</h1>
        <p class="page-subtitle">Explore course descriptions, assigned faculty, study materials, assignments, quizzes, and announcements.</p>
    </div>
</div>

<div class="card">
    <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
        <input type="hidden" name="r" value="student/courses">
        <input type="search" name="q" placeholder="Search enrolled courses by code, title, or teacher..." value="<?= e($search) ?>" style="flex:1;">
        <button type="submit" class="btn btn-sm btn-primary">Search</button>
    </form>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Course Title & Description</th>
                    <th>Semester & Credits</th>
                    <th>Assigned Teacher</th>
                    <th>Resources</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($courses)): ?>
                    <tr><td colspan="6" class="empty-state">No enrolled courses found.</td></tr>
                <?php else: ?>
                    <?php foreach ($courses as $c): ?>
                    <tr>
                        <td><strong><?= e($c['course_code']) ?></strong></td>
                        <td>
                            <strong><?= e($c['course_name']) ?></strong>
                            <div style="font-size:12.5px; color:var(--slate-500);"><?= e($c['description']) ?></div>
                        </td>
                        <td><?= e($c['semester']) ?> (<?= (int) $c['credits'] ?> Cr)</td>
                        <td><?= e($c['teacher_name'] ?: 'TBA') ?></td>
                        <td>
                            <?= (int) $c['material_count'] ?> Materials •
                            <?= (int) $c['assignment_count'] ?> Assignments •
                            <?= (int) $c['quiz_count'] ?> Quizzes
                        </td>
                        <td>
                            <a href="<?= route_url('student/courses', ['course_id' => $c['course_id']]) ?>" class="btn btn-sm btn-primary">Open Details</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if (!empty($selectedCourse)): ?>
<div class="card">
    <div class="card-header">
        <div>
            <h2 class="card-title"><?= e($selectedCourse['course_code']) ?> — <?= e($selectedCourse['course_name']) ?></h2>
            <small style="color:var(--slate-500);">Instructor: <?= e($selectedCourse['teacher_name'] ?: 'TBA') ?> (<?= e($selectedCourse['teacher_qualification'] ?? '') ?>)</small>
        </div>
        <div class="btn-group">
            <a href="<?= route_url('student/materials', ['course_id' => $selectedCourse['course_id']]) ?>" class="btn btn-sm btn-outline">Materials (<?= count($courseMaterials) ?>)</a>
            <a href="<?= route_url('student/assignments', ['course_id' => $selectedCourse['course_id']]) ?>" class="btn btn-sm btn-outline">Assignments (<?= count($courseAssignments) ?>)</a>
            <a href="<?= route_url('student/quizzes', ['course_id' => $selectedCourse['course_id']]) ?>" class="btn btn-sm btn-teal">Quizzes (<?= count($courseQuizzes) ?>)</a>
        </div>
    </div>
    <div class="card-body">
        <p style="margin-top:0;"><?= e($selectedCourse['description']) ?></p>

        <div class="grid-2" style="margin-bottom:0;">
            <div>
                <h3 style="font-size:15px; margin-bottom:8px;">Course Materials</h3>
                <?php if (empty($courseMaterials)): ?>
                    <p style="color:var(--slate-500); font-size:13px;">No study materials uploaded yet.</p>
                <?php else: ?>
                    <?php foreach ($courseMaterials as $m): ?>
                        <div style="padding:8px 0; border-bottom:1px solid var(--slate-100); display:flex; justify-content:space-between; align-items:center;">
                            <div>
                                <strong><?= e($m['title']) ?></strong> (<code>.<?= e($m['file_type']) ?></code>)
                            </div>
                            <a href="<?= route_url('download/material', ['id' => $m['material_id']]) ?>" class="btn btn-sm btn-outline">Download</a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div>
                <h3 style="font-size:15px; margin-bottom:8px;">Course Notices</h3>
                <?php if (empty($courseNotices)): ?>
                    <p style="color:var(--slate-500); font-size:13px;">No course-specific notices.</p>
                <?php else: ?>
                    <?php foreach ($courseNotices as $cn): ?>
                        <div style="padding:8px 0; border-bottom:1px solid var(--slate-100);">
                            <strong><?= e($cn['title']) ?></strong>
                            <div style="font-size:12.5px; color:var(--slate-600);"><?= e($cn['description']) ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
