<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">My Quiz Attempts & Scores</h1>
        <p class="page-subtitle">Review your completed objective quiz attempts, percentages, and question-by-question answer keys.</p>
    </div>
    <a href="<?= route_url('student/quizzes') ?>" class="btn btn-outline">&larr; Back to Quizzes</a>
</div>

<?php if (!empty($selectedAttempt)): ?>
<div class="card">
    <div class="card-header">
        <div>
            <h2 class="card-title">Detailed Breakdown: <?= e($selectedAttempt['quiz_title']) ?> (Attempt #<?= (int) $selectedAttempt['attempt_number'] ?>)</h2>
            <small style="color:var(--slate-500);">Submitted: <?= format_datetime($selectedAttempt['submitted_at']) ?></small>
        </div>
        <div>
            <span class="badge badge-success" style="font-size:14px; padding:6px 12px;">
                Score: <?= e($selectedAttempt['score']) ?> / <?= e($selectedAttempt['total_marks']) ?> (<?= e($selectedAttempt['percentage']) ?>%)
            </span>
        </div>
    </div>
    <div class="card-body">
        <?php foreach ($selectedAttempt['answers'] as $idx => $ans): ?>
            <div class="quiz-question-card" style="border-left:4px solid <?= !empty($ans['is_correct']) ? '#16a34a' : '#dc2626' ?>;">
                <div style="display:flex; justify-content:space-between;">
                    <strong>Q<?= $idx + 1 ?>. <?= e($ans['question_text']) ?></strong>
                    <span class="badge <?= !empty($ans['is_correct']) ? 'badge-success' : 'badge-danger' ?>">
                        <?= e($ans['marks_awarded']) ?> / <?= e($ans['max_question_marks']) ?> Marks
                    </span>
                </div>
                <div style="margin-top:8px; font-size:13.5px;">
                    Your Selection: <strong><?= e($ans['selected_option'] ?: 'Unanswered') ?></strong> •
                    <?php if (!empty($selectedAttempt['results_published'])): ?>
                        Correct Answer: <strong style="color:#166534;"><?= e($ans['correct_option']) ?></strong>
                        <?php if (!empty($ans['explanation'])): ?>
                            <div style="color:var(--slate-500); margin-top:4px;"><em>Explanation: <?= e($ans['explanation']) ?></em></div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Completed Quiz Attempts (<?= count($attempts) ?>)</h2>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Quiz Title</th>
                    <th>Attempt #</th>
                    <th>Score</th>
                    <th>Percentage</th>
                    <th>Submitted At</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($attempts)): ?>
                    <tr><td colspan="7" class="empty-state">You have not completed any online quizzes yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($attempts as $atp): ?>
                    <tr>
                        <td><strong><?= e($atp['course_code']) ?></strong></td>
                        <td><?= e($atp['quiz_title']) ?></td>
                        <td>#<?= (int) $atp['attempt_number'] ?></td>
                        <td><strong><?= e($atp['score']) ?> / <?= e($atp['total_marks']) ?></strong></td>
                        <td><span class="badge <?= ((float) $atp['percentage'] >= 40) ? 'badge-success' : 'badge-danger' ?>"><?= e($atp['percentage']) ?>%</span></td>
                        <td><?= format_datetime($atp['submitted_at']) ?></td>
                        <td>
                            <a href="<?= route_url('student/quiz-results', ['attempt_id' => $atp['attempt_id']]) ?>" class="btn btn-sm btn-outline">Inspect Answers</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
