<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">My Attendance Summary & History</h1>
        <p class="page-subtitle">Course-wise attendance percentage and date-by-date class presence records. Overall Attendance: <strong><?= e($overallPercent) ?>%</strong></p>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Course-Wise Attendance Summary</h2>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Teacher</th>
                    <th>Total Classes</th>
                    <th>Present</th>
                    <th>Absent</th>
                    <th>Attendance %</th>
                    <th>Filter Log</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courseSummaries as $cs): ?>
                <tr>
                    <td><strong><?= e($cs['course_code']) ?></strong></td>
                    <td><?= e($cs['course_name']) ?></td>
                    <td><?= e($cs['teacher_name'] ?: 'TBA') ?></td>
                    <td><?= (int) $cs['total_classes'] ?></td>
                    <td><?= (int) $cs['present_classes'] ?></td>
                    <td><?= (int) $cs['absent_classes'] ?></td>
                    <td>
                        <strong><?= e($cs['percentage']) ?>%</strong>
                        <div class="progress-track" style="margin-top:4px; max-width:130px;">
                            <div class="progress-fill" style="width:<?= min(100, (float) $cs['percentage']) ?>%;"></div>
                        </div>
                    </td>
                    <td>
                        <a href="<?= route_url('student/attendance', ['course_id' => $cs['course_id']]) ?>" class="btn btn-sm btn-outline">View Dates</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Date-Wise Attendance History (<?= count($history) ?> Classes)</h2>
        <?php if ($selectedCourseId): ?>
            <a href="<?= route_url('student/attendance') ?>" class="btn btn-sm btn-outline">Show All Courses</a>
        <?php endif; ?>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Class Date</th>
                    <th>Course</th>
                    <th>Status</th>
                    <th>Remarks</th>
                    <th>Recorded By</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($history)): ?>
                    <tr><td colspan="5" class="empty-state">No attendance records found.</td></tr>
                <?php else: ?>
                    <?php foreach ($history as $h): ?>
                    <tr>
                        <td><strong><?= format_date($h['class_date']) ?></strong></td>
                        <td><?= e($h['course_code']) ?> — <?= e($h['course_name']) ?></td>
                        <td><span class="badge <?= status_badge_class($h['status']) ?>"><?= e($h['status']) ?></span></td>
                        <td><?= e($h['remarks'] ?: '—') ?></td>
                        <td><?= e($h['recorded_by_name']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
