<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Notices & Academic Announcements</h1>
        <p class="page-subtitle">Stay updated with institution-wide circulars and announcements from your enrolled courses.</p>
    </div>
</div>

<div class="card">
    <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
        <input type="hidden" name="r" value="student/notices">
        <input type="search" name="q" placeholder="Search notice title or content..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1;">
        <select name="priority">
            <option value="">All Priorities</option>
            <option value="urgent" <?= (($filters['priority'] ?? '') === 'urgent') ? 'selected' : '' ?>>Urgent</option>
            <option value="important" <?= (($filters['priority'] ?? '') === 'important') ? 'selected' : '' ?>>Important</option>
            <option value="normal" <?= (($filters['priority'] ?? '') === 'normal') ? 'selected' : '' ?>>Normal</option>
        </select>
        <button type="submit" class="btn btn-sm btn-primary">Filter</button>
    </form>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Announcement Title & Details</th>
                    <th>Course / Audience</th>
                    <th>Priority</th>
                    <th>Published By & Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($notices)): ?>
                    <tr><td colspan="4" class="empty-state">No notices matched your search.</td></tr>
                <?php else: ?>
                    <?php foreach ($notices as $n): ?>
                    <tr>
                        <td>
                            <strong><?= e($n['title']) ?></strong>
                            <div style="font-size:13.5px; color:var(--slate-600); margin-top:4px;"><?= nl2br(e($n['description'])) ?></div>
                        </td>
                        <td>
                            <span class="badge badge-info"><?= e($n['course_code'] ?: strtoupper($n['audience'])) ?></span>
                        </td>
                        <td><span class="badge <?= status_badge_class($n['priority']) ?>"><?= e($n['priority']) ?></span></td>
                        <td>
                            <?= e($n['author_name']) ?><br>
                            <small style="color:var(--slate-500);"><?= format_datetime($n['published_at']) ?></small>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
