<?php
declare(strict_types=1);
?>
<div class="quiz-timer-banner">
    <div>
        <strong><?= e($quiz['course_code']) ?> — <?= e($quiz['title']) ?></strong><br>
        <small style="color:#cbd5e1;"><?= count($questions) ?> Questions • Total Marks: <?= e($quiz['total_marks']) ?></small>
    </div>
    <div style="text-align:right;">
        <span style="font-size:12px; text-transform:uppercase; color:#93c5fd;">Remaining Time</span><br>
        <strong id="quizTimerDisplay" data-remaining-seconds="<?= (int) $remainingSeconds ?>" style="font-size:22px; font-family:monospace;">
            <?= sprintf('%02d:%02d', intdiv((int) $remainingSeconds, 60), ((int) $remainingSeconds) % 60) ?>
        </strong>
    </div>
</div>

<form method="post" action="<?= route_url('student/quizzes/submit') ?>" id="quizAttemptForm" data-confirm="Submit your quiz answers now for final grading?">
    <?= csrf_field() ?>
    <input type="hidden" name="attempt_id" value="<?= (int) $attemptId ?>">

    <?php foreach ($questions as $idx => $qn):
        $qid = (int) $qn['question_id'];
    ?>
        <div class="quiz-question-card">
            <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                <strong>Question <?= $idx + 1 ?> of <?= count($questions) ?></strong>
                <span class="badge badge-info"><?= e($qn['marks']) ?> Marks</span>
            </div>
            <p style="font-size:15.5px; font-weight:600; margin:0 0 14px;"><?= e($qn['question_text']) ?></p>

            <?php foreach ($qn['options'] as $opt): ?>
                <label class="quiz-option-label">
                    <input type="radio" name="answers[<?= $qid ?>]" value="<?= e($opt['option_label']) ?>">
                    <span><strong><?= e($opt['option_label']) ?>.</strong> <?= e($opt['option_text']) ?></span>
                </label>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>

    <div class="card">
        <div class="card-body" style="display:flex; justify-content:space-between; align-items:center;">
            <span style="color:var(--slate-600); font-size:13.5px;">Verify that you have answered all questions before submitting.</span>
            <button type="submit" class="btn btn-primary" style="padding:11px 24px;">Submit Quiz & View Score</button>
        </div>
    </div>
</form>
