<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">My Academic Results & Grade Card</h1>
        <p class="page-subtitle">Consolidated course-wise performance derived from published assignment marks, quiz scores, and attendance.</p>
    </div>
    <button type="button" onclick="window.print()" class="btn btn-outline no-print">🖨️ Print Grade Card</button>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Consolidated Course Results</h2>
        <span style="font-size:12px; color:var(--slate-500);">Grading: A+ (&ge;80%), A (70-79%), B (60-69%), C (50-59%), D (40-49%), F (&lt;40%)</span>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Credits</th>
                    <th>Assignment Marks</th>
                    <th>Quiz Marks</th>
                    <th>Attendance %</th>
                    <th>Overall %</th>
                    <th>Grade</th>
                    <th>Standing / Remarks</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($results)): ?>
                    <tr><td colspan="9" class="empty-state">No published course results available yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($results as $r): ?>
                    <tr>
                        <td><strong><?= e($r['course_code']) ?></strong></td>
                        <td><?= e($r['course_name']) ?></td>
                        <td><?= (int) $r['credits'] ?></td>
                        <td><?= e($r['assignment_marks_obtained']) ?> / <?= e($r['assignment_marks_max']) ?></td>
                        <td><?= e($r['quiz_marks_obtained']) ?> / <?= e($r['quiz_marks_max']) ?></td>
                        <td><?= e($r['attendance_percentage']) ?>%</td>
                        <td><strong><?= e($r['overall_percentage']) ?>%</strong></td>
                        <td><span class="badge <?= status_badge_class($r['grade']) ?>"><?= e($r['grade']) ?></span></td>
                        <td><?= e($r['remarks'] ?: '—') ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Published Assignment Evaluations</h2>
        </div>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Course</th>
                        <th>Assignment</th>
                        <th>Marks</th>
                        <th>Feedback</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($publishedSubmissions)): ?>
                        <tr><td colspan="4" class="empty-state">No published assignment evaluations yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($publishedSubmissions as $ps): ?>
                        <tr>
                            <td><strong><?= e($ps['course_code']) ?></strong></td>
                            <td><?= e($ps['assignment_title']) ?></td>
                            <td><strong><?= e($ps['marks']) ?> / <?= e($ps['max_marks']) ?></strong></td>
                            <td><?= e($ps['feedback'] ?: '—') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Completed Quiz Scores</h2>
        </div>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Course</th>
                        <th>Quiz</th>
                        <th>Score</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($quizAttempts)): ?>
                        <tr><td colspan="4" class="empty-state">No quiz scores recorded yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($quizAttempts as $qa): ?>
                        <tr>
                            <td><strong><?= e($qa['course_code']) ?></strong></td>
                            <td><?= e($qa['quiz_title']) ?></td>
                            <td><strong><?= e($qa['score']) ?> / <?= e($qa['total_marks']) ?></strong></td>
                            <td><span class="badge badge-success"><?= e($qa['percentage']) ?>%</span></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
