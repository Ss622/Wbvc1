<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Course Assignments & Online Submission</h1>
        <p class="page-subtitle">Read assignment instructions, download reference files, and submit your written work or attachment before the deadline.</p>
    </div>
    <a href="<?= route_url('student/submissions') ?>" class="btn btn-outline">View My Submissions</a>
</div>

<div class="card">
    <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
        <input type="hidden" name="r" value="student/assignments">
        <input type="search" name="q" placeholder="Search assignment title or course..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1;">
        <select name="course_id">
            <option value="0">All Enrolled Courses</option>
            <?php foreach ($courses as $c): ?>
                <option value="<?= (int) $c['course_id'] ?>" <?= ((int) ($filters['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                    <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-sm btn-primary">Filter</button>
    </form>

    <div class="card-body">
        <?php if (empty($assignments)): ?>
            <div class="empty-state">No assignments found for your enrolled courses.</div>
        <?php else: ?>
            <?php foreach ($assignments as $a):
                $subStatus = $a['submission_status'] ?? 'Not Submitted';
                $isLocked = in_array($subStatus, ['evaluated', 'published'], true) || ($a['status'] === 'closed');
            ?>
                <div class="quiz-question-card">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px;">
                        <div>
                            <span class="badge badge-info"><?= e($a['course_code']) ?> — <?= e($a['course_name']) ?></span>
                            <h3 style="margin:6px 0; font-size:17px;"><?= e($a['title']) ?></h3>
                            <div style="font-size:13px; color:var(--slate-500);">
                                Issue Date: <strong><?= format_date($a['issue_date']) ?></strong> •
                                Due Date: <strong><?= format_date($a['due_date']) ?></strong> •
                                Maximum Marks: <strong><?= e($a['max_marks']) ?></strong>
                            </div>
                        </div>
                        <div>
                            <span class="badge <?= status_badge_class($subStatus) ?>"><?= e($subStatus) ?></span>
                            <?php if ($subStatus === 'published' && $a['awarded_marks'] !== null): ?>
                                <span class="badge badge-success" style="margin-left:6px;">Marks: <?= e($a['awarded_marks']) ?> / <?= e($a['max_marks']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <p style="margin:12px 0; color:var(--slate-700);"><?= nl2br(e($a['description'])) ?></p>

                    <?php if (!empty($a['attachment_path'])): ?>
                        <div style="margin-bottom:12px;">
                            <a href="<?= route_url('download/assignment', ['id' => $a['assignment_id']]) ?>" class="btn btn-sm btn-outline">
                                📎 Download Assignment Reference (<?= e($a['attachment_name'] ?: 'Document') ?>)
                            </a>
                        </div>
                    <?php endif; ?>

                    <?php if ($subStatus === 'published' && !empty($a['feedback'])): ?>
                        <div class="alert alert-info" style="margin-bottom:12px;">
                            <div><strong>Teacher Evaluation Feedback:</strong> <?= e($a['feedback']) ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if (!$isLocked): ?>
                        <form method="post" action="<?= route_url('student/assignments/submit') ?>" enctype="multipart/form-data" style="background:var(--slate-50); padding:14px; border-radius:8px; border:1px solid var(--slate-200);">
                            <?= csrf_field() ?>
                            <input type="hidden" name="assignment_id" value="<?= (int) $a['assignment_id'] ?>">
                            <div class="form-group" style="margin-bottom:10px;">
                                <label class="form-label"><?= !empty($a['submission_id']) ? 'Update Written Response' : 'Written Response / Summary' ?></label>
                                <textarea name="text_response" class="form-control" rows="2" placeholder="Enter your assignment solution notes or summary..."></textarea>
                            </div>
                            <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap;">
                                <input type="file" name="submission_file" class="form-control" style="max-width:360px;">
                                <button type="submit" class="btn btn-primary">
                                    <?= !empty($a['submission_id']) ? 'Resubmit Assignment' : 'Submit Assignment' ?>
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
