<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">My Assignment Submissions</h1>
        <p class="page-subtitle">Track submission timestamps, uploaded attachments, evaluation status, and published faculty marks.</p>
    </div>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Assignment Title</th>
                    <th>Submitted Work</th>
                    <th>Submitted At</th>
                    <th>Status</th>
                    <th>Awarded Marks</th>
                    <th>Teacher Feedback</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($submissions)): ?>
                    <tr><td colspan="7" class="empty-state">You have not submitted any assignments yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($submissions as $s): ?>
                    <tr>
                        <td><strong><?= e($s['course_code']) ?></strong></td>
                        <td><?= e($s['assignment_title']) ?></td>
                        <td>
                            <?php if (!empty($s['text_response'])): ?>
                                <div style="font-size:12.5px; color:var(--slate-600); max-width:280px;"><?= e($s['text_response']) ?></div>
                            <?php endif; ?>
                            <?php if (!empty($s['file_path'])): ?>
                                <a href="<?= route_url('download/submission', ['id' => $s['submission_id']]) ?>" style="font-size:12.5px;">
                                    📥 <?= e($s['original_name'] ?: 'Download Attachment') ?>
                                </a>
                            <?php endif; ?>
                        </td>
                        <td><?= format_datetime($s['submitted_at']) ?></td>
                        <td><span class="badge <?= status_badge_class($s['status']) ?>"><?= e($s['status']) ?></span></td>
                        <td>
                            <?php if ($s['status'] === 'published' && $s['marks'] !== null): ?>
                                <strong><?= e($s['marks']) ?> / <?= e($s['max_marks']) ?></strong>
                            <?php else: ?>
                                <span style="color:var(--slate-400);">Awaiting Publication</span>
                            <?php endif; ?>
                        </td>
                        <td><?= ($s['status'] === 'published' && !empty($s['feedback'])) ? e($s['feedback']) : '—' ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
