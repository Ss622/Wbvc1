<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Online Objective Quizzes</h1>
        <p class="page-subtitle">Attempt timed multiple-choice quizzes for your enrolled courses and receive instant server-calculated scores.</p>
    </div>
    <a href="<?= route_url('student/quiz-results') ?>" class="btn btn-outline">My Quiz History</a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Quiz Title & Instructions</th>
                    <th>Questions & Marks</th>
                    <th>Time Limit</th>
                    <th>Attempts Used</th>
                    <th>Best Score</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($quizzes)): ?>
                    <tr><td colspan="7" class="empty-state">No online quizzes available for your enrolled courses.</td></tr>
                <?php else: ?>
                    <?php foreach ($quizzes as $q):
                        $used = (int) $q['student_attempts'];
                        $allowed = (int) $q['allowed_attempts'];
                        $canAttempt = ($used < $allowed) && ((int) $q['question_count'] > 0);
                    ?>
                    <tr>
                        <td><strong><?= e($q['course_code']) ?></strong></td>
                        <td>
                            <strong><?= e($q['title']) ?></strong>
                            <div style="font-size:12.5px; color:var(--slate-500);"><?= e($q['description']) ?></div>
                        </td>
                        <td><?= (int) $q['question_count'] ?> Qs • <strong><?= e($q['total_marks']) ?> Marks</strong></td>
                        <td><?= (int) $q['duration_minutes'] ?> Minutes</td>
                        <td><?= $used ?> / <?= $allowed ?></td>
                        <td>
                            <?php if ($q['best_score'] !== null): ?>
                                <span class="badge badge-success"><?= e($q['best_score']) ?> / <?= e($q['total_marks']) ?></span>
                            <?php else: ?>
                                <span style="color:var(--slate-400);">Not Attempted</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($canAttempt): ?>
                                <a href="<?= route_url('student/quizzes/take', ['quiz_id' => $q['quiz_id']]) ?>" class="btn btn-sm btn-primary">
                                    <?= $used > 0 ? 'Retake Quiz' : 'Start Quiz' ?>
                                </a>
                            <?php else: ?>
                                <a href="<?= route_url('student/quiz-results') ?>" class="btn btn-sm btn-outline">View Score</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
