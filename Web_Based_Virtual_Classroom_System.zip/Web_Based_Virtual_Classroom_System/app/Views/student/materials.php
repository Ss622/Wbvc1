<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Course Learning Materials</h1>
        <p class="page-subtitle">Access and download lecture notes, syllabi, lab manuals, and study resources for your enrolled courses.</p>
    </div>
</div>

<div class="card">
    <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
        <input type="hidden" name="r" value="student/materials">
        <input type="search" name="q" placeholder="Search material title, description, or course..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1;">
        <select name="course_id">
            <option value="0">All Enrolled Courses</option>
            <?php foreach ($courses as $c): ?>
                <option value="<?= (int) $c['course_id'] ?>" <?= ((int) ($filters['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                    <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-sm btn-primary">Filter</button>
    </form>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Material Title & Description</th>
                    <th>Category</th>
                    <th>File Type & Size</th>
                    <th>Uploaded Date</th>
                    <th>Download</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($materials)): ?>
                    <tr><td colspan="6" class="empty-state">No learning materials available for the selected filter.</td></tr>
                <?php else: ?>
                    <?php foreach ($materials as $m): ?>
                    <tr>
                        <td>
                            <strong><?= e($m['course_code']) ?></strong><br>
                            <small style="color:var(--slate-500);"><?= e($m['course_name']) ?></small>
                        </td>
                        <td>
                            <strong><?= e($m['title']) ?></strong>
                            <div style="font-size:12.5px; color:var(--slate-500);"><?= e($m['description']) ?></div>
                        </td>
                        <td><span class="badge badge-info"><?= e($m['category']) ?></span></td>
                        <td><code>.<?= e(strtoupper($m['file_type'])) ?></code> (<?= format_bytes((int) $m['file_size']) ?>)</td>
                        <td><?= format_date($m['created_at']) ?></td>
                        <td>
                            <a href="<?= route_url('download/material', ['id' => $m['material_id']]) ?>" class="btn btn-sm btn-teal">⬇ Download</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
