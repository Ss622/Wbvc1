<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Student Academic Dashboard</h1>
        <p class="page-subtitle">Track your enrolled courses, study materials, assignment deadlines, online quizzes, attendance, and published results.</p>
    </div>
    <div class="btn-group">
        <a href="<?= route_url('student/courses') ?>" class="btn btn-primary">My Courses</a>
        <a href="<?= route_url('student/quizzes') ?>" class="btn btn-teal">Attempt Quizzes</a>
        <a href="<?= route_url('student/results') ?>" class="btn btn-outline">View Transcript</a>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <span class="stat-card-label">Enrolled Courses</span>
        <span class="stat-card-value"><?= (int) $stats['enrolled_courses'] ?></span>
        <span class="stat-card-hint">Active BCA Courses</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Pending Assignments</span>
        <span class="stat-card-value"><?= (int) $stats['pending_assignments'] ?></span>
        <span class="stat-card-hint"><?= (int) $stats['submitted_assignments'] ?> Already Submitted</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Available Quizzes</span>
        <span class="stat-card-value"><?= (int) $stats['upcoming_quizzes'] ?></span>
        <span class="stat-card-hint"><?= (int) $stats['completed_quizzes'] ?> Completed</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Overall Attendance</span>
        <span class="stat-card-value"><?= e($stats['attendance_percentage']) ?>%</span>
        <span class="stat-card-hint">Min 75% Recommended</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Published Results</span>
        <span class="stat-card-value"><?= (int) $stats['published_results'] ?></span>
        <span class="stat-card-hint">Course Evaluations</span>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">My Enrolled Courses</h2>
        <a href="<?= route_url('student/courses') ?>" class="btn btn-sm btn-outline">Open Course Portal</a>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Semester</th>
                    <th>Faculty Teacher</th>
                    <th>Materials</th>
                    <th>Assignments</th>
                    <th>Quizzes</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($enrolledCourses)): ?>
                    <tr><td colspan="8" class="empty-state">You are not enrolled in any courses yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($enrolledCourses as $c): ?>
                    <tr>
                        <td><strong><?= e($c['course_code']) ?></strong></td>
                        <td><?= e($c['course_name']) ?></td>
                        <td><?= e($c['semester']) ?></td>
                        <td><?= e($c['teacher_name'] ?: 'TBA') ?></td>
                        <td><?= (int) $c['material_count'] ?></td>
                        <td><?= (int) $c['assignment_count'] ?></td>
                        <td><?= (int) $c['quiz_count'] ?></td>
                        <td>
                            <a href="<?= route_url('student/courses', ['course_id' => $c['course_id']]) ?>" class="btn btn-sm btn-primary">Open Classroom</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Assignments & Submission Status</h2>
            <a href="<?= route_url('student/assignments') ?>" class="btn btn-sm btn-outline">All Assignments</a>
        </div>
        <div class="card-body">
            <?php if (empty($assignments)): ?>
                <div class="empty-state">No assignments posted for your courses.</div>
            <?php else: ?>
                <?php foreach ($assignments as $a):
                    $subStatus = $a['submission_status'] ?? 'Not Submitted';
                ?>
                    <div style="padding:10px 0; border-bottom:1px solid var(--slate-100); display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <strong>[<?= e($a['course_code']) ?>] <?= e($a['title']) ?></strong><br>
                            <small style="color:var(--slate-500);">Due: <?= format_date($a['due_date']) ?> • Max: <?= e($a['max_marks']) ?> Marks</small>
                        </div>
                        <span class="badge <?= status_badge_class($subStatus) ?>"><?= e($subStatus) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Recent Announcements</h2>
            <a href="<?= route_url('student/notices') ?>" class="btn btn-sm btn-outline">All Notices</a>
        </div>
        <div class="card-body">
            <?php if (empty($notices)): ?>
                <div class="empty-state">No announcements published.</div>
            <?php else: ?>
                <?php foreach ($notices as $n): ?>
                    <div style="padding:8px 0; border-bottom:1px solid var(--slate-100);">
                        <div style="display:flex; justify-content:space-between;">
                            <strong><?= e($n['title']) ?></strong>
                            <span class="badge <?= status_badge_class($n['priority']) ?>"><?= e($n['priority']) ?></span>
                        </div>
                        <p style="margin:4px 0; font-size:13px; color:var(--slate-600);"><?= e($n['description']) ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
