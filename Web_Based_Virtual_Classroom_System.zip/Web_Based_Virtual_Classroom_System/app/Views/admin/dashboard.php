<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Administrator Dashboard</h1>
        <p class="page-subtitle">Real-time institutional overview of users, courses, enrollments, assessments, and system activity.</p>
    </div>
    <div class="btn-group">
        <a href="<?= route_url('admin/users') ?>" class="btn btn-primary">+ Add User</a>
        <a href="<?= route_url('admin/courses') ?>" class="btn btn-teal">+ Create Course</a>
        <a href="<?= route_url('admin/reports') ?>" class="btn btn-outline">Export Reports</a>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <span class="stat-card-label">Total Students</span>
        <span class="stat-card-value"><?= (int) $stats['total_students'] ?></span>
        <span class="stat-card-hint">Enrolled BCA Learners</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Total Teachers</span>
        <span class="stat-card-value"><?= (int) $stats['total_teachers'] ?></span>
        <span class="stat-card-hint">Academic Counsellors</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Administrators</span>
        <span class="stat-card-value"><?= (int) $stats['total_admins'] ?></span>
        <span class="stat-card-hint">System Managers</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Courses (Published)</span>
        <span class="stat-card-value"><?= (int) $stats['published_courses'] ?> / <?= (int) $stats['total_courses'] ?></span>
        <span class="stat-card-hint">Active Course Catalogue</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Active Enrollments</span>
        <span class="stat-card-value"><?= (int) $stats['total_enrollments'] ?></span>
        <span class="stat-card-hint">Student-Course Links</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Assignments & Quizzes</span>
        <span class="stat-card-value"><?= (int) $stats['total_assignments'] ?> / <?= (int) $stats['total_quizzes'] ?></span>
        <span class="stat-card-hint">Published Assessments</span>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Course Overview & Assigned Faculty</h2>
        <a href="<?= route_url('admin/courses') ?>" class="btn btn-sm btn-outline">Manage All Courses</a>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Course Title</th>
                    <th>Semester</th>
                    <th>Assigned Teacher</th>
                    <th>Enrolled</th>
                    <th>Materials</th>
                    <th>Assignments</th>
                    <th>Quizzes</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $c): ?>
                <tr>
                    <td><strong><?= e($c['course_code']) ?></strong></td>
                    <td><?= e($c['course_name']) ?></td>
                    <td><?= e($c['semester']) ?></td>
                    <td><?= e($c['teacher_name'] ?: 'Unassigned') ?></td>
                    <td><?= (int) $c['enrolled_count'] ?></td>
                    <td><?= (int) $c['material_count'] ?></td>
                    <td><?= (int) $c['assignment_count'] ?></td>
                    <td><?= (int) $c['quiz_count'] ?></td>
                    <td><span class="badge <?= status_badge_class($c['status']) ?>"><?= e($c['status']) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Recent Institutional Notices</h2>
            <a href="<?= route_url('admin/notices') ?>" class="btn btn-sm btn-outline">Manage Notices</a>
        </div>
        <div class="card-body">
            <?php if (empty($recentNotices)): ?>
                <div class="empty-state">No announcements published yet.</div>
            <?php else: ?>
                <?php foreach ($recentNotices as $n): ?>
                    <div style="padding:10px 0; border-bottom:1px solid var(--slate-100);">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <strong><?= e($n['title']) ?></strong>
                            <span class="badge <?= status_badge_class($n['priority']) ?>"><?= e($n['priority']) ?></span>
                        </div>
                        <p style="margin:4px 0; font-size:13px; color:var(--slate-600);"><?= e($n['description']) ?></p>
                        <small style="color:var(--slate-400);">Audience: <?= e(strtoupper($n['audience'])) ?> • <?= format_datetime($n['published_at']) ?></small>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Recent System Activity Logs</h2>
            <a href="<?= route_url('admin/activity-logs') ?>" class="btn btn-sm btn-outline">Full Audit Log</a>
        </div>
        <div class="card-body">
            <?php if (empty($recentLogs)): ?>
                <div class="empty-state">No recent user activity recorded.</div>
            <?php else: ?>
                <?php foreach ($recentLogs as $log): ?>
                    <div style="padding:8px 0; border-bottom:1px solid var(--slate-100); font-size:13px;">
                        <div style="display:flex; justify-content:space-between;">
                            <strong><?= e($log['action']) ?></strong>
                            <span style="color:var(--slate-400); font-size:12px;"><?= format_datetime($log['created_at']) ?></span>
                        </div>
                        <div style="color:var(--slate-600);"><?= e($log['description']) ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
