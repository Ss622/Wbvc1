<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Enrollment Management</h1>
        <p class="page-subtitle">Associate students with courses and enforce unique student-course enrollment constraints.</p>
    </div>
</div>

<div class="grid-sidebar-form">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Enroll Student in Course</h2>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url('admin/enrollments/store') ?>">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label class="form-label">Select Student <span class="req">*</span></label>
                    <select name="student_id" class="form-control" required>
                        <option value="">-- Choose Active Student --</option>
                        <?php foreach ($students as $s): ?>
                            <option value="<?= (int) $s['user_id'] ?>">
                                <?= e($s['name']) ?> (<?= e($s['enrollment_no'] ?: $s['email']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Select Course <span class="req">*</span></label>
                    <select name="course_id" class="form-control" required>
                        <option value="">-- Choose Course --</option>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int) $c['course_id'] ?>">
                                <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;">Enroll Student</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Active Course Enrollments (<?= count($enrollments) ?>)</h2>
        </div>

        <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
            <input type="hidden" name="r" value="admin/enrollments">
            <input type="search" name="q" placeholder="Search student name, enrolment no., or course..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1;">
            <select name="course_id">
                <option value="">All Courses</option>
                <?php foreach ($courses as $c): ?>
                    <option value="<?= (int) $c['course_id'] ?>" <?= ((int) ($filters['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                        <?= e($c['course_code']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-sm btn-primary">Filter</button>
            <a href="<?= route_url('admin/enrollments') ?>" class="btn btn-sm btn-outline">Reset</a>
        </form>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Course</th>
                        <th>Enrolment No.</th>
                        <th>Student Name & Email</th>
                        <th>Assigned Teacher</th>
                        <th>Enrolled Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($enrollments)): ?>
                        <tr><td colspan="7" class="empty-state">No enrollment records found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($enrollments as $e): ?>
                        <tr>
                            <td>
                                <strong><?= e($e['course_code']) ?></strong><br>
                                <small style="color:var(--slate-500);"><?= e($e['course_name']) ?></small>
                            </td>
                            <td><strong><?= e($e['enrollment_no'] ?: '—') ?></strong></td>
                            <td>
                                <?= e($e['student_name']) ?><br>
                                <small style="color:var(--slate-500);"><?= e($e['student_email']) ?></small>
                            </td>
                            <td><?= e($e['teacher_name'] ?: 'Unassigned') ?></td>
                            <td><?= format_date($e['enrolled_at']) ?></td>
                            <td><span class="badge <?= status_badge_class($e['enrollment_status']) ?>"><?= e($e['enrollment_status']) ?></span></td>
                            <td>
                                <form method="post" action="<?= route_url('admin/enrollments/remove') ?>" data-confirm="Remove <?= e($e['student_name']) ?> from <?= e($e['course_code']) ?>?" style="margin:0;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="enrollment_id" value="<?= (int) $e['enrollment_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger">Unenroll</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
