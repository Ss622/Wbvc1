<?php
declare(strict_types=1);
$isEditing = !empty($editCourse);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Course Management</h1>
        <p class="page-subtitle">Add, edit, publish, archive, and assign faculty teachers to academic courses.</p>
    </div>
</div>

<div class="grid-sidebar-form">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?= $isEditing ? 'Edit Course (' . e($editCourse['course_code']) . ')' : 'Create New Course' ?></h2>
            <?php if ($isEditing): ?>
                <a href="<?= route_url('admin/courses') ?>" class="btn btn-sm btn-outline">Cancel</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url($isEditing ? 'admin/courses/update' : 'admin/courses/store') ?>">
                <?= csrf_field() ?>
                <?php if ($isEditing): ?>
                    <input type="hidden" name="course_id" value="<?= (int) $editCourse['course_id'] ?>">
                <?php endif; ?>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Course Code <span class="req">*</span></label>
                        <input type="text" name="course_code" class="form-control"
                               placeholder="e.g. BCS-051"
                               value="<?= e($editCourse['course_code'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Credits <span class="req">*</span></label>
                        <input type="number" name="credits" class="form-control" min="1" max="12"
                               value="<?= e($editCourse['credits'] ?? 4) ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Course Title <span class="req">*</span></label>
                    <input type="text" name="course_name" class="form-control"
                           placeholder="e.g. Introduction to Software Engineering"
                           value="<?= e($editCourse['course_name'] ?? '') ?>" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Semester</label>
                        <input type="text" name="semester" class="form-control"
                               placeholder="e.g. Semester V"
                               value="<?= e($editCourse['semester'] ?? 'Semester VI') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status <span class="req">*</span></label>
                        <select name="status" class="form-control">
                            <option value="published" <?= (($editCourse['status'] ?? 'published') === 'published') ? 'selected' : '' ?>>Published</option>
                            <option value="draft" <?= (($editCourse['status'] ?? '') === 'draft') ? 'selected' : '' ?>>Draft</option>
                            <option value="archived" <?= (($editCourse['status'] ?? '') === 'archived') ? 'selected' : '' ?>>Archived</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Assigned Faculty Teacher</label>
                    <select name="teacher_id" class="form-control">
                        <option value="">-- Select Teacher --</option>
                        <?php foreach ($teachers as $t): ?>
                            <option value="<?= (int) $t['user_id'] ?>"
                                <?= ((int) ($editCourse['teacher_id'] ?? 0) === (int) $t['user_id']) ? 'selected' : '' ?>>
                                <?= e($t['name']) ?> (<?= e($t['qualification'] ?: $t['email']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Course Description & Syllabus Overview <span class="req">*</span></label>
                    <textarea name="description" class="form-control" required><?= e($editCourse['description'] ?? '') ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;">
                    <?= $isEditing ? 'Update Course' : 'Save & Publish Course' ?>
                </button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Academic Course Catalogue (<?= count($courses) ?>)</h2>
        </div>

        <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
            <input type="hidden" name="r" value="admin/courses">
            <input type="search" name="q" placeholder="Search code, title, teacher..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1;">
            <select name="status">
                <option value="">All Statuses</option>
                <option value="published" <?= (($filters['status'] ?? '') === 'published') ? 'selected' : '' ?>>Published</option>
                <option value="draft" <?= (($filters['status'] ?? '') === 'draft') ? 'selected' : '' ?>>Draft</option>
                <option value="archived" <?= (($filters['status'] ?? '') === 'archived') ? 'selected' : '' ?>>Archived</option>
            </select>
            <button type="submit" class="btn btn-sm btn-primary">Filter</button>
            <a href="<?= route_url('admin/courses') ?>" class="btn btn-sm btn-outline">Reset</a>
        </form>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Course Title & Description</th>
                        <th>Teacher</th>
                        <th>Students</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($courses)): ?>
                        <tr><td colspan="6" class="empty-state">No courses found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($courses as $c): ?>
                        <tr>
                            <td>
                                <strong><?= e($c['course_code']) ?></strong><br>
                                <small style="color:var(--slate-500);"><?= e($c['semester']) ?> • <?= (int) $c['credits'] ?> Cr</small>
                            </td>
                            <td>
                                <strong><?= e($c['course_name']) ?></strong>
                                <div style="font-size:12.5px; color:var(--slate-500); max-width:380px;"><?= e($c['description']) ?></div>
                            </td>
                            <td><?= e($c['teacher_name'] ?: 'Unassigned') ?></td>
                            <td>
                                <a href="<?= route_url('admin/enrollments', ['course_id' => $c['course_id']]) ?>">
                                    <?= (int) $c['enrolled_count'] ?> Enrolled
                                </a>
                            </td>
                            <td><span class="badge <?= status_badge_class($c['status']) ?>"><?= e($c['status']) ?></span></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?= route_url('admin/courses', ['edit' => $c['course_id']]) ?>" class="btn btn-sm btn-outline">Edit</a>
                                    <form method="post" action="<?= route_url('admin/courses/delete') ?>" data-confirm="Delete course <?= e($c['course_code']) ?>?" style="margin:0;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="course_id" value="<?= (int) $c['course_id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
