<?php
declare(strict_types=1);
$isEditing = !empty($editUser);
$defaultRoleId = 3;
if (!empty($lockedRole)) {
    $defaultRoleId = ($lockedRole === 'TEACHER') ? 2 : 3;
}
?>
<div class="page-header">
    <div>
        <h1 class="page-title"><?= e($pageTitle) ?></h1>
        <p class="page-subtitle">Create, edit, search, filter, and activate or deactivate Administrator, Teacher, and Student accounts.</p>
    </div>
</div>

<div class="grid-sidebar-form">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?= $isEditing ? 'Edit User Account' : 'Create New User Account' ?></h2>
            <?php if ($isEditing): ?>
                <a href="<?= route_url('admin/users') ?>" class="btn btn-sm btn-outline">Cancel</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url($isEditing ? 'admin/users/update' : 'admin/users/store') ?>">
                <?= csrf_field() ?>
                <?php if ($isEditing): ?>
                    <input type="hidden" name="user_id" value="<?= (int) $editUser['user_id'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label class="form-label">Account Role <span class="req">*</span></label>
                    <select name="role_id" class="form-control" required>
                        <?php foreach ($roles as $r):
                            $selected = $isEditing ? ((int) $editUser['role_id'] === (int) $r['role_id']) : ((int) $r['role_id'] === $defaultRoleId);
                        ?>
                            <option value="<?= (int) $r['role_id'] ?>" <?= $selected ? 'selected' : '' ?>>
                                <?= e($r['role_name']) ?> (<?= e($r['role_slug']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Enrolment No. / Faculty Staff ID</label>
                    <input type="text" name="enrollment_no" class="form-control"
                           placeholder="e.g. 2200080271 or FAC-0500-104"
                           value="<?= e($editUser['enrollment_no'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Full Name <span class="req">*</span></label>
                    <input type="text" name="name" class="form-control"
                           placeholder="Enter full name"
                           value="<?= e($editUser['name'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Email Address <span class="req">*</span></label>
                    <input type="email" name="email" class="form-control"
                           placeholder="user@ignou-vc.edu.in"
                           value="<?= e($editUser['email'] ?? '') ?>" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Phone Number</label>
                        <input type="text" name="phone" class="form-control"
                               value="<?= e($editUser['phone'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status <span class="req">*</span></label>
                        <select name="status" class="form-control">
                            <option value="active" <?= (($editUser['status'] ?? 'active') === 'active') ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= (($editUser['status'] ?? '') === 'inactive') ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Qualification / Semester</label>
                    <input type="text" name="qualification" class="form-control"
                           placeholder="e.g. BCA Semester VI or M.Tech (CSE)"
                           value="<?= e($editUser['qualification'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Department / Study Centre</label>
                    <input type="text" name="department" class="form-control"
                           value="<?= e($editUser['department'] ?? 'BCA Programme (Study Centre 0500)') ?>">
                </div>

                <?php if ($isEditing): ?>
                    <div class="form-group">
                        <label class="form-label">Reset Password (Optional)</label>
                        <input type="password" name="new_password" class="form-control"
                               placeholder="Leave blank to keep existing password" minlength="8">
                    </div>
                <?php else: ?>
                    <div class="form-group">
                        <label class="form-label">Initial Password (min 8 chars) <span class="req">*</span></label>
                        <input type="password" name="password" class="form-control"
                               placeholder="Minimum 8 characters" minlength="8" required>
                    </div>
                <?php endif; ?>

                <button type="submit" class="btn btn-primary" style="width:100%;">
                    <?= $isEditing ? 'Update User Account' : 'Create User Account' ?>
                </button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Registered Users (<?= count($users) ?>)</h2>
        </div>

        <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
            <input type="hidden" name="r" value="admin/users">
            <input type="search" name="q" placeholder="Search name, email, enrolment no..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1; min-width:180px;">
            <select name="role">
                <option value="">All Roles</option>
                <option value="ADMIN" <?= (($filters['role_slug'] ?? '') === 'ADMIN') ? 'selected' : '' ?>>Administrators</option>
                <option value="TEACHER" <?= (($filters['role_slug'] ?? '') === 'TEACHER') ? 'selected' : '' ?>>Teachers</option>
                <option value="STUDENT" <?= (($filters['role_slug'] ?? '') === 'STUDENT') ? 'selected' : '' ?>>Students</option>
            </select>
            <select name="status">
                <option value="">All Statuses</option>
                <option value="active" <?= (($filters['status'] ?? '') === 'active') ? 'selected' : '' ?>>Active</option>
                <option value="inactive" <?= (($filters['status'] ?? '') === 'inactive') ? 'selected' : '' ?>>Inactive</option>
            </select>
            <button type="submit" class="btn btn-sm btn-primary">Filter</button>
            <a href="<?= route_url('admin/users') ?>" class="btn btn-sm btn-outline">Reset</a>
        </form>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID / Enrol No.</th>
                        <th>Full Name & Email</th>
                        <th>Role</th>
                        <th>Department / Qualification</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                        <tr><td colspan="6" class="empty-state">No user records matched your filter criteria.</td></tr>
                    <?php else: ?>
                        <?php foreach ($users as $u): ?>
                        <tr>
                            <td>
                                <strong><?= e($u['enrollment_no'] ?: ('#' . $u['user_id'])) ?></strong>
                            </td>
                            <td>
                                <strong><?= e($u['name']) ?></strong><br>
                                <span style="font-size:12.5px; color:var(--slate-500);"><?= e($u['email']) ?></span>
                            </td>
                            <td><span class="badge badge-info"><?= e($u['role_name']) ?></span></td>
                            <td>
                                <?= e($u['qualification'] ?: '—') ?><br>
                                <small style="color:var(--slate-500);"><?= e($u['department'] ?? '') ?></small>
                            </td>
                            <td><span class="badge <?= status_badge_class($u['status']) ?>"><?= e($u['status']) ?></span></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?= route_url('admin/users', ['edit' => $u['user_id']]) ?>" class="btn btn-sm btn-outline">Edit</a>
                                    <?php if ((int) $u['user_id'] !== (int) \App\Core\Auth::id()): ?>
                                        <form method="post" action="<?= route_url('admin/users/toggle-status') ?>" style="margin:0;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="user_id" value="<?= (int) $u['user_id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-outline">
                                                <?= ($u['status'] === 'active') ? 'Deactivate' : 'Activate' ?>
                                            </button>
                                        </form>
                                        <form method="post" action="<?= route_url('admin/users/delete') ?>" data-confirm="Delete user <?= e($u['name']) ?>?" style="margin:0;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="user_id" value="<?= (int) $u['user_id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
