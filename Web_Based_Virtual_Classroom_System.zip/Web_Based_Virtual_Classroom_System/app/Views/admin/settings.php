<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Institutional & Grading Settings</h1>
        <p class="page-subtitle">Configure global institution parameters, minimum attendance thresholds, and documented IGNOU grading criteria.</p>
    </div>
</div>

<div class="card" style="max-width:760px;">
    <div class="card-header">
        <h2 class="card-title">Portal Configuration</h2>
    </div>
    <div class="card-body">
        <form method="post" action="<?= route_url('admin/settings/update') ?>">
            <?= csrf_field() ?>

            <div class="form-group">
                <label class="form-label">Institution / Study Centre Name</label>
                <input type="text" name="institution_name" class="form-control"
                       value="<?= e($settings['institution_name'] ?? '') ?>" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Active Academic Session</label>
                    <input type="text" name="academic_session" class="form-control"
                           value="<?= e($settings['academic_session'] ?? '2026-2027') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Project Course Code</label>
                    <input type="text" name="project_code" class="form-control"
                           value="<?= e($settings['project_code'] ?? 'BCSP-064') ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Minimum Recommended Attendance (%)</label>
                    <input type="number" name="min_attendance_percent" class="form-control" min="0" max="100"
                           value="<?= e($settings['min_attendance_percent'] ?? '75') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Minimum Passing Percentage (%)</label>
                    <input type="number" name="pass_percentage" class="form-control" min="0" max="100"
                           value="<?= e($settings['pass_percentage'] ?? '40') ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Documented Grading Scale Reference</label>
                <input type="text" name="grading_scale_info" class="form-control"
                       value="<?= e($settings['grading_scale_info'] ?? '') ?>" required>
                <div class="form-hint">Used across student transcripts and course performance reports.</div>
            </div>

            <button type="submit" class="btn btn-primary">Save Institutional Settings</button>
        </form>
    </div>
</div>
