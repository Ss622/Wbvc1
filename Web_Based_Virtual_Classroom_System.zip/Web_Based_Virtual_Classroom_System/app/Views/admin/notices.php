<?php
declare(strict_types=1);
$isEditing = !empty($editNotice);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Notices & Announcements</h1>
        <p class="page-subtitle">Publish institution-wide, role-specific, or course-specific academic notices.</p>
    </div>
</div>

<div class="grid-sidebar-form">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?= $isEditing ? 'Edit Notice' : 'Publish New Notice' ?></h2>
            <?php if ($isEditing): ?>
                <a href="<?= route_url('admin/notices') ?>" class="btn btn-sm btn-outline">Cancel</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url($isEditing ? 'admin/notices/update' : 'admin/notices/store') ?>">
                <?= csrf_field() ?>
                <?php if ($isEditing): ?>
                    <input type="hidden" name="notice_id" value="<?= (int) $editNotice['notice_id'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label class="form-label">Notice Title <span class="req">*</span></label>
                    <input type="text" name="title" class="form-control"
                           value="<?= e($editNotice['title'] ?? '') ?>" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Audience <span class="req">*</span></label>
                        <select name="audience" id="noticeAudienceSelect" class="form-control">
                            <option value="all" <?= (($editNotice['audience'] ?? 'all') === 'all') ? 'selected' : '' ?>>All Users (Institution-Wide)</option>
                            <option value="students" <?= (($editNotice['audience'] ?? '') === 'students') ? 'selected' : '' ?>>Students Only</option>
                            <option value="teachers" <?= (($editNotice['audience'] ?? '') === 'teachers') ? 'selected' : '' ?>>Teachers Only</option>
                            <option value="course" <?= (($editNotice['audience'] ?? '') === 'course') ? 'selected' : '' ?>>Specific Course</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Priority <span class="req">*</span></label>
                        <select name="priority" class="form-control">
                            <option value="normal" <?= (($editNotice['priority'] ?? 'normal') === 'normal') ? 'selected' : '' ?>>Normal</option>
                            <option value="important" <?= (($editNotice['priority'] ?? '') === 'important') ? 'selected' : '' ?>>Important</option>
                            <option value="urgent" <?= (($editNotice['priority'] ?? '') === 'urgent') ? 'selected' : '' ?>>Urgent</option>
                        </select>
                    </div>
                </div>

                <div class="form-group" id="noticeCourseGroup" style="display:none;">
                    <label class="form-label">Related Course</label>
                    <select name="course_id" class="form-control">
                        <option value="">-- Select Course --</option>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int) $c['course_id'] ?>" <?= ((int) ($editNotice['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                                <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Publication Status</label>
                    <select name="status" class="form-control">
                        <option value="published" <?= (($editNotice['status'] ?? 'published') === 'published') ? 'selected' : '' ?>>Published</option>
                        <option value="draft" <?= (($editNotice['status'] ?? '') === 'draft') ? 'selected' : '' ?>>Draft</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Announcement Description <span class="req">*</span></label>
                    <textarea name="description" class="form-control" rows="4" required><?= e($editNotice['description'] ?? '') ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;">
                    <?= $isEditing ? 'Update Notice' : 'Publish Notice' ?>
                </button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Published & Draft Notices (<?= count($notices) ?>)</h2>
        </div>

        <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
            <input type="hidden" name="r" value="admin/notices">
            <input type="search" name="q" placeholder="Search notice title or content..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1;">
            <select name="audience">
                <option value="">All Audiences</option>
                <option value="all" <?= (($filters['audience'] ?? '') === 'all') ? 'selected' : '' ?>>Institution-Wide</option>
                <option value="students" <?= (($filters['audience'] ?? '') === 'students') ? 'selected' : '' ?>>Students</option>
                <option value="teachers" <?= (($filters['audience'] ?? '') === 'teachers') ? 'selected' : '' ?>>Teachers</option>
                <option value="course" <?= (($filters['audience'] ?? '') === 'course') ? 'selected' : '' ?>>Course-Specific</option>
            </select>
            <select name="priority">
                <option value="">All Priorities</option>
                <option value="urgent" <?= (($filters['priority'] ?? '') === 'urgent') ? 'selected' : '' ?>>Urgent</option>
                <option value="important" <?= (($filters['priority'] ?? '') === 'important') ? 'selected' : '' ?>>Important</option>
                <option value="normal" <?= (($filters['priority'] ?? '') === 'normal') ? 'selected' : '' ?>>Normal</option>
            </select>
            <button type="submit" class="btn btn-sm btn-primary">Filter</button>
        </form>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Title & Message</th>
                        <th>Audience</th>
                        <th>Priority</th>
                        <th>Author & Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($notices)): ?>
                        <tr><td colspan="6" class="empty-state">No notices found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($notices as $n): ?>
                        <tr>
                            <td>
                                <strong><?= e($n['title']) ?></strong>
                                <div style="font-size:13px; color:var(--slate-600); margin-top:3px;"><?= e($n['description']) ?></div>
                            </td>
                            <td>
                                <span class="badge badge-info"><?= e($n['audience']) ?></span>
                                <?php if (!empty($n['course_code'])): ?>
                                    <br><small><?= e($n['course_code']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge <?= status_badge_class($n['priority']) ?>"><?= e($n['priority']) ?></span></td>
                            <td>
                                <?= e($n['author_name']) ?><br>
                                <small style="color:var(--slate-500);"><?= format_datetime($n['published_at']) ?></small>
                            </td>
                            <td><span class="badge <?= status_badge_class($n['status']) ?>"><?= e($n['status']) ?></span></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?= route_url('admin/notices', ['edit' => $n['notice_id']]) ?>" class="btn btn-sm btn-outline">Edit</a>
                                    <form method="post" action="<?= route_url('admin/notices/delete') ?>" data-confirm="Delete this notice?" style="margin:0;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="notice_id" value="<?= (int) $n['notice_id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
