<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">System Audit & Activity Logs</h1>
        <p class="page-subtitle">Chronological audit trail of logins, course changes, uploads, submissions, and evaluations.</p>
    </div>
</div>

<div class="card">
    <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
        <input type="hidden" name="r" value="admin/activity-logs">
        <input type="search" name="q" placeholder="Filter by action, description, or user..." value="<?= e($search) ?>" style="flex:1;">
        <button type="submit" class="btn btn-sm btn-primary">Search Logs</button>
        <a href="<?= route_url('admin/activity-logs') ?>" class="btn btn-sm btn-outline">Reset</a>
    </form>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Log ID</th>
                    <th>Timestamp</th>
                    <th>User & Role</th>
                    <th>Action Code</th>
                    <th>Description</th>
                    <th>IP Address</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr><td colspan="6" class="empty-state">No activity logs matched your query.</td></tr>
                <?php else: ?>
                    <?php foreach ($logs as $l): ?>
                    <tr>
                        <td>#<?= (int) $l['log_id'] ?></td>
                        <td><?= format_datetime($l['created_at']) ?></td>
                        <td>
                            <strong><?= e($l['user_name'] ?: 'System') ?></strong>
                            <?php if (!empty($l['role_name'])): ?>
                                <br><small style="color:var(--slate-500);"><?= e($l['role_name']) ?></small>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge badge-info"><?= e($l['action']) ?></span></td>
                        <td><?= e($l['description']) ?></td>
                        <td><code><?= e($l['ip_address'] ?: '127.0.0.1') ?></code></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
