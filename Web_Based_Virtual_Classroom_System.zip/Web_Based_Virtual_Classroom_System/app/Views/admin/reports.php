<?php
declare(strict_types=1);
$reportTypes = [
    'performance' => 'Academic Performance Report',
    'students'    => 'Student Directory Report',
    'teachers'    => 'Teacher Directory Report',
    'courses'     => 'Course Catalogue Report',
    'enrollments' => 'Enrollment Registry Report',
    'attendance'  => 'Attendance Summary Report',
    'assignments' => 'Assignment Status Report',
    'quizzes'     => 'Quiz Score Report',
];
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Institutional Academic Reports</h1>
        <p class="page-subtitle">Generate real-time database reports with one-click CSV export and printer-friendly layouts.</p>
    </div>
    <div class="btn-group no-print">
        <a href="<?= route_url('admin/reports', ['type' => $reportType, 'course_id' => $courseId, 'export' => 'csv']) ?>" class="btn btn-teal">⬇ Download CSV</a>
        <button type="button" onclick="window.print()" class="btn btn-outline">🖨️ Print Report</button>
    </div>
</div>

<div class="card">
    <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar no-print">
        <input type="hidden" name="r" value="admin/reports">
        <label class="form-label" style="margin:0;">Report Type:</label>
        <select name="type">
            <?php foreach ($reportTypes as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= ($reportType === $key) ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
        <label class="form-label" style="margin:0;">Course Filter:</label>
        <select name="course_id">
            <option value="0">All Courses</option>
            <?php foreach ($courses as $c): ?>
                <option value="<?= (int) $c['course_id'] ?>" <?= ((int) $courseId === (int) $c['course_id']) ? 'selected' : '' ?>>
                    <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-sm btn-primary">Generate Report</button>
    </form>

    <div class="card-header">
        <h2 class="card-title"><?= e($reportTitle) ?> (<?= count($rows) ?> Records)</h2>
        <span style="font-size:12px; color:var(--slate-500);">Generated: <?= date('d M Y, h:i A') ?></span>
    </div>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <?php foreach ($headers as $h): ?>
                        <th><?= e($h) ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="<?= count($headers) ?>" class="empty-state">No database records available for this report filter.</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <?php foreach ($row as $cell): ?>
                                <td><?= e($cell) ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
