<?php
declare(strict_types=1);
use App\Core\Auth;
$user = Auth::user();
$roleSlug = $user['role_slug'] ?? 'STUDENT';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? 'Virtual Classroom') ?> — IGNOU BCSP-064</title>
    <link rel="icon" type="image/svg+xml" href="<?= base_url('assets/images/logo.svg') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>
<div class="app-shell">
    <?php
    if ($roleSlug === 'ADMIN') {
        require dirname(__DIR__) . '/partials/sidebar_admin.php';
    } elseif ($roleSlug === 'TEACHER') {
        require dirname(__DIR__) . '/partials/sidebar_teacher.php';
    } else {
        require dirname(__DIR__) . '/partials/sidebar_student.php';
    }
    ?>

    <div class="app-main">
        <?php require dirname(__DIR__) . '/partials/topbar.php'; ?>

        <main class="app-content">
            <?php require dirname(__DIR__) . '/partials/flash.php'; ?>
            <?= $content ?>
        </main>
    </div>
</div>
<script src="<?= base_url('assets/js/app.js') ?>"></script>
</body>
</html>
