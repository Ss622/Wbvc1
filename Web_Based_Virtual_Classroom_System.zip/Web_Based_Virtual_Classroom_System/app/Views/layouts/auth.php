<?php
declare(strict_types=1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? 'Sign In — Web-Based Virtual Classroom System') ?></title>
    <link rel="icon" type="image/svg+xml" href="<?= base_url('assets/images/logo.svg') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>
<div class="auth-wrapper">
    <?= $content ?>
</div>
<script src="<?= base_url('assets/js/app.js') ?>"></script>
</body>
</html>
