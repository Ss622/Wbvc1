<?php
declare(strict_types=1);
?>
<aside class="app-sidebar" id="appSidebar">
    <div class="sidebar-brand">
        <img src="<?= base_url('assets/images/logo.svg') ?>" alt="Logo">
        <div class="sidebar-brand-text">
            <span class="sidebar-brand-title">Virtual Classroom</span>
            <span class="sidebar-brand-sub">IGNOU BCA • BCSP-064</span>
        </div>
    </div>

    <div class="sidebar-role-pill">
        <span>Teacher Panel</span>
        <span>Faculty</span>
    </div>

    <ul class="sidebar-nav">
        <li><a href="<?= route_url('teacher/dashboard') ?>" class="<?= is_active_route('teacher/dashboard') ?>"><span class="sidebar-nav-icon">📊</span> Dashboard</a></li>
        <li><a href="<?= route_url('teacher/courses') ?>" class="<?= is_active_route('teacher/courses') ?>"><span class="sidebar-nav-icon">📚</span> My Courses</a></li>
        <li><a href="<?= route_url('teacher/materials') ?>" class="<?= is_active_route('teacher/materials') ?>"><span class="sidebar-nav-icon">📂</span> Course Materials</a></li>
        <li><a href="<?= route_url('teacher/assignments') ?>" class="<?= is_active_route('teacher/assignments') ?>"><span class="sidebar-nav-icon">📝</span> Assignments</a></li>
        <li><a href="<?= route_url('teacher/submissions') ?>" class="<?= is_active_route('teacher/submissions') ?>"><span class="sidebar-nav-icon">✅</span> Student Submissions</a></li>
        <li><a href="<?= route_url('teacher/quizzes') ?>" class="<?= is_active_route('teacher/quizzes') ?>"><span class="sidebar-nav-icon">⏱️</span> Quiz Management</a></li>
        <li><a href="<?= route_url('teacher/questions') ?>" class="<?= is_active_route('teacher/questions') ?>"><span class="sidebar-nav-icon">❓</span> Question Bank</a></li>
        <li><a href="<?= route_url('teacher/attendance') ?>" class="<?= is_active_route('teacher/attendance') ?>"><span class="sidebar-nav-icon">📅</span> Attendance</a></li>
        <li><a href="<?= route_url('teacher/results') ?>" class="<?= is_active_route('teacher/results') ?>"><span class="sidebar-nav-icon">🏆</span> Student Results</a></li>
        <li><a href="<?= route_url('teacher/notices') ?>" class="<?= is_active_route('teacher/notices') ?>"><span class="sidebar-nav-icon">📢</span> Notices</a></li>
        <li><a href="<?= route_url('teacher/reports') ?>" class="<?= is_active_route('teacher/reports') ?>"><span class="sidebar-nav-icon">📈</span> Reports</a></li>
        <li><a href="<?= route_url('profile') ?>" class="<?= is_active_route('profile') ?>"><span class="sidebar-nav-icon">👤</span> My Profile</a></li>
        <li><a href="<?= route_url('logout') ?>"><span class="sidebar-nav-icon">🚪</span> Logout</a></li>
    </ul>

    <div class="sidebar-footer">
        Sahil Alam (2200080265)<br>BCSP-064 Academic Portal
    </div>
</aside>
