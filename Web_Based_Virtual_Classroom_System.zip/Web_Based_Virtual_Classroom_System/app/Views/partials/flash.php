<?php
declare(strict_types=1);
use App\Core\Flash;
$messages = Flash::getAll();
foreach ($messages as $msg):
    $type = in_array($msg['type'], ['success', 'warning', 'danger', 'info'], true) ? $msg['type'] : 'info';
?>
<div class="alert alert-<?= e($type) ?>" role="alert">
    <span><?= e($msg['message']) ?></span>
</div>
<?php endforeach; ?>
