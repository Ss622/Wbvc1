<?php
declare(strict_types=1);
?>
<aside class="app-sidebar" id="appSidebar">
    <div class="sidebar-brand">
        <img src="<?= base_url('assets/images/logo.svg') ?>" alt="Logo">
        <div class="sidebar-brand-text">
            <span class="sidebar-brand-title">Virtual Classroom</span>
            <span class="sidebar-brand-sub">IGNOU BCA • BCSP-064</span>
        </div>
    </div>

    <div class="sidebar-role-pill">
        <span>Administrator Panel</span>
        <span>RC 0500</span>
    </div>

    <ul class="sidebar-nav">
        <li><a href="<?= route_url('admin/dashboard') ?>" class="<?= is_active_route('admin/dashboard') ?>"><span class="sidebar-nav-icon">📊</span> Dashboard</a></li>
        <li><a href="<?= route_url('admin/users') ?>" class="<?= is_active_route('admin/users') ?>"><span class="sidebar-nav-icon">👥</span> User Management</a></li>
        <li><a href="<?= route_url('admin/students') ?>" class="<?= is_active_route('admin/students') ?>"><span class="sidebar-nav-icon">🎓</span> Student Management</a></li>
        <li><a href="<?= route_url('admin/teachers') ?>" class="<?= is_active_route('admin/teachers') ?>"><span class="sidebar-nav-icon">🧑‍🏫</span> Teacher Management</a></li>
        <li><a href="<?= route_url('admin/courses') ?>" class="<?= is_active_route('admin/courses') ?>"><span class="sidebar-nav-icon">📚</span> Course Management</a></li>
        <li><a href="<?= route_url('admin/enrollments') ?>" class="<?= is_active_route('admin/enrollments') ?>"><span class="sidebar-nav-icon">🔗</span> Enrollment Management</a></li>
        <li><a href="<?= route_url('admin/notices') ?>" class="<?= is_active_route('admin/notices') ?>"><span class="sidebar-nav-icon">📢</span> Notices</a></li>
        <li><a href="<?= route_url('admin/reports') ?>" class="<?= is_active_route('admin/reports') ?>"><span class="sidebar-nav-icon">📈</span> Reports & CSV</a></li>
        <li><a href="<?= route_url('admin/activity-logs') ?>" class="<?= is_active_route('admin/activity-logs') ?>"><span class="sidebar-nav-icon">🛡️</span> Activity Logs</a></li>
        <li><a href="<?= route_url('profile') ?>" class="<?= is_active_route('profile') ?>"><span class="sidebar-nav-icon">👤</span> Profile</a></li>
        <li><a href="<?= route_url('admin/settings') ?>" class="<?= is_active_route('admin/settings') ?>"><span class="sidebar-nav-icon">⚙️</span> Settings</a></li>
        <li><a href="<?= route_url('logout') ?>"><span class="sidebar-nav-icon">🚪</span> Logout</a></li>
    </ul>

    <div class="sidebar-footer">
        Sahil Alam (2200080265)<br>BCSP-064 Academic Portal
    </div>
</aside>
