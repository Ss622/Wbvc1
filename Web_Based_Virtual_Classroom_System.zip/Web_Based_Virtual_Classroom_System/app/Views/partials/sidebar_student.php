<?php
declare(strict_types=1);
?>
<aside class="app-sidebar" id="appSidebar">
    <div class="sidebar-brand">
        <img src="<?= base_url('assets/images/logo.svg') ?>" alt="Logo">
        <div class="sidebar-brand-text">
            <span class="sidebar-brand-title">Virtual Classroom</span>
            <span class="sidebar-brand-sub">IGNOU BCA • BCSP-064</span>
        </div>
    </div>

    <div class="sidebar-role-pill">
        <span>Student Panel</span>
        <span>Learner</span>
    </div>

    <ul class="sidebar-nav">
        <li><a href="<?= route_url('student/dashboard') ?>" class="<?= is_active_route('student/dashboard') ?>"><span class="sidebar-nav-icon">📊</span> Dashboard</a></li>
        <li><a href="<?= route_url('student/courses') ?>" class="<?= is_active_route('student/courses') ?>"><span class="sidebar-nav-icon">📚</span> My Courses</a></li>
        <li><a href="<?= route_url('student/materials') ?>" class="<?= is_active_route('student/materials') ?>"><span class="sidebar-nav-icon">📂</span> Learning Materials</a></li>
        <li><a href="<?= route_url('student/assignments') ?>" class="<?= is_active_route('student/assignments') ?>"><span class="sidebar-nav-icon">📝</span> Assignments</a></li>
        <li><a href="<?= route_url('student/submissions') ?>" class="<?= is_active_route('student/submissions') ?>"><span class="sidebar-nav-icon">📤</span> My Submissions</a></li>
        <li><a href="<?= route_url('student/quizzes') ?>" class="<?= is_active_route('student/quizzes') ?>"><span class="sidebar-nav-icon">⏱️</span> Online Quizzes</a></li>
        <li><a href="<?= route_url('student/quiz-results') ?>" class="<?= is_active_route('student/quiz-results') ?>"><span class="sidebar-nav-icon">🎯</span> Quiz Results</a></li>
        <li><a href="<?= route_url('student/attendance') ?>" class="<?= is_active_route('student/attendance') ?>"><span class="sidebar-nav-icon">📅</span> Attendance</a></li>
        <li><a href="<?= route_url('student/results') ?>" class="<?= is_active_route('student/results') ?>"><span class="sidebar-nav-icon">🏆</span> My Results</a></li>
        <li><a href="<?= route_url('student/notices') ?>" class="<?= is_active_route('student/notices') ?>"><span class="sidebar-nav-icon">📢</span> Notices</a></li>
        <li><a href="<?= route_url('profile') ?>" class="<?= is_active_route('profile') ?>"><span class="sidebar-nav-icon">👤</span> My Profile / Password</a></li>
        <li><a href="<?= route_url('logout') ?>"><span class="sidebar-nav-icon">🚪</span> Logout</a></li>
    </ul>

    <div class="sidebar-footer">
        Sahil Alam (2200080265)<br>BCSP-064 Academic Portal
    </div>
</aside>
