<?php
declare(strict_types=1);
use App\Core\Auth;
$user = Auth::user();
$initials = strtoupper(substr(trim((string) ($user['name'] ?? 'U')), 0, 1));
?>
<header class="app-topbar">
    <div class="topbar-left">
        <button type="button" class="mobile-menu-btn" id="mobileMenuBtn" aria-label="Toggle Navigation">☰</button>
        <div class="topbar-breadcrumb">
            IGNOU Virtual Classroom &rsaquo; <strong><?= e($pageTitle ?? 'Dashboard') ?></strong>
        </div>
    </div>

    <div class="topbar-right">
        <a href="<?= route_url('profile') ?>" class="user-chip" title="Manage Profile & Password">
            <div class="user-avatar"><?= e($initials) ?></div>
            <div class="user-meta">
                <span class="user-meta-name"><?= e($user['name']) ?></span>
                <span class="user-meta-role"><?= e($user['role_name']) ?><?= !empty($user['enrollment_no']) ? ' • ' . e($user['enrollment_no']) : '' ?></span>
            </div>
        </a>
        <form method="post" action="<?= route_url('logout') ?>" style="margin:0;">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-sm btn-outline">Sign Out</button>
        </form>
    </div>
</header>
