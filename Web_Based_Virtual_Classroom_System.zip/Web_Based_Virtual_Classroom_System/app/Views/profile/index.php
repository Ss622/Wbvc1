<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">My Profile & Account Security</h1>
        <p class="page-subtitle">Manage your personal contact details and update your account password.</p>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Personal & Academic Identity</h2>
            <span class="badge <?= status_badge_class($profile['status']) ?>"><?= e($profile['status']) ?></span>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url('profile/update') ?>">
                <?= csrf_field() ?>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Role</label>
                        <input type="text" class="form-control" value="<?= e($profile['role_name']) ?>" disabled>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Enrolment / Staff No.</label>
                        <input type="text" class="form-control" value="<?= e($profile['enrollment_no'] ?: 'N/A') ?>" disabled>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Email Address (Login Identifier)</label>
                    <input type="email" class="form-control" value="<?= e($profile['email']) ?>" disabled>
                </div>

                <div class="form-group">
                    <label for="prof_name" class="form-label">Full Name <span class="req">*</span></label>
                    <input type="text" id="prof_name" name="name" class="form-control" value="<?= e($profile['name']) ?>" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="prof_phone" class="form-label">Phone Number</label>
                        <input type="text" id="prof_phone" name="phone" class="form-control" value="<?= e($profile['phone'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label for="prof_qual" class="form-label">Qualification / Semester</label>
                        <input type="text" id="prof_qual" name="qualification" class="form-control" value="<?= e($profile['qualification'] ?? '') ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="prof_dept" class="form-label">Department / Study Centre</label>
                    <input type="text" id="prof_dept" name="department" class="form-control" value="<?= e($profile['department'] ?? '') ?>">
                </div>

                <button type="submit" class="btn btn-primary">Save Profile Changes</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Change Account Password</h2>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url('profile/password') ?>">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label for="current_password" class="form-label">Current Password <span class="req">*</span></label>
                    <input type="password" id="current_password" name="current_password" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="new_password" class="form-label">New Password (minimum 8 characters) <span class="req">*</span></label>
                    <input type="password" id="new_password" name="new_password" class="form-control" minlength="8" required>
                </div>

                <div class="form-group">
                    <label for="confirm_password" class="form-label">Confirm New Password <span class="req">*</span></label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" minlength="8" required>
                </div>

                <button type="submit" class="btn btn-teal">Update Password Securely</button>
            </form>
        </div>
    </div>
</div>
