<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Student Assignment Submissions & Evaluation</h1>
        <p class="page-subtitle">Inspect student work, download submitted files, award validated marks, and publish feedback.</p>
    </div>
</div>

<div class="card">
    <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
        <input type="hidden" name="r" value="teacher/submissions">
        <input type="search" name="q" placeholder="Search student name, enrolment no., or assignment..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1;">
        <select name="course_id">
            <option value="0">All Assigned Courses</option>
            <?php foreach ($courses as $c): ?>
                <option value="<?= (int) $c['course_id'] ?>" <?= ((int) ($filters['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                    <?= e($c['course_code']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <select name="status">
            <option value="">All Statuses</option>
            <option value="submitted" <?= (($filters['status'] ?? '') === 'submitted') ? 'selected' : '' ?>>Submitted (Pending)</option>
            <option value="late" <?= (($filters['status'] ?? '') === 'late') ? 'selected' : '' ?>>Late</option>
            <option value="evaluated" <?= (($filters['status'] ?? '') === 'evaluated') ? 'selected' : '' ?>>Evaluated (Unpublished)</option>
            <option value="published" <?= (($filters['status'] ?? '') === 'published') ? 'selected' : '' ?>>Published</option>
        </select>
        <button type="submit" class="btn btn-sm btn-primary">Filter</button>
        <a href="<?= route_url('teacher/submissions') ?>" class="btn btn-sm btn-outline">Reset</a>
    </form>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Student & Course</th>
                    <th>Assignment & Submission Content</th>
                    <th>Submitted At</th>
                    <th>Status</th>
                    <th style="min-width:340px;">Award Marks & Feedback</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($submissions)): ?>
                    <tr><td colspan="5" class="empty-state">No student submissions matched your filter criteria.</td></tr>
                <?php else: ?>
                    <?php foreach ($submissions as $s): ?>
                    <tr>
                        <td>
                            <strong><?= e($s['student_name']) ?></strong><br>
                            <small style="color:var(--slate-500);"><?= e($s['enrollment_no'] ?: $s['student_email']) ?></small><br>
                            <span class="badge badge-info"><?= e($s['course_code']) ?></span>
                        </td>
                        <td>
                            <strong><?= e($s['assignment_title']) ?></strong> (Max: <?= e($s['max_marks']) ?>)<br>
                            <?php if (!empty($s['text_response'])): ?>
                                <div style="margin-top:6px; padding:8px 10px; background:var(--slate-50); border:1px solid var(--slate-200); border-radius:6px; font-size:12.5px;">
                                    <?= nl2br(e($s['text_response'])) ?>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($s['file_path'])): ?>
                                <div style="margin-top:6px;">
                                    <a href="<?= route_url('download/submission', ['id' => $s['submission_id']]) ?>" class="btn btn-sm btn-outline">
                                        📥 Download <?= e($s['original_name'] ?: 'Attachment') ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= format_datetime($s['submitted_at']) ?>
                            <?php if (!empty($s['is_late'])): ?>
                                <br><span class="badge badge-danger">Late Submission</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge <?= status_badge_class($s['status']) ?>"><?= e($s['status']) ?></span></td>
                        <td>
                            <form method="post" action="<?= route_url('teacher/submissions/evaluate') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="submission_id" value="<?= (int) $s['submission_id'] ?>">
                                <div style="display:flex; gap:8px; margin-bottom:6px; align-items:center;">
                                    <input type="number" step="0.5" min="0" max="<?= e($s['max_marks']) ?>"
                                           name="marks" class="form-control" style="width:110px;"
                                           placeholder="0 - <?= e($s['max_marks']) ?>"
                                           value="<?= e($s['marks'] ?? '') ?>" required>
                                    <span style="font-size:12.5px; color:var(--slate-500);">/ <?= e($s['max_marks']) ?></span>
                                    <select name="eval_action" class="form-control" style="flex:1;">
                                        <option value="publish" <?= ($s['status'] === 'published') ? 'selected' : '' ?>>Publish Marks</option>
                                        <option value="save" <?= ($s['status'] === 'evaluated') ? 'selected' : '' ?>>Save Draft Evaluation</option>
                                    </select>
                                </div>
                                <div style="display:flex; gap:8px;">
                                    <input type="text" name="feedback" class="form-control"
                                           placeholder="Enter constructive faculty feedback..."
                                           value="<?= e($s['feedback'] ?? '') ?>">
                                    <button type="submit" class="btn btn-sm btn-primary">Save</button>
                                </div>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
