<?php
declare(strict_types=1);
$isEditing = !empty($editAssignment);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Course Assignments</h1>
        <p class="page-subtitle">Create assignments, set maximum marks and due dates, attach reference files, and monitor submissions.</p>
    </div>
</div>

<div class="grid-sidebar-form">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?= $isEditing ? 'Edit Assignment' : 'Create New Assignment' ?></h2>
            <?php if ($isEditing): ?>
                <a href="<?= route_url('teacher/assignments') ?>" class="btn btn-sm btn-outline">Cancel</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url($isEditing ? 'teacher/assignments/update' : 'teacher/assignments/store') ?>" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <?php if ($isEditing): ?>
                    <input type="hidden" name="assignment_id" value="<?= (int) $editAssignment['assignment_id'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label class="form-label">Course <span class="req">*</span></label>
                    <select name="course_id" class="form-control" required>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int) $c['course_id'] ?>"
                                <?= ((int) ($editAssignment['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                                <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Assignment Title <span class="req">*</span></label>
                    <input type="text" name="title" class="form-control"
                           placeholder="e.g. TMA-01: Prepare SRS & DFD"
                           value="<?= e($editAssignment['title'] ?? '') ?>" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Maximum Marks <span class="req">*</span></label>
                        <input type="number" step="0.5" min="1" max="1000" name="max_marks" class="form-control"
                               value="<?= e($editAssignment['max_marks'] ?? '100.00') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status <span class="req">*</span></label>
                        <select name="status" class="form-control">
                            <?php foreach (['open', 'published', 'draft', 'due', 'closed'] as $st): ?>
                                <option value="<?= $st ?>" <?= (($editAssignment['status'] ?? 'open') === $st) ? 'selected' : '' ?>>
                                    <?= strtoupper($st) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Issue Date <span class="req">*</span></label>
                        <input type="date" name="issue_date" class="form-control"
                               value="<?= e($editAssignment['issue_date'] ?? date('Y-m-d')) ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Due Date <span class="req">*</span></label>
                        <input type="date" name="due_date" class="form-control"
                               value="<?= e($editAssignment['due_date'] ?? date('Y-m-d', strtotime('+14 days'))) ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Assignment Instructions <span class="req">*</span></label>
                    <textarea name="description" class="form-control" rows="4" required><?= e($editAssignment['description'] ?? '') ?></textarea>
                </div>

                <?php if (!$isEditing): ?>
                <div class="form-group">
                    <label class="form-label">Reference Document (Optional)</label>
                    <input type="file" name="attachment" class="form-control">
                </div>
                <?php endif; ?>

                <div class="form-group">
                    <label style="display:flex; align-items:center; gap:8px; font-size:13.5px; cursor:pointer;">
                        <input type="checkbox" name="allow_late" value="1" <?= !isset($editAssignment) || !empty($editAssignment['allow_late']) ? 'checked' : '' ?>>
                        Allow late submissions (flagged as Late)
                    </label>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;">
                    <?= $isEditing ? 'Update Assignment' : 'Create Assignment' ?>
                </button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Course Assignments (<?= count($assignments) ?>)</h2>
        </div>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Course</th>
                        <th>Assignment Title & Instructions</th>
                        <th>Timeline</th>
                        <th>Max Marks</th>
                        <th>Submissions</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($assignments)): ?>
                        <tr><td colspan="7" class="empty-state">No assignments found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($assignments as $a): ?>
                        <tr>
                            <td><strong><?= e($a['course_code']) ?></strong></td>
                            <td>
                                <strong><?= e($a['title']) ?></strong>
                                <div style="font-size:12.5px; color:var(--slate-500);"><?= e($a['description']) ?></div>
                                <?php if (!empty($a['attachment_path'])): ?>
                                    <div style="margin-top:4px;">
                                        <a href="<?= route_url('download/assignment', ['id' => $a['assignment_id']]) ?>" style="font-size:12px;">📎 <?= e($a['attachment_name'] ?: 'Download Reference') ?></a>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                Issued: <?= format_date($a['issue_date']) ?><br>
                                <strong>Due: <?= format_date($a['due_date']) ?></strong>
                            </td>
                            <td><?= e($a['max_marks']) ?></td>
                            <td>
                                <a href="<?= route_url('teacher/submissions', ['assignment_id' => $a['assignment_id']]) ?>">
                                    <?= (int) $a['submission_count'] ?> / <?= (int) $a['enrolled_count'] ?> Submitted
                                </a>
                            </td>
                            <td><span class="badge <?= status_badge_class($a['status']) ?>"><?= e($a['status']) ?></span></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?= route_url('teacher/submissions', ['assignment_id' => $a['assignment_id']]) ?>" class="btn btn-sm btn-teal">Evaluate</a>
                                    <a href="<?= route_url('teacher/assignments', ['edit' => $a['assignment_id']]) ?>" class="btn btn-sm btn-outline">Edit</a>
                                    <form method="post" action="<?= route_url('teacher/assignments/delete') ?>" data-confirm="Delete assignment <?= e($a['title']) ?>?" style="margin:0;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="assignment_id" value="<?= (int) $a['assignment_id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
