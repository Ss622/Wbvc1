<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Faculty Course Performance Reports</h1>
        <p class="page-subtitle">Printer-friendly and CSV-exportable academic summary for your assigned courses.</p>
    </div>
    <div class="btn-group no-print">
        <a href="<?= route_url('teacher/reports', ['course_id' => $courseId, 'export' => 'csv']) ?>" class="btn btn-teal">⬇ Download CSV</a>
        <button type="button" onclick="window.print()" class="btn btn-outline">🖨️ Print Report</button>
    </div>
</div>

<div class="card">
    <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar no-print">
        <input type="hidden" name="r" value="teacher/reports">
        <label class="form-label" style="margin:0;">Filter by Assigned Course:</label>
        <select name="course_id">
            <option value="0">All My Courses</option>
            <?php foreach ($courses as $c): ?>
                <option value="<?= (int) $c['course_id'] ?>" <?= ((int) $courseId === (int) $c['course_id']) ? 'selected' : '' ?>>
                    <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-sm btn-primary">Apply Filter</button>
    </form>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Enrolment No.</th>
                    <th>Student Name</th>
                    <th>Assignments</th>
                    <th>Quizzes</th>
                    <th>Attendance %</th>
                    <th>Overall %</th>
                    <th>Grade</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($results)): ?>
                    <tr><td colspan="10" class="empty-state">No performance records available.</td></tr>
                <?php else: ?>
                    <?php foreach ($results as $r): ?>
                    <tr>
                        <td><strong><?= e($r['course_code']) ?></strong></td>
                        <td><?= e($r['course_name']) ?></td>
                        <td><?= e($r['enrollment_no'] ?: '—') ?></td>
                        <td><?= e($r['student_name']) ?></td>
                        <td><?= e($r['assignment_marks_obtained']) ?> / <?= e($r['assignment_marks_max']) ?></td>
                        <td><?= e($r['quiz_marks_obtained']) ?> / <?= e($r['quiz_marks_max']) ?></td>
                        <td><?= e($r['attendance_percentage']) ?>%</td>
                        <td><strong><?= e($r['overall_percentage']) ?>%</strong></td>
                        <td><span class="badge <?= status_badge_class($r['grade']) ?>"><?= e($r['grade']) ?></span></td>
                        <td><?= e($r['remarks'] ?: '—') ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
