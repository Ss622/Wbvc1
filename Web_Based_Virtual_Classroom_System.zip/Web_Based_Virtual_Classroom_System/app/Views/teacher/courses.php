<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">My Assigned Courses</h1>
        <p class="page-subtitle">Inspect course details, syllabus descriptions, and enrolled student rosters for your assigned courses.</p>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Assigned Course List (<?= count($courses) ?>)</h2>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Title & Description</th>
                    <th>Semester</th>
                    <th>Credits</th>
                    <th>Enrolled Students</th>
                    <th>Resources</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($courses)): ?>
                    <tr><td colspan="8" class="empty-state">No courses assigned to your account.</td></tr>
                <?php else: ?>
                    <?php foreach ($courses as $c): ?>
                    <tr>
                        <td><strong><?= e($c['course_code']) ?></strong></td>
                        <td>
                            <strong><?= e($c['course_name']) ?></strong>
                            <div style="font-size:12.5px; color:var(--slate-500);"><?= e($c['description']) ?></div>
                        </td>
                        <td><?= e($c['semester']) ?></td>
                        <td><?= (int) $c['credits'] ?></td>
                        <td><?= (int) $c['enrolled_count'] ?> Learners</td>
                        <td>
                            <?= (int) $c['material_count'] ?> Materials •
                            <?= (int) $c['assignment_count'] ?> Assignments •
                            <?= (int) $c['quiz_count'] ?> Quizzes
                        </td>
                        <td><span class="badge <?= status_badge_class($c['status']) ?>"><?= e($c['status']) ?></span></td>
                        <td>
                            <a href="<?= route_url('teacher/courses', ['course_id' => $c['course_id']]) ?>" class="btn btn-sm btn-primary">View Roster</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if (!empty($selectedCourse)): ?>
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Enrolled Students in <?= e($selectedCourse['course_code']) ?> — <?= e($selectedCourse['course_name']) ?> (<?= count($enrolledStudents) ?>)</h2>
        <div class="btn-group">
            <a href="<?= route_url('teacher/attendance', ['course_id' => $selectedCourse['course_id']]) ?>" class="btn btn-sm btn-teal">Mark Attendance</a>
            <a href="<?= route_url('teacher/results', ['course_id' => $selectedCourse['course_id']]) ?>" class="btn btn-sm btn-outline">Course Results</a>
        </div>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Enrolment No.</th>
                    <th>Student Name</th>
                    <th>Email Address</th>
                    <th>Enrollment Status</th>
                    <th>Enrolled Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($enrolledStudents)): ?>
                    <tr><td colspan="5" class="empty-state">No students are currently enrolled in this course.</td></tr>
                <?php else: ?>
                    <?php foreach ($enrolledStudents as $st): ?>
                    <tr>
                        <td><strong><?= e($st['enrollment_no'] ?: '—') ?></strong></td>
                        <td><?= e($st['student_name']) ?></td>
                        <td><?= e($st['student_email']) ?></td>
                        <td><span class="badge <?= status_badge_class($st['enrollment_status']) ?>"><?= e($st['enrollment_status']) ?></span></td>
                        <td><?= format_date($st['enrolled_at']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
