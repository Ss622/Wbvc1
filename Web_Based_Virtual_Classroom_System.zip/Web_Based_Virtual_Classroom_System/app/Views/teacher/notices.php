<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Course Notices & Announcements</h1>
        <p class="page-subtitle">Publish course-specific announcements to your enrolled students and view institutional notices.</p>
    </div>
</div>

<div class="grid-sidebar-form">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Post Course Announcement</h2>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url('teacher/notices/store') ?>">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label class="form-label">Target Course <span class="req">*</span></label>
                    <select name="course_id" class="form-control" required>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int) $c['course_id'] ?>">
                                <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Priority <span class="req">*</span></label>
                    <select name="priority" class="form-control">
                        <option value="normal">Normal</option>
                        <option value="important">Important</option>
                        <option value="urgent">Urgent</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Announcement Title <span class="req">*</span></label>
                    <input type="text" name="title" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Message <span class="req">*</span></label>
                    <textarea name="description" class="form-control" rows="4" required></textarea>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;">Publish Course Notice</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Recent Announcements (<?= count($notices) ?>)</h2>
        </div>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Title & Message</th>
                        <th>Scope</th>
                        <th>Priority</th>
                        <th>Author & Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($notices as $n): ?>
                    <tr>
                        <td>
                            <strong><?= e($n['title']) ?></strong>
                            <div style="font-size:13px; color:var(--slate-600);"><?= e($n['description']) ?></div>
                        </td>
                        <td>
                            <span class="badge badge-info"><?= e($n['course_code'] ?: strtoupper($n['audience'])) ?></span>
                        </td>
                        <td><span class="badge <?= status_badge_class($n['priority']) ?>"><?= e($n['priority']) ?></span></td>
                        <td>
                            <?= e($n['author_name']) ?><br>
                            <small style="color:var(--slate-500);"><?= format_datetime($n['published_at']) ?></small>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
