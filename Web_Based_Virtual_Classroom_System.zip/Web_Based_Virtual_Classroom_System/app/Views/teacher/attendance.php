<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Course Attendance Management</h1>
        <p class="page-subtitle">Record date-wise student attendance and review cumulative attendance percentages.</p>
    </div>
</div>

<div class="card">
    <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
        <input type="hidden" name="r" value="teacher/attendance">
        <label class="form-label" style="margin:0;">Select Course:</label>
        <select name="course_id" required>
            <?php foreach ($courses as $c): ?>
                <option value="<?= (int) $c['course_id'] ?>" <?= ((int) $selectedCourseId === (int) $c['course_id']) ? 'selected' : '' ?>>
                    <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <label class="form-label" style="margin:0;">Class Date:</label>
        <input type="date" name="class_date" value="<?= e($classDate) ?>" required>
        <button type="submit" class="btn btn-sm btn-primary">Load Class Sheet</button>
    </form>

    <?php if ($selectedCourseId > 0): ?>
    <div class="card-header">
        <h2 class="card-title">Mark Attendance for Date: <?= format_date($classDate) ?></h2>
        <span class="badge <?= !empty($existingRecords) ? 'badge-success' : 'badge-warning' ?>">
            <?= !empty($existingRecords) ? 'Existing Record Loaded (Editable)' : 'New Class Session' ?>
        </span>
    </div>

    <div class="card-body">
        <?php if (empty($enrolledStudents)): ?>
            <div class="empty-state">No active students are enrolled in this course.</div>
        <?php else: ?>
            <form method="post" action="<?= route_url('teacher/attendance/store') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="course_id" value="<?= (int) $selectedCourseId ?>">
                <input type="hidden" name="class_date" value="<?= e($classDate) ?>">

                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Enrolment No.</th>
                                <th>Student Name</th>
                                <th>Attendance Status</th>
                                <th>Remarks (Optional)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($enrolledStudents as $st):
                                $sid = (int) $st['student_id'];
                                $rec = $existingRecords[$sid] ?? null;
                                $curStatus = $rec['status'] ?? 'Present';
                            ?>
                            <tr>
                                <td><strong><?= e($st['enrollment_no'] ?: '—') ?></strong></td>
                                <td><?= e($st['student_name']) ?></td>
                                <td>
                                    <label style="margin-right:16px; cursor:pointer;">
                                        <input type="radio" name="status[<?= $sid ?>]" value="Present" <?= ($curStatus === 'Present') ? 'checked' : '' ?>>
                                        <span class="badge badge-success">Present</span>
                                    </label>
                                    <label style="cursor:pointer;">
                                        <input type="radio" name="status[<?= $sid ?>]" value="Absent" <?= ($curStatus === 'Absent') ? 'checked' : '' ?>>
                                        <span class="badge badge-danger">Absent</span>
                                    </label>
                                </td>
                                <td>
                                    <input type="text" name="remarks[<?= $sid ?>]" class="form-control"
                                           placeholder="Optional note..."
                                           value="<?= e($rec['remarks'] ?? '') ?>">
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div style="margin-top:16px;">
                    <button type="submit" class="btn btn-primary">Save Attendance Records</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php if (!empty($courseSummary)): ?>
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Course-Wise Cumulative Attendance Summary</h2>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Enrolment No.</th>
                    <th>Student Name</th>
                    <th>Total Classes</th>
                    <th>Present</th>
                    <th>Absent</th>
                    <th>Attendance %</th>
                    <th>Standing</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courseSummary as $sum): ?>
                <tr>
                    <td><strong><?= e($sum['enrollment_no'] ?: '—') ?></strong></td>
                    <td><?= e($sum['student_name']) ?></td>
                    <td><?= (int) $sum['total_classes'] ?></td>
                    <td><?= (int) $sum['present_classes'] ?></td>
                    <td><?= (int) $sum['absent_classes'] ?></td>
                    <td>
                        <strong><?= e($sum['percentage']) ?>%</strong>
                        <div class="progress-track" style="margin-top:4px; max-width:140px;">
                            <div class="progress-fill" style="width:<?= min(100, (float) $sum['percentage']) ?>%;"></div>
                        </div>
                    </td>
                    <td>
                        <span class="badge <?= ((float) $sum['percentage'] >= 75) ? 'badge-success' : 'badge-warning' ?>">
                            <?= ((float) $sum['percentage'] >= 75) ? 'Regular (>=75%)' : 'Low Attendance' ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
