<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Student Academic Performance & Results</h1>
        <p class="page-subtitle">Consolidated view of assignment marks, quiz scores, attendance percentages, and overall grades for your assigned courses.</p>
    </div>
    <a href="<?= route_url('teacher/reports', ['course_id' => $filters['course_id'] ?? 0, 'export' => 'csv']) ?>" class="btn btn-teal">⬇ Export CSV</a>
</div>

<div class="card">
    <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
        <input type="hidden" name="r" value="teacher/results">
        <input type="search" name="q" placeholder="Search student name or enrolment no..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1;">
        <select name="course_id">
            <option value="0">All Assigned Courses</option>
            <?php foreach ($courses as $c): ?>
                <option value="<?= (int) $c['course_id'] ?>" <?= ((int) ($filters['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                    <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-sm btn-primary">Filter</button>
    </form>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Enrolment No.</th>
                    <th>Student Name</th>
                    <th>Assignment Marks</th>
                    <th>Quiz Marks</th>
                    <th>Attendance %</th>
                    <th>Overall %</th>
                    <th>Grade</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($results)): ?>
                    <tr><td colspan="9" class="empty-state">No consolidated result records available yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($results as $r): ?>
                    <tr>
                        <td><strong><?= e($r['course_code']) ?></strong></td>
                        <td><strong><?= e($r['enrollment_no'] ?: '—') ?></strong></td>
                        <td><?= e($r['student_name']) ?></td>
                        <td><?= e($r['assignment_marks_obtained']) ?> / <?= e($r['assignment_marks_max']) ?></td>
                        <td><?= e($r['quiz_marks_obtained']) ?> / <?= e($r['quiz_marks_max']) ?></td>
                        <td><?= e($r['attendance_percentage']) ?>%</td>
                        <td><strong><?= e($r['overall_percentage']) ?>%</strong></td>
                        <td><span class="badge <?= status_badge_class($r['grade']) ?>"><?= e($r['grade']) ?></span></td>
                        <td><?= e($r['remarks'] ?: '—') ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
