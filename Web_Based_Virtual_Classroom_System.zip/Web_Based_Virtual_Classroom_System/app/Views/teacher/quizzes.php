<?php
declare(strict_types=1);
$isEditing = !empty($editQuiz);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Online Objective Quiz Management</h1>
        <p class="page-subtitle">Configure timed multiple-choice quizzes, manage question banks, and inspect student attempt scores.</p>
    </div>
    <a href="<?= route_url('teacher/questions') ?>" class="btn btn-teal">Manage Question Bank</a>
</div>

<div class="grid-sidebar-form">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?= $isEditing ? 'Edit Quiz Settings' : 'Create New Objective Quiz' ?></h2>
            <?php if ($isEditing): ?>
                <a href="<?= route_url('teacher/quizzes') ?>" class="btn btn-sm btn-outline">Cancel</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url($isEditing ? 'teacher/quizzes/update' : 'teacher/quizzes/store') ?>">
                <?= csrf_field() ?>
                <?php if ($isEditing): ?>
                    <input type="hidden" name="quiz_id" value="<?= (int) $editQuiz['quiz_id'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label class="form-label">Course <span class="req">*</span></label>
                    <select name="course_id" class="form-control" required>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int) $c['course_id'] ?>"
                                <?= ((int) ($editQuiz['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                                <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Quiz Title <span class="req">*</span></label>
                    <input type="text" name="title" class="form-control"
                           placeholder="e.g. Quiz 01: Software Engineering Fundamentals"
                           value="<?= e($editQuiz['title'] ?? '') ?>" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Duration (Minutes) <span class="req">*</span></label>
                        <input type="number" name="duration_minutes" class="form-control" min="1" max="300"
                               value="<?= (int) ($editQuiz['duration_minutes'] ?? 15) ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Allowed Attempts <span class="req">*</span></label>
                        <input type="number" name="allowed_attempts" class="form-control" min="1" max="10"
                               value="<?= (int) ($editQuiz['allowed_attempts'] ?? 2) ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Start Date/Time <span class="req">*</span></label>
                        <input type="datetime-local" name="start_time" class="form-control"
                               value="<?= !empty($editQuiz['start_time']) ? date('Y-m-d\TH:i', strtotime($editQuiz['start_time'])) : date('Y-m-d\T09:00') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">End Date/Time <span class="req">*</span></label>
                        <input type="datetime-local" name="end_time" class="form-control"
                               value="<?= !empty($editQuiz['end_time']) ? date('Y-m-d\TH:i', strtotime($editQuiz['end_time'])) : date('Y-m-d\T23:59', strtotime('+60 days')) ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Instructions / Description</label>
                    <textarea name="description" class="form-control" rows="3"><?= e($editQuiz['description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label style="display:flex; align-items:center; gap:8px; font-size:13.5px; margin-bottom:6px;">
                        <input type="checkbox" name="is_published" value="1" <?= !isset($editQuiz) || !empty($editQuiz['is_published']) ? 'checked' : '' ?>>
                        Publish Quiz for Enrolled Students
                    </label>
                    <label style="display:flex; align-items:center; gap:8px; font-size:13.5px;">
                        <input type="checkbox" name="results_published" value="1" <?= !isset($editQuiz) || !empty($editQuiz['results_published']) ? 'checked' : '' ?>>
                        Show Score & Explanations Immediately After Submission
                    </label>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;">
                    <?= $isEditing ? 'Update Quiz Configuration' : 'Create Quiz & Add Questions' ?>
                </button>
            </form>
        </div>
    </div>

    <div>
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Configured Quizzes (<?= count($quizzes) ?>)</h2>
            </div>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Course</th>
                            <th>Quiz Title & Window</th>
                            <th>Questions & Marks</th>
                            <th>Duration / Attempts</th>
                            <th>Student Attempts</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($quizzes)): ?>
                            <tr><td colspan="7" class="empty-state">No quizzes created yet.</td></tr>
                        <?php else: ?>
                            <?php foreach ($quizzes as $q): ?>
                            <tr>
                                <td><strong><?= e($q['course_code']) ?></strong></td>
                                <td>
                                    <strong><?= e($q['title']) ?></strong><br>
                                    <small style="color:var(--slate-500);">Closes: <?= format_datetime($q['end_time']) ?></small>
                                </td>
                                <td>
                                    <?= (int) $q['question_count'] ?> Qs • <strong><?= e($q['total_marks']) ?> Marks</strong>
                                </td>
                                <td><?= (int) $q['duration_minutes'] ?> mins • Max <?= (int) $q['allowed_attempts'] ?></td>
                                <td>
                                    <a href="<?= route_url('teacher/quizzes', ['attempts_quiz_id' => $q['quiz_id']]) ?>">
                                        <?= (int) $q['attempt_count'] ?> Completed
                                    </a>
                                </td>
                                <td>
                                    <span class="badge <?= !empty($q['is_published']) ? 'badge-success' : 'badge-neutral' ?>">
                                        <?= !empty($q['is_published']) ? 'Published' : 'Draft' ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?= route_url('teacher/questions', ['quiz_id' => $q['quiz_id'], 'course_id' => $q['course_id']]) ?>" class="btn btn-sm btn-teal">+ Questions</a>
                                        <a href="<?= route_url('teacher/quizzes', ['edit' => $q['quiz_id']]) ?>" class="btn btn-sm btn-outline">Edit</a>
                                        <form method="post" action="<?= route_url('teacher/quizzes/delete') ?>" data-confirm="Delete quiz <?= e($q['title']) ?>?" style="margin:0;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="quiz_id" value="<?= (int) $q['quiz_id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if (!empty($selectedQuiz)): ?>
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Student Attempts for <?= e($selectedQuiz['title']) ?> (<?= count($selectedQuizAttempts) ?>)</h2>
            </div>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Enrolment No.</th>
                            <th>Student Name</th>
                            <th>Attempt #</th>
                            <th>Score</th>
                            <th>Percentage</th>
                            <th>Submitted At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($selectedQuizAttempts)): ?>
                            <tr><td colspan="6" class="empty-state">No students have attempted this quiz yet.</td></tr>
                        <?php else: ?>
                            <?php foreach ($selectedQuizAttempts as $atp): ?>
                            <tr>
                                <td><strong><?= e($atp['enrollment_no'] ?: '—') ?></strong></td>
                                <td><?= e($atp['student_name']) ?></td>
                                <td>#<?= (int) $atp['attempt_number'] ?></td>
                                <td><strong><?= e($atp['score']) ?> / <?= e($atp['total_marks']) ?></strong></td>
                                <td><span class="badge badge-success"><?= e($atp['percentage']) ?>%</span></td>
                                <td><?= format_datetime($atp['submitted_at']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
