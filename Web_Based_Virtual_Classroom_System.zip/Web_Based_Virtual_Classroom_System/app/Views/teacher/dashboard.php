<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Teacher Faculty Dashboard</h1>
        <p class="page-subtitle">Manage your assigned courses, upload study materials, evaluate submissions, conduct quizzes, and record attendance.</p>
    </div>
    <div class="btn-group">
        <a href="<?= route_url('teacher/materials') ?>" class="btn btn-primary">+ Upload Material</a>
        <a href="<?= route_url('teacher/assignments') ?>" class="btn btn-teal">+ Create Assignment</a>
        <a href="<?= route_url('teacher/attendance') ?>" class="btn btn-outline">Record Attendance</a>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <span class="stat-card-label">Assigned Courses</span>
        <span class="stat-card-value"><?= (int) $stats['assigned_courses'] ?></span>
        <span class="stat-card-hint">Active Faculty Courses</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Enrolled Students</span>
        <span class="stat-card-value"><?= (int) $stats['enrolled_students'] ?></span>
        <span class="stat-card-hint">Across Assigned Courses</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Assignments Created</span>
        <span class="stat-card-value"><?= (int) $stats['total_assignments'] ?></span>
        <span class="stat-card-hint">Course Assessments</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Pending Evaluations</span>
        <span class="stat-card-value"><?= (int) $stats['pending_submissions'] ?></span>
        <span class="stat-card-hint">Awaiting Marks</span>
    </div>
    <div class="stat-card">
        <span class="stat-card-label">Objective Quizzes</span>
        <span class="stat-card-value"><?= (int) $stats['created_quizzes'] ?></span>
        <span class="stat-card-hint">Online MCQ Quizzes</span>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">My Assigned Courses</h2>
        <a href="<?= route_url('teacher/courses') ?>" class="btn btn-sm btn-outline">View All Courses</a>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Semester</th>
                    <th>Enrolled Students</th>
                    <th>Materials</th>
                    <th>Assignments</th>
                    <th>Quizzes</th>
                    <th>Status</th>
                    <th>Quick Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($myCourses)): ?>
                    <tr><td colspan="9" class="empty-state">No courses are currently assigned to your faculty account.</td></tr>
                <?php else: ?>
                    <?php foreach ($myCourses as $c): ?>
                    <tr>
                        <td><strong><?= e($c['course_code']) ?></strong></td>
                        <td><?= e($c['course_name']) ?></td>
                        <td><?= e($c['semester']) ?></td>
                        <td><?= (int) $c['enrolled_count'] ?></td>
                        <td><?= (int) $c['material_count'] ?></td>
                        <td><?= (int) $c['assignment_count'] ?></td>
                        <td><?= (int) $c['quiz_count'] ?></td>
                        <td><span class="badge <?= status_badge_class($c['status']) ?>"><?= e($c['status']) ?></span></td>
                        <td>
                            <div class="btn-group">
                                <a href="<?= route_url('teacher/courses', ['course_id' => $c['course_id']]) ?>" class="btn btn-sm btn-outline">Students</a>
                                <a href="<?= route_url('teacher/attendance', ['course_id' => $c['course_id']]) ?>" class="btn btn-sm btn-primary">Attendance</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Pending Student Submissions</h2>
            <a href="<?= route_url('teacher/submissions') ?>" class="btn btn-sm btn-outline">Evaluate All</a>
        </div>
        <div class="card-body">
            <?php if (empty($pendingSubs)): ?>
                <div class="empty-state">All submitted assignments have been evaluated.</div>
            <?php else: ?>
                <?php foreach ($pendingSubs as $sub): ?>
                    <div style="padding:10px 0; border-bottom:1px solid var(--slate-100); display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <strong><?= e($sub['student_name']) ?> (<?= e($sub['enrollment_no'] ?: '—') ?>)</strong><br>
                            <small style="color:var(--slate-500);"><?= e($sub['course_code']) ?> • <?= e($sub['assignment_title']) ?></small>
                        </div>
                        <a href="<?= route_url('teacher/submissions', ['assignment_id' => $sub['assignment_id']]) ?>" class="btn btn-sm btn-primary">Grade</a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Recent Notices & Deadlines</h2>
            <a href="<?= route_url('teacher/notices') ?>" class="btn btn-sm btn-outline">Course Notices</a>
        </div>
        <div class="card-body">
            <?php foreach ($recentNotices as $n): ?>
                <div style="padding:8px 0; border-bottom:1px solid var(--slate-100);">
                    <div style="display:flex; justify-content:space-between;">
                        <strong><?= e($n['title']) ?></strong>
                        <span class="badge <?= status_badge_class($n['priority']) ?>"><?= e($n['priority']) ?></span>
                    </div>
                    <p style="margin:3px 0; font-size:13px; color:var(--slate-600);"><?= e($n['description']) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
