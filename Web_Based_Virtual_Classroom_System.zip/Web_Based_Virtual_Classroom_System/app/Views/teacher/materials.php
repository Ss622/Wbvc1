<?php
declare(strict_types=1);
$isEditing = !empty($editMaterial);
$categories = ['Lecture Notes', 'Syllabus', 'Reference Book', 'Lab Manual', 'Presentation', 'Worksheet'];
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Course Learning Materials</h1>
        <p class="page-subtitle">Upload, categorize, edit metadata, and securely distribute study materials to enrolled students.</p>
    </div>
</div>

<div class="grid-sidebar-form">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?= $isEditing ? 'Edit Material Metadata' : 'Upload Learning Material' ?></h2>
            <?php if ($isEditing): ?>
                <a href="<?= route_url('teacher/materials') ?>" class="btn btn-sm btn-outline">Cancel</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url($isEditing ? 'teacher/materials/update' : 'teacher/materials/store') ?>" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <?php if ($isEditing): ?>
                    <input type="hidden" name="material_id" value="<?= (int) $editMaterial['material_id'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label class="form-label">Assigned Course <span class="req">*</span></label>
                    <select name="course_id" class="form-control" required>
                        <option value="">-- Select Assigned Course --</option>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int) $c['course_id'] ?>"
                                <?= ((int) ($editMaterial['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                                <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Resource Title <span class="req">*</span></label>
                    <input type="text" name="title" class="form-control"
                           placeholder="e.g. Unit 1 Lecture Notes: IEEE SRS"
                           value="<?= e($editMaterial['title'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Resource Category <span class="req">*</span></label>
                    <select name="category" class="form-control">
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= e($cat) ?>" <?= (($editMaterial['category'] ?? 'Lecture Notes') === $cat) ? 'selected' : '' ?>>
                                <?= e($cat) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Description / Study Instructions</label>
                    <textarea name="description" class="form-control" rows="3"><?= e($editMaterial['description'] ?? '') ?></textarea>
                </div>

                <?php if (!$isEditing): ?>
                <div class="form-group">
                    <label class="form-label">Select File <span class="req">*</span></label>
                    <input type="file" name="material_file" class="form-control" required>
                    <div class="form-hint">Allowed: PDF, DOC, DOCX, PPT, PPTX, XLS, XLSX, TXT, JPG, PNG (Max 10 MB).</div>
                </div>
                <?php endif; ?>

                <button type="submit" class="btn btn-primary" style="width:100%;">
                    <?= $isEditing ? 'Save Metadata Changes' : 'Upload & Publish Material' ?>
                </button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Uploaded Course Materials (<?= count($materials) ?>)</h2>
        </div>

        <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
            <input type="hidden" name="r" value="teacher/materials">
            <input type="search" name="q" placeholder="Search title or description..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1;">
            <select name="course_id">
                <option value="0">All My Courses</option>
                <?php foreach ($courses as $c): ?>
                    <option value="<?= (int) $c['course_id'] ?>" <?= ((int) ($filters['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                        <?= e($c['course_code']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-sm btn-primary">Filter</button>
        </form>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Course</th>
                        <th>Title & Description</th>
                        <th>Category</th>
                        <th>File Info</th>
                        <th>Downloads</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($materials)): ?>
                        <tr><td colspan="6" class="empty-state">No learning materials uploaded yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($materials as $m): ?>
                        <tr>
                            <td><strong><?= e($m['course_code']) ?></strong></td>
                            <td>
                                <strong><?= e($m['title']) ?></strong>
                                <div style="font-size:12.5px; color:var(--slate-500);"><?= e($m['description']) ?></div>
                            </td>
                            <td><span class="badge badge-info"><?= e($m['category']) ?></span></td>
                            <td>
                                <code>.<?= e(strtoupper($m['file_type'])) ?></code> (<?= format_bytes((int) $m['file_size']) ?>)<br>
                                <small style="color:var(--slate-400);"><?= format_date($m['created_at']) ?></small>
                            </td>
                            <td><?= (int) $m['download_count'] ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?= route_url('download/material', ['id' => $m['material_id']]) ?>" class="btn btn-sm btn-teal">Download</a>
                                    <a href="<?= route_url('teacher/materials', ['edit' => $m['material_id']]) ?>" class="btn btn-sm btn-outline">Edit</a>
                                    <form method="post" action="<?= route_url('teacher/materials/delete') ?>" data-confirm="Delete material <?= e($m['title']) ?>?" style="margin:0;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="material_id" value="<?= (int) $m['material_id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
