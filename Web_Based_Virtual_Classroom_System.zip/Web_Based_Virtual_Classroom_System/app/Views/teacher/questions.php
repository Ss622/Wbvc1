<?php
declare(strict_types=1);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Question Bank & Quiz MCQ Builder</h1>
        <p class="page-subtitle">Add single-correct multiple-choice questions with options A, B, C, D, marks, and explanations.</p>
    </div>
    <a href="<?= route_url('teacher/quizzes') ?>" class="btn btn-outline">&larr; Back to Quizzes</a>
</div>

<div class="grid-sidebar-form">
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Add New Multiple-Choice Question</h2>
        </div>
        <div class="card-body">
            <form method="post" action="<?= route_url('teacher/questions/store') ?>">
                <?= csrf_field() ?>

                <div class="form-group">
                    <label class="form-label">Course <span class="req">*</span></label>
                    <select name="course_id" class="form-control" required>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int) $c['course_id'] ?>"
                                <?= ((int) ($filters['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                                <?= e($c['course_code']) ?> — <?= e($c['course_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Attach to Quiz</label>
                    <select name="quiz_id" class="form-control">
                        <option value="">-- Question Bank Only (Unassigned) --</option>
                        <?php foreach ($quizzes as $q): ?>
                            <option value="<?= (int) $q['quiz_id'] ?>"
                                <?= ((int) ($filters['quiz_id'] ?? 0) === (int) $q['quiz_id']) ? 'selected' : '' ?>>
                                [<?= e($q['course_code']) ?>] <?= e($q['title']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Topic / Unit</label>
                        <input type="text" name="topic" class="form-control" placeholder="e.g. Normalization" value="General">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Marks <span class="req">*</span></label>
                        <input type="number" step="0.5" min="0.5" max="100" name="marks" class="form-control" value="2.00" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Question Text <span class="req">*</span></label>
                    <textarea name="question_text" class="form-control" rows="3" required></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Option A <span class="req">*</span></label>
                    <input type="text" name="option_a" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Option B <span class="req">*</span></label>
                    <input type="text" name="option_b" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Option C <span class="req">*</span></label>
                    <input type="text" name="option_c" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Option D <span class="req">*</span></label>
                    <input type="text" name="option_d" class="form-control" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Correct Answer <span class="req">*</span></label>
                        <select name="correct_option" class="form-control" required>
                            <option value="A">Option A</option>
                            <option value="B">Option B</option>
                            <option value="C">Option C</option>
                            <option value="D">Option D</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Display Order</label>
                        <input type="number" name="sort_order" class="form-control" value="1" min="1">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Answer Explanation (Shown after quiz completion)</label>
                    <input type="text" name="explanation" class="form-control" placeholder="Brief rationale for correct answer">
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;">Add Question to Bank</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Configured Questions (<?= count($questions) ?>)</h2>
        </div>

        <form method="get" action="<?= base_url('index.php') ?>" class="filter-bar">
            <input type="hidden" name="r" value="teacher/questions">
            <input type="search" name="q" placeholder="Search question text or topic..." value="<?= e($filters['search'] ?? '') ?>" style="flex:1;">
            <select name="quiz_id">
                <option value="0">All Quizzes</option>
                <?php foreach ($quizzes as $q): ?>
                    <option value="<?= (int) $q['quiz_id'] ?>" <?= ((int) ($filters['quiz_id'] ?? 0) === (int) $q['quiz_id']) ? 'selected' : '' ?>>
                        <?= e($q['title']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-sm btn-primary">Filter</button>
        </form>

        <div class="card-body">
            <?php if (empty($questions)): ?>
                <div class="empty-state">No questions found for the selected filter.</div>
            <?php else: ?>
                <?php foreach ($questions as $idx => $qn): ?>
                    <div class="quiz-question-card">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:10px;">
                            <div>
                                <span class="badge badge-info"><?= e($qn['course_code']) ?></span>
                                <span class="badge badge-neutral"><?= e($qn['topic']) ?></span>
                                <?php if (!empty($qn['quiz_title'])): ?>
                                    <small style="color:var(--slate-500); margin-left:6px;"><?= e($qn['quiz_title']) ?></small>
                                <?php endif; ?>
                                <h3 style="margin:8px 0; font-size:15px;">Q<?= $idx + 1 ?>. <?= e($qn['question_text']) ?> (<?= e($qn['marks']) ?> Marks)</h3>
                            </div>
                            <form method="post" action="<?= route_url('teacher/questions/delete') ?>" data-confirm="Delete this question?" style="margin:0;">
                                <?= csrf_field() ?>
                                <input type="hidden" name="question_id" value="<?= (int) $qn['question_id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </div>

                        <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:8px; margin-top:8px;">
                            <?php foreach ($qn['options'] as $opt): ?>
                                <div style="padding:7px 11px; border-radius:6px; font-size:13px; border:1px solid <?= !empty($opt['is_correct']) ? '#86efac' : 'var(--slate-200)' ?>; background:<?= !empty($opt['is_correct']) ? 'var(--emerald-100)' : 'var(--slate-50)' ?>;">
                                    <strong><?= e($opt['option_label']) ?>.</strong> <?= e($opt['option_text']) ?>
                                    <?php if (!empty($opt['is_correct'])): ?>
                                        <strong style="color:#166534;"> ✓ (Correct)</strong>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php if (!empty($qn['explanation'])): ?>
                            <div style="margin-top:8px; font-size:12.5px; color:var(--slate-500);">
                                <strong>Explanation:</strong> <?= e($qn['explanation']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
