<?php
declare(strict_types=1);
use App\Core\Auth;
?>
<div class="card" style="max-width:560px; margin:40px auto; text-align:center;">
    <div class="card-body" style="padding:36px 28px;">
        <div style="font-size:42px; font-weight:800; color:var(--red-600); margin-bottom:10px;">403</div>
        <h2 style="margin:0 0 10px; font-size:20px;"><?= e($pageTitle ?? 'Access Denied (403 Forbidden)') ?></h2>
        <p style="color:var(--slate-600); margin-bottom:24px;"><?= e($message ?? 'An unexpected error occurred.') ?></p>
        <?php if (Auth::check()): ?>
            <a href="<?= route_url(Auth::dashboardRoute()) ?>" class="btn btn-primary">Return to Dashboard</a>
        <?php else: ?>
            <a href="<?= route_url('login') ?>" class="btn btn-primary">Return to Sign In</a>
        <?php endif; ?>
    </div>
</div>
