<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Models\QuestionModel;
use RuntimeException;

/**
 * Transactional Server-Side Objective Quiz Scoring Engine.
 * Enforces attempt status, time limit with small network grace buffer,
 * compares answers strictly on the server, records attempt_answers, and updates consolidated results.
 */
class QuizScoringService
{
    public static function submitAndScore(int $attemptId, int $studentId, array $submittedAnswers): array
    {
        $db = Database::getConnection();

        $stmt = $db->prepare(
            'SELECT a.*, q.course_id, q.duration_minutes, q.total_marks AS quiz_total_marks
             FROM attempts a
             INNER JOIN quizzes q ON a.quiz_id = q.quiz_id
             WHERE a.attempt_id = :aid AND a.student_id = :sid
             LIMIT 1'
        );
        $stmt->execute(['aid' => $attemptId, 'sid' => $studentId]);
        $attempt = $stmt->fetch();

        if (!$attempt) {
            throw new RuntimeException('Quiz attempt record not found or unauthorized.');
        }

        if ($attempt['status'] === 'completed') {
            throw new RuntimeException('This quiz attempt has already been submitted and scored.');
        }

        // Server-side time limit validation (allows 60-second network submission grace buffer)
        $startedAt = strtotime((string) $attempt['started_at']);
        $maxAllowedSeconds = ((int) $attempt['duration_minutes'] * 60) + 60;
        $elapsedSeconds = time() - ($startedAt ?: time());
        $isExpired = ($elapsedSeconds > $maxAllowedSeconds);

        $questionModel = new QuestionModel();
        $questions = $questionModel->getByQuiz((int) $attempt['quiz_id'], true);

        $db->beginTransaction();
        try {
            $delOld = $db->prepare('DELETE FROM attempt_answers WHERE attempt_id = :aid');
            $delOld->execute(['aid' => $attemptId]);

            $insAns = $db->prepare(
                'INSERT INTO attempt_answers (attempt_id, question_id, selected_option, is_correct, marks_awarded)
                 VALUES (:aid, :qid, :sel, :correct, :marks)'
            );

            $totalScore = 0.0;
            $totalMarks = 0.0;

            foreach ($questions as $q) {
                $qid = (int) $q['question_id'];
                $qMarks = (float) $q['marks'];
                $totalMarks += $qMarks;

                $rawSelected = isset($submittedAnswers[$qid]) ? strtoupper(trim((string) $submittedAnswers[$qid])) : null;
                $selected = in_array($rawSelected, ['A', 'B', 'C', 'D'], true) ? $rawSelected : null;

                $isCorrect = ($selected !== null && $selected === strtoupper((string) $q['correct_option'])) ? 1 : 0;
                $awarded = $isCorrect ? $qMarks : 0.00;
                $totalScore += $awarded;

                $insAns->execute([
                    'aid'     => $attemptId,
                    'qid'     => $qid,
                    'sel'     => $selected,
                    'correct' => $isCorrect,
                    'marks'   => $awarded,
                ]);
            }

            $percentage = $totalMarks > 0 ? round(($totalScore / $totalMarks) * 100, 2) : 0.00;

            $updAttempt = $db->prepare(
                "UPDATE attempts
                 SET submitted_at = :sub_at,
                     score = :score,
                     total_marks = :tmarks,
                     percentage = :pct,
                     status = 'completed'
                 WHERE attempt_id = :aid"
            );
            $updAttempt->execute([
                'sub_at' => date('Y-m-d H:i:s'),
                'score'  => $totalScore,
                'tmarks' => $totalMarks,
                'pct'    => $percentage,
                'aid'    => $attemptId,
            ]);

            $db->commit();

            // Synchronize consolidated course result
            ResultCalculationService::recalculateForStudentCourse($studentId, (int) $attempt['course_id']);

            return [
                'attempt_id'  => $attemptId,
                'score'       => $totalScore,
                'total_marks' => $totalMarks,
                'percentage'  => $percentage,
                'was_expired' => $isExpired,
            ];
        } catch (\Throwable $e) {
            $db->rollBack();
            throw $e;
        }
    }
}
