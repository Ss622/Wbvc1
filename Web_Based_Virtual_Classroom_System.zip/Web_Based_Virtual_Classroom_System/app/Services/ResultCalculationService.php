<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/**
 * Computes and synchronizes a student's consolidated course result in the `results` table
 * based on genuine published assignment marks, completed quiz scores, and attendance records.
 *
 * Documented IGNOU BCA Grading Scheme (configured in `settings` table):
 *   Overall Assessment % = ((Assignment Marks Obtained + Quiz Marks Obtained) / (Assignment Max + Quiz Max)) * 100
 *   Grade Mapping:
 *     >= 80% : A+ (Distinction)
 *     70-79% : A  (First Division)
 *     60-69% : B  (Second Division)
 *     50-59% : C  (Pass)
 *     40-49% : D  (Satisfactory)
 *     <  40% : F  (Needs Improvement)
 */
class ResultCalculationService
{
    public static function recalculateForStudentCourse(int $studentId, int $courseId): void
    {
        $db = Database::getConnection();

        // 1. Published assignment marks in this course
        $asgStmt = $db->prepare(
            "SELECT COALESCE(SUM(s.marks), 0) AS obtained,
                    COALESCE(SUM(a.max_marks), 0) AS max_total
             FROM submissions s
             INNER JOIN assignments a ON s.assignment_id = a.assignment_id
             WHERE s.student_id = :sid
               AND a.course_id = :cid
               AND s.status = 'published'"
        );
        $asgStmt->execute(['sid' => $studentId, 'cid' => $courseId]);
        $asg = $asgStmt->fetch();
        $asgObtained = (float) ($asg['obtained'] ?? 0.0);
        $asgMax      = (float) ($asg['max_total'] ?? 0.0);

        // 2. Best score per quiz in this course (where results_published = 1)
        $quizStmt = $db->prepare(
            "SELECT q.quiz_id,
                    q.total_marks,
                    MAX(atp.score) AS best_score
             FROM quizzes q
             INNER JOIN attempts atp ON atp.quiz_id = q.quiz_id
             WHERE q.course_id = :cid
               AND atp.student_id = :sid
               AND atp.status = 'completed'
               AND q.results_published = 1
             GROUP BY q.quiz_id, q.total_marks"
        );
        $quizStmt->execute(['cid' => $courseId, 'sid' => $studentId]);
        $quizRows = $quizStmt->fetchAll();

        $quizObtained = 0.0;
        $quizMax      = 0.0;
        foreach ($quizRows as $qr) {
            $quizObtained += (float) $qr['best_score'];
            $quizMax      += (float) $qr['total_marks'];
        }

        // 3. Attendance percentage
        $attStmt = $db->prepare(
            "SELECT COUNT(*) AS total_classes,
                    SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present_classes
             FROM attendance
             WHERE course_id = :cid AND student_id = :sid"
        );
        $attStmt->execute(['cid' => $courseId, 'sid' => $studentId]);
        $attRow = $attStmt->fetch();
        $totalClasses   = (int) ($attRow['total_classes'] ?? 0);
        $presentClasses = (int) ($attRow['present_classes'] ?? 0);
        $attendancePct  = $totalClasses > 0 ? round(($presentClasses / $totalClasses) * 100, 2) : 0.00;
        $attendancePct  = max(0.00, min(100.00, $attendancePct));

        // 4. Overall Assessment Percentage
        $totalAssessmentMax = $asgMax + $quizMax;
        $totalAssessmentObt = $asgObtained + $quizObtained;
        $overallPct = $totalAssessmentMax > 0
            ? round(($totalAssessmentObt / $totalAssessmentMax) * 100, 2)
            : 0.00;
        $overallPct = max(0.00, min(100.00, $overallPct));

        [$grade, $remarks] = self::mapGrade($overallPct, $totalAssessmentMax > 0);

        // 5. Upsert into results table
        $chk = $db->prepare('SELECT result_id FROM results WHERE student_id = :sid AND course_id = :cid LIMIT 1');
        $chk->execute(['sid' => $studentId, 'cid' => $courseId]);
        $existingId = $chk->fetchColumn();

        if ($existingId) {
            $upd = $db->prepare(
                'UPDATE results
                 SET assignment_marks_obtained = :ao,
                     assignment_marks_max = :am,
                     quiz_marks_obtained = :qo,
                     quiz_marks_max = :qm,
                     attendance_percentage = :att,
                     overall_percentage = :ov,
                     grade = :grade,
                     remarks = :remarks,
                     is_published = 1,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE result_id = :id'
            );
            $upd->execute([
                'ao'      => $asgObtained,
                'am'      => $asgMax,
                'qo'      => $quizObtained,
                'qm'      => $quizMax,
                'att'     => $attendancePct,
                'ov'      => $overallPct,
                'grade'   => $grade,
                'remarks' => $remarks,
                'id'      => (int) $existingId,
            ]);
        } else {
            $ins = $db->prepare(
                'INSERT INTO results (student_id, course_id, assignment_marks_obtained, assignment_marks_max, quiz_marks_obtained, quiz_marks_max, attendance_percentage, overall_percentage, grade, remarks, is_published)
                 VALUES (:sid, :cid, :ao, :am, :qo, :qm, :att, :ov, :grade, :remarks, 1)'
            );
            $ins->execute([
                'sid'     => $studentId,
                'cid'     => $courseId,
                'ao'      => $asgObtained,
                'am'      => $asgMax,
                'qo'      => $quizObtained,
                'qm'      => $quizMax,
                'att'     => $attendancePct,
                'ov'      => $overallPct,
                'grade'   => $grade,
                'remarks' => $remarks,
            ]);
        }
    }

    public static function mapGrade(float $percentage, bool $hasEvaluatedWork = true): array
    {
        if (!$hasEvaluatedWork) {
            return ['In Progress', 'No published assessments recorded yet'];
        }
        if ($percentage >= 80.0) {
            return ['A+', 'Distinction — Excellent Academic Performance'];
        }
        if ($percentage >= 70.0) {
            return ['A', 'First Division — Very Good Performance'];
        }
        if ($percentage >= 60.0) {
            return ['B', 'Second Division — Good Academic Standing'];
        }
        if ($percentage >= 50.0) {
            return ['C', 'Pass — Satisfactory Progress'];
        }
        if ($percentage >= 40.0) {
            return ['D', 'Pass — Minimum Qualifying Grade'];
        }
        return ['F', 'Needs Improvement — Below Minimum Passing Threshold'];
    }
}
