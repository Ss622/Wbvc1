<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Flash;
use App\Helpers\FileUpload;
use App\Models\ActivityLogModel;
use App\Models\AssignmentModel;
use App\Models\AttemptModel;
use App\Models\AttendanceModel;
use App\Models\CourseModel;
use App\Models\EnrollmentModel;
use App\Models\MaterialModel;
use App\Models\NoticeModel;
use App\Models\QuestionModel;
use App\Models\QuizModel;
use App\Models\ResultModel;
use App\Models\SubmissionModel;
use App\Services\QuizScoringService;

/**
 * Student Panel Controller.
 * Enforces strict enrollment-based authorization and student data isolation
 * so a student can only view enrolled courses and their own private academic records.
 */
class StudentController extends Controller
{
    private function studentId(): int
    {
        return (int) Auth::id();
    }

    private function verifyEnrollment(int $courseId): array
    {
        $enrollmentModel = new EnrollmentModel();
        if (!$enrollmentModel->isEnrolled($this->studentId(), $courseId)) {
            $this->abortForbidden('Access Denied: You are not enrolled in this course.');
        }
        $course = (new CourseModel())->findById($courseId);
        if (!$course || $course['status'] !== 'published') {
            $this->abortNotFound('Course is not currently available.');
        }
        return $course;
    }

    public function dashboard(): void
    {
        $sid = $this->studentId();
        $courseModel     = new CourseModel();
        $assignmentModel = new AssignmentModel();
        $quizModel       = new QuizModel();
        $attendanceModel = new AttendanceModel();
        $resultModel     = new ResultModel();
        $noticeModel     = new NoticeModel();

        $enrolledCourses = $courseModel->getStudentEnrolledCourses($sid);
        $assignments     = $assignmentModel->getForStudent($sid);
        $quizzes         = $quizModel->getForStudent($sid);
        $results         = $resultModel->getAll(['student_id' => $sid, 'is_published' => 1]);
        $notices         = array_slice($noticeModel->getVisibleForStudent($sid), 0, 5);

        $pendingAssignments   = 0;
        $submittedAssignments = 0;
        foreach ($assignments as $a) {
            if (empty($a['submission_id'])) {
                $pendingAssignments++;
            } else {
                $submittedAssignments++;
            }
        }

        $upcomingQuizzes  = 0;
        $completedQuizzes = 0;
        foreach ($quizzes as $q) {
            if ((int) $q['student_attempts'] > 0) {
                $completedQuizzes++;
            } else {
                $upcomingQuizzes++;
            }
        }

        $stats = [
            'enrolled_courses'      => count($enrolledCourses),
            'pending_assignments'   => $pendingAssignments,
            'submitted_assignments' => $submittedAssignments,
            'upcoming_quizzes'      => $upcomingQuizzes,
            'completed_quizzes'     => $completedQuizzes,
            'attendance_percentage' => $attendanceModel->calculateStudentOverallPercentage($sid),
            'published_results'     => count($results),
        ];

        $this->render('student/dashboard', [
            'pageTitle'       => 'Student Learning Dashboard',
            'stats'           => $stats,
            'enrolledCourses' => $enrolledCourses,
            'assignments'     => array_slice($assignments, 0, 5),
            'quizzes'         => array_slice($quizzes, 0, 4),
            'notices'         => $notices,
        ]);
    }

    public function courses(): void
    {
        $sid = $this->studentId();
        $search = trim((string) ($_GET['q'] ?? ''));
        $courseModel = new CourseModel();

        $selectedCourse = null;
        $courseMaterials = [];
        $courseAssignments = [];
        $courseQuizzes = [];
        $courseNotices = [];

        if (!empty($_GET['course_id'])) {
            $cid = (int) $_GET['course_id'];
            $selectedCourse = $this->verifyEnrollment($cid);
            $courseMaterials   = (new MaterialModel())->getAll(['course_id' => $cid]);
            $courseAssignments = (new AssignmentModel())->getForStudent($sid, ['course_id' => $cid]);
            $courseQuizzes     = (new QuizModel())->getForStudent($sid, ['course_id' => $cid]);
            $courseNotices     = (new NoticeModel())->getVisibleForStudent($sid, ['course_id' => $cid]);
        }

        $this->render('student/courses', [
            'pageTitle'         => 'My Enrolled Courses',
            'courses'           => $courseModel->getStudentEnrolledCourses($sid, $search),
            'search'            => $search,
            'selectedCourse'    => $selectedCourse,
            'courseMaterials'   => $courseMaterials,
            'courseAssignments' => $courseAssignments,
            'courseQuizzes'     => $courseQuizzes,
            'courseNotices'     => $courseNotices,
        ]);
    }

    public function materials(): void
    {
        $sid = $this->studentId();
        $courseId = (int) ($_GET['course_id'] ?? 0);
        if ($courseId > 0) {
            $this->verifyEnrollment($courseId);
        }

        $filters = [
            'student_id' => $sid,
            'course_id'  => $courseId,
            'category'   => trim((string) ($_GET['category'] ?? '')),
            'search'     => trim((string) ($_GET['q'] ?? '')),
        ];

        $this->render('student/materials', [
            'pageTitle' => 'Course Learning Materials',
            'materials' => (new MaterialModel())->getAll($filters),
            'courses'   => (new CourseModel())->getStudentEnrolledCourses($sid),
            'filters'   => $filters,
        ]);
    }

    public function assignments(): void
    {
        $sid = $this->studentId();
        $courseId = (int) ($_GET['course_id'] ?? 0);
        if ($courseId > 0) {
            $this->verifyEnrollment($courseId);
        }

        $filters = [
            'course_id' => $courseId,
            'search'    => trim((string) ($_GET['q'] ?? '')),
        ];

        $this->render('student/assignments', [
            'pageTitle'   => 'Course Assignments',
            'assignments' => (new AssignmentModel())->getForStudent($sid, $filters),
            'courses'     => (new CourseModel())->getStudentEnrolledCourses($sid),
            'filters'     => $filters,
        ]);
    }

    public function submitAssignment(): void
    {
        $this->requirePost();
        $sid = $this->studentId();
        $assignmentId = (int) ($_POST['assignment_id'] ?? 0);

        $assignment = (new AssignmentModel())->findById($assignmentId);
        if (!$assignment || $assignment['status'] === 'draft') {
            $this->abortNotFound('Assignment not found.');
        }

        $this->verifyEnrollment((int) $assignment['course_id']);

        if ($assignment['status'] === 'closed') {
            Flash::set('danger', 'This assignment is closed and no longer accepts submissions.');
            $this->redirect('student/assignments');
        }

        $today = date('Y-m-d');
        $isLate = ($today > (string) $assignment['due_date']);
        if ($isLate && empty($assignment['allow_late'])) {
            Flash::set('danger', 'The submission deadline (' . $assignment['due_date'] . ') has passed and late submissions are not permitted for this assignment.');
            $this->redirect('student/assignments');
        }

        $submissionModel = new SubmissionModel();
        $existing = $submissionModel->findByAssignmentAndStudent($assignmentId, $sid);
        if ($existing && in_array($existing['status'], ['evaluated', 'published'], true)) {
            Flash::set('warning', 'Your submission has already been evaluated by the teacher and cannot be overwritten.');
            $this->redirect('student/submissions');
        }

        $textResponse = trim((string) ($_POST['text_response'] ?? ''));
        $hasFile = !empty($_FILES['submission_file']['name']);

        if ($textResponse === '' && !$hasFile && empty($existing['file_path'])) {
            Flash::set('danger', 'Please provide either a written response or attach your assignment file before submitting.');
            $this->redirect('student/assignments');
        }

        $fileMeta = [];
        if ($hasFile) {
            try {
                $fileMeta = FileUpload::upload($_FILES['submission_file'], 'submissions');
            } catch (\RuntimeException $e) {
                Flash::set('danger', $e->getMessage());
                $this->redirect('student/assignments');
            }
        }

        $subId = $submissionModel->createOrUpdateSubmission([
            'assignment_id' => $assignmentId,
            'student_id'    => $sid,
            'text_response' => $textResponse,
            'file_path'     => $fileMeta['file_path'] ?? null,
            'original_name' => $fileMeta['original_name'] ?? null,
            'file_size'     => $fileMeta['file_size'] ?? 0,
            'is_late'       => $isLate ? 1 : 0,
        ]);

        ActivityLogModel::record('ASSIGNMENT_SUBMIT', "Submitted work for assignment: {$assignment['title']}.", 'submission', $subId);
        Flash::set('success', 'Your assignment submission has been recorded successfully.');
        $this->redirect('student/submissions');
    }

    public function submissions(): void
    {
        $sid = $this->studentId();
        $submissions = (new SubmissionModel())->getAll([
            'student_id' => $sid,
            'search'     => trim((string) ($_GET['q'] ?? '')),
        ]);

        // Hide unpublished marks/feedback from student view
        foreach ($submissions as &$sub) {
            if ($sub['status'] !== 'published') {
                $sub['marks']    = null;
                $sub['feedback'] = null;
            }
        }

        $this->render('student/submissions', [
            'pageTitle'   => 'My Assignment Submissions',
            'submissions' => $submissions,
        ]);
    }

    // ------------------------------------------------------------------------
    // ONLINE QUIZZES & AUTOMATED SCORING
    // ------------------------------------------------------------------------
    public function quizzes(): void
    {
        $sid = $this->studentId();
        $courseId = (int) ($_GET['course_id'] ?? 0);
        if ($courseId > 0) {
            $this->verifyEnrollment($courseId);
        }

        $this->render('student/quizzes', [
            'pageTitle' => 'Online Objective Quizzes',
            'quizzes'   => (new QuizModel())->getForStudent($sid, [
                'course_id' => $courseId,
                'search'    => trim((string) ($_GET['q'] ?? '')),
            ]),
            'courses'   => (new CourseModel())->getStudentEnrolledCourses($sid),
            'courseId'  => $courseId,
        ]);
    }

    public function startQuiz(): void
    {
        $sid = $this->studentId();
        $quizId = (int) ($_GET['quiz_id'] ?? $_POST['quiz_id'] ?? 0);

        $quizModel = new QuizModel();
        $quiz = $quizModel->findById($quizId);
        if (!$quiz || empty($quiz['is_published'])) {
            $this->abortNotFound('Quiz not found or not published.');
        }

        $this->verifyEnrollment((int) $quiz['course_id']);

        $now = time();
        $startTs = strtotime((string) $quiz['start_time']);
        $endTs   = strtotime((string) $quiz['end_time']);

        if ($startTs !== false && $now < $startTs) {
            Flash::set('warning', 'This quiz is not open yet. It opens on ' . format_datetime($quiz['start_time']) . '.');
            $this->redirect('student/quizzes');
        }
        if ($endTs !== false && $now > $endTs) {
            Flash::set('danger', 'The availability window for this quiz closed on ' . format_datetime($quiz['end_time']) . '.');
            $this->redirect('student/quizzes');
        }

        $attemptModel = new AttemptModel();
        $completedCount = $attemptModel->countStudentAttempts($quizId, $sid);
        if ($completedCount >= (int) $quiz['allowed_attempts']) {
            Flash::set('warning', "You have already used all {$quiz['allowed_attempts']} allowed attempt(s) for this quiz.");
            $this->redirect('student/quiz-results');
        }

        // Fetch questions WITHOUT correct answers (server security requirement)
        $questions = (new QuestionModel())->getByQuiz($quizId, false);
        if (empty($questions)) {
            Flash::set('warning', 'This quiz does not contain any questions yet.');
            $this->redirect('student/quizzes');
        }

        $attemptId = $attemptModel->startAttempt($quizId, $sid, (float) $quiz['total_marks']);
        $activeAttempt = $attemptModel->findActiveAttempt($quizId, $sid);

        $startedTs = strtotime((string) ($activeAttempt['started_at'] ?? 'now')) ?: time();
        $remainingSeconds = max(0, ((int) $quiz['duration_minutes'] * 60) - (time() - $startedTs));

        $this->render('student/quiz_take', [
            'pageTitle'        => 'Attempt Quiz: ' . $quiz['title'],
            'quiz'             => $quiz,
            'questions'        => $questions,
            'attemptId'        => $attemptId,
            'remainingSeconds' => $remainingSeconds,
        ]);
    }

    public function submitQuiz(): void
    {
        $this->requirePost();
        $sid = $this->studentId();
        $attemptId = (int) ($_POST['attempt_id'] ?? 0);
        $answers   = $_POST['answers'] ?? [];

        try {
            $outcome = QuizScoringService::submitAndScore($attemptId, $sid, is_array($answers) ? $answers : []);
            ActivityLogModel::record(
                'QUIZ_SUBMIT',
                sprintf('Completed quiz attempt #%d with score %.2f / %.2f (%.2f%%).', $attemptId, $outcome['score'], $outcome['total_marks'], $outcome['percentage']),
                'attempt',
                $attemptId
            );
            Flash::set('success', sprintf('Quiz submitted! Your score: %.2f / %.2f (%.2f%%).', $outcome['score'], $outcome['total_marks'], $outcome['percentage']));
        } catch (\Throwable $e) {
            Flash::set('danger', $e->getMessage());
            $this->redirect('student/quizzes');
        }

        $this->redirect('student/quiz-results', ['attempt_id' => $attemptId]);
    }

    public function quizResults(): void
    {
        $sid = $this->studentId();
        $attemptModel = new AttemptModel();
        $attempts = $attemptModel->getAll(['student_id' => $sid]);

        $selectedAttempt = null;
        if (!empty($_GET['attempt_id'])) {
            $detail = $attemptModel->findByIdWithDetails((int) $_GET['attempt_id']);
            if ($detail && (int) $detail['student_id'] === $sid) {
                $selectedAttempt = $detail;
            } else {
                $this->abortForbidden('You cannot view another student quiz attempt.');
            }
        }

        $this->render('student/quiz_results', [
            'pageTitle'       => 'My Quiz Attempts & Scores',
            'attempts'        => $attempts,
            'selectedAttempt' => $selectedAttempt,
        ]);
    }

    // ------------------------------------------------------------------------
    // ATTENDANCE, RESULTS & NOTICES
    // ------------------------------------------------------------------------
    public function attendance(): void
    {
        $sid = $this->studentId();
        $courseId = !empty($_GET['course_id']) ? (int) $_GET['course_id'] : null;
        if ($courseId !== null && $courseId > 0) {
            $this->verifyEnrollment($courseId);
        }

        $attModel = new AttendanceModel();
        $this->render('student/attendance', [
            'pageTitle'        => 'My Attendance Summary & History',
            'courseSummaries'  => $attModel->getStudentCourseSummary($sid),
            'history'          => $attModel->getStudentAttendanceHistory($sid, $courseId),
            'overallPercent'   => $attModel->calculateStudentOverallPercentage($sid),
            'selectedCourseId' => $courseId,
        ]);
    }

    public function results(): void
    {
        $sid = $this->studentId();
        $results = (new ResultModel())->getAll([
            'student_id'   => $sid,
            'is_published' => 1,
        ]);

        $publishedSubmissions = (new SubmissionModel())->getAll([
            'student_id' => $sid,
            'status'     => 'published',
        ]);

        $quizAttempts = (new AttemptModel())->getAll([
            'student_id' => $sid,
        ]);

        $this->render('student/results', [
            'pageTitle'            => 'My Academic Results & Transcript',
            'results'              => $results,
            'publishedSubmissions' => $publishedSubmissions,
            'quizAttempts'         => $quizAttempts,
        ]);
    }

    public function notices(): void
    {
        $sid = $this->studentId();
        $filters = [
            'priority' => trim((string) ($_GET['priority'] ?? '')),
            'search'   => trim((string) ($_GET['q'] ?? '')),
        ];

        $this->render('student/notices', [
            'pageTitle' => 'Notices & Announcements',
            'notices'   => (new NoticeModel())->getVisibleForStudent($sid, $filters),
            'filters'   => $filters,
        ]);
    }
}
