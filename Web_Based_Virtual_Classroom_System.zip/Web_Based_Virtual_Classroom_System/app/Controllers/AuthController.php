<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Flash;
use App\Core\Logger;
use App\Models\ActivityLogModel;
use App\Models\UserModel;

/**
 * Handles Login, Logout, Session Protection, and Brute-Force Rate Limiting.
 */
class AuthController extends Controller
{
    public function showLogin(): void
    {
        if (Auth::check()) {
            $this->redirect(Auth::dashboardRoute());
        }

        $this->render('auth/login', [
            'pageTitle' => 'Sign In — Web-Based Virtual Classroom System',
        ], 'layouts/auth');
    }

    public function login(): void
    {
        $this->requirePost();

        $identifier = trim((string) ($_POST['identifier'] ?? ''));
        $password   = (string) ($_POST['password'] ?? '');
        $ip         = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

        if ($identifier === '' || $password === '') {
            Flash::set('danger', 'Please enter both your email/enrolment number and password.');
            $this->redirect('login');
        }

        $appConfig = require dirname(__DIR__, 2) . '/config/app.php';
        $maxAttempts = (int) ($appConfig['max_login_attempts'] ?? 5);
        $lockoutMins = (int) ($appConfig['lockout_minutes'] ?? 15);

        $userModel = new UserModel();
        if ($userModel->isLockedOut($identifier, $ip, $maxAttempts, $lockoutMins)) {
            Logger::warning("Locked out login attempt for identifier={$identifier}");
            Flash::set('danger', "Too many failed login attempts. Please wait {$lockoutMins} minutes before trying again.");
            $this->redirect('login');
        }

        $user = $userModel->findByEmailOrEnrollment($identifier);

        // Generic error message so we never reveal whether an email/account exists
        $genericError = 'Invalid login credentials. Please check your email/enrolment number and password.';

        if (!$user || !password_verify($password, (string) $user['password_hash'])) {
            $userModel->recordFailedLogin($identifier, $ip);
            Logger::warning("Failed login attempt for identifier={$identifier}");
            Flash::set('danger', $genericError);
            $this->redirect('login');
        }

        if (($user['status'] ?? 'inactive') !== 'active') {
            Logger::warning("Inactive account login attempt for user_id={$user['user_id']}");
            Flash::set('danger', 'Your account is currently deactivated. Please contact the system administrator.');
            $this->redirect('login');
        }

        $userModel->clearFailedLogins($identifier, $ip);
        $userModel->touchLastLogin((int) $user['user_id']);
        Auth::loginUser($user);

        ActivityLogModel::record(
            'AUTH_LOGIN',
            "User {$user['name']} ({$user['role_name']}) signed in successfully.",
            'user',
            (int) $user['user_id'],
            (int) $user['user_id']
        );

        Flash::set('success', 'Welcome back, ' . $user['name'] . '!');
        $this->redirect(Auth::dashboardRoute());
    }

    public function logout(): void
    {
        if (Auth::check()) {
            $user = Auth::user();
            ActivityLogModel::record(
                'AUTH_LOGOUT',
                "User {$user['name']} signed out.",
                'user',
                (int) $user['user_id'],
                (int) $user['user_id']
            );
        }

        Auth::logoutUser();
        session_start();
        Flash::set('info', 'You have been securely signed out.');
        $this->redirect('login');
    }
}
