<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Flash;
use App\Helpers\CsvExporter;
use App\Helpers\FileUpload;
use App\Models\ActivityLogModel;
use App\Models\AssignmentModel;
use App\Models\AttemptModel;
use App\Models\AttendanceModel;
use App\Models\CourseModel;
use App\Models\EnrollmentModel;
use App\Models\MaterialModel;
use App\Models\NoticeModel;
use App\Models\QuestionModel;
use App\Models\QuizModel;
use App\Models\ResultModel;
use App\Models\SubmissionModel;
use App\Services\ResultCalculationService;
use App\Validators\Validator;

/**
 * Teacher Panel Controller.
 * Enforces strict course-ownership checks on every operation so a teacher
 * can only view or modify records belonging to their assigned courses.
 */
class TeacherController extends Controller
{
    private function teacherId(): int
    {
        return (int) Auth::id();
    }

    private function verifyCourseOwnership(int $courseId): array
    {
        $courseModel = new CourseModel();
        $course = $courseModel->findById($courseId);
        if (!$course) {
            $this->abortNotFound('Course record not found.');
        }
        if ((int) $course['teacher_id'] !== $this->teacherId()) {
            $this->abortForbidden('Access Denied: You can only access or modify courses assigned to your faculty account.');
        }
        return $course;
    }

    public function dashboard(): void
    {
        $tid = $this->teacherId();
        $courseModel     = new CourseModel();
        $enrollmentModel = new EnrollmentModel();
        $assignmentModel = new AssignmentModel();
        $submissionModel = new SubmissionModel();
        $quizModel       = new QuizModel();
        $noticeModel     = new NoticeModel();

        $myCourses       = $courseModel->getAll(['teacher_id' => $tid]);
        $myEnrollments   = $enrollmentModel->getAll(['teacher_id' => $tid, 'status' => 'active']);
        $myAssignments   = $assignmentModel->getAll(['teacher_id' => $tid]);
        $pendingSubs     = $submissionModel->getAll(['teacher_id' => $tid, 'status' => 'submitted']);
        $myQuizzes       = $quizModel->getAll(['teacher_id' => $tid]);
        $recentNotices   = array_slice($noticeModel->getVisibleForTeacher($tid), 0, 5);

        $stats = [
            'assigned_courses'    => count($myCourses),
            'enrolled_students'   => count($myEnrollments),
            'total_assignments'   => count($myAssignments),
            'pending_submissions' => count($pendingSubs),
            'created_quizzes'     => count($myQuizzes),
        ];

        $this->render('teacher/dashboard', [
            'pageTitle'      => 'Teacher Dashboard',
            'stats'          => $stats,
            'myCourses'      => $myCourses,
            'myAssignments'  => array_slice($myAssignments, 0, 5),
            'pendingSubs'    => array_slice($pendingSubs, 0, 5),
            'recentNotices'  => $recentNotices,
        ]);
    }

    public function courses(): void
    {
        $tid = $this->teacherId();
        $courseModel = new CourseModel();
        $selectedCourse = null;
        $enrolledStudents = [];

        if (!empty($_GET['course_id'])) {
            $selectedCourse = $this->verifyCourseOwnership((int) $_GET['course_id']);
            $enrolledStudents = (new EnrollmentModel())->getStudentsByCourse((int) $selectedCourse['course_id']);
        }

        $this->render('teacher/courses', [
            'pageTitle'        => 'My Assigned Courses',
            'courses'          => $courseModel->getAll(['teacher_id' => $tid, 'search' => trim((string) ($_GET['q'] ?? ''))]),
            'selectedCourse'   => $selectedCourse,
            'enrolledStudents' => $enrolledStudents,
        ]);
    }

    // ------------------------------------------------------------------------
    // LEARNING MATERIALS
    // ------------------------------------------------------------------------
    public function materials(): void
    {
        $tid = $this->teacherId();
        $filters = [
            'teacher_id' => $tid,
            'course_id'  => (int) ($_GET['course_id'] ?? 0),
            'category'   => trim((string) ($_GET['category'] ?? '')),
            'search'     => trim((string) ($_GET['q'] ?? '')),
        ];

        $materialModel = new MaterialModel();
        $editMaterial = null;
        if (!empty($_GET['edit'])) {
            $m = $materialModel->findById((int) $_GET['edit']);
            if ($m && (int) $m['teacher_id'] === $tid) {
                $editMaterial = $m;
            }
        }

        $this->render('teacher/materials', [
            'pageTitle'    => 'Course Learning Materials',
            'materials'    => $materialModel->getAll($filters),
            'courses'      => (new CourseModel())->getAll(['teacher_id' => $tid]),
            'filters'      => $filters,
            'editMaterial' => $editMaterial,
        ]);
    }

    public function storeMaterial(): void
    {
        $this->requirePost();
        $courseId = (int) ($_POST['course_id'] ?? 0);
        $this->verifyCourseOwnership($courseId);

        $validator = new Validator($_POST);
        $validator
            ->required('title', 'Material Title')
            ->inList('category', ['Lecture Notes', 'Syllabus', 'Reference Book', 'Lab Manual', 'Presentation', 'Worksheet'], 'Category');

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('teacher/materials');
        }

        try {
            $fileMeta = FileUpload::upload($_FILES['material_file'] ?? [], 'materials');
        } catch (\RuntimeException $e) {
            Flash::set('danger', $e->getMessage());
            $this->redirect('teacher/materials');
        }

        $materialId = (new MaterialModel())->create(array_merge($_POST, $fileMeta, [
            'uploaded_by' => $this->teacherId(),
        ]));

        ActivityLogModel::record('MATERIAL_UPLOAD', "Uploaded course material: {$_POST['title']}.", 'material', $materialId);
        Flash::set('success', 'Learning material uploaded and linked to course successfully.');
        $this->redirect('teacher/materials');
    }

    public function updateMaterial(): void
    {
        $this->requirePost();
        $materialId = (int) ($_POST['material_id'] ?? 0);
        $materialModel = new MaterialModel();
        $material = $materialModel->findById($materialId);
        if (!$material || (int) $material['teacher_id'] !== $this->teacherId()) {
            $this->abortForbidden('You cannot modify this learning material.');
        }

        $courseId = (int) ($_POST['course_id'] ?? 0);
        $this->verifyCourseOwnership($courseId);

        $materialModel->updateMetadata($materialId, $_POST);
        ActivityLogModel::record('MATERIAL_UPDATE', "Updated material metadata ID #{$materialId}: {$_POST['title']}.", 'material', $materialId);
        Flash::set('success', 'Material metadata updated.');
        $this->redirect('teacher/materials');
    }

    public function deleteMaterial(): void
    {
        $this->requirePost();
        $materialId = (int) ($_POST['material_id'] ?? 0);
        $materialModel = new MaterialModel();
        $material = $materialModel->findById($materialId);
        if (!$material || (int) $material['teacher_id'] !== $this->teacherId()) {
            $this->abortForbidden('You cannot delete this learning material.');
        }

        $materialModel->delete($materialId);
        ActivityLogModel::record('MATERIAL_DELETE', "Deleted material: {$material['title']}.", 'material', $materialId);
        Flash::set('info', 'Learning material deleted.');
        $this->redirect('teacher/materials');
    }

    // ------------------------------------------------------------------------
    // ASSIGNMENTS & SUBMISSIONS EVALUATION
    // ------------------------------------------------------------------------
    public function assignments(): void
    {
        $tid = $this->teacherId();
        $filters = [
            'teacher_id' => $tid,
            'course_id'  => (int) ($_GET['course_id'] ?? 0),
            'status'     => trim((string) ($_GET['status'] ?? '')),
            'search'     => trim((string) ($_GET['q'] ?? '')),
        ];

        $assignmentModel = new AssignmentModel();
        $editAssignment = null;
        if (!empty($_GET['edit'])) {
            $a = $assignmentModel->findById((int) $_GET['edit']);
            if ($a && (int) $a['teacher_id'] === $tid) {
                $editAssignment = $a;
            }
        }

        $this->render('teacher/assignments', [
            'pageTitle'      => 'Assignment Management',
            'assignments'    => $assignmentModel->getAll($filters),
            'courses'        => (new CourseModel())->getAll(['teacher_id' => $tid]),
            'filters'        => $filters,
            'editAssignment' => $editAssignment,
        ]);
    }

    public function storeAssignment(): void
    {
        $this->requirePost();
        $courseId = (int) ($_POST['course_id'] ?? 0);
        $this->verifyCourseOwnership($courseId);

        $validator = new Validator($_POST);
        $validator
            ->required('title', 'Assignment Title')
            ->required('description', 'Instructions')
            ->numericRange('max_marks', 1, 1000, 'Maximum Marks')
            ->required('issue_date', 'Issue Date')
            ->required('due_date', 'Due Date')
            ->dateAfterOrEqual('issue_date', 'due_date', 'Issue Date', 'Due Date')
            ->inList('status', ['draft', 'published', 'open', 'due', 'closed'], 'Status');

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('teacher/assignments');
        }

        $attachmentPath = null;
        $attachmentName = null;
        if (!empty($_FILES['attachment']['name'])) {
            try {
                $uploaded = FileUpload::upload($_FILES['attachment'], 'assignments');
                $attachmentPath = $uploaded['file_path'];
                $attachmentName = $uploaded['original_name'];
            } catch (\RuntimeException $e) {
                Flash::set('danger', $e->getMessage());
                $this->redirect('teacher/assignments');
            }
        }

        $assignmentId = (new AssignmentModel())->create([
            'course_id'       => $courseId,
            'created_by'      => $this->teacherId(),
            'title'           => $_POST['title'],
            'description'     => $_POST['description'],
            'max_marks'       => (float) $_POST['max_marks'],
            'issue_date'      => $_POST['issue_date'],
            'due_date'        => $_POST['due_date'],
            'allow_late'      => isset($_POST['allow_late']) ? 1 : 0,
            'attachment_path' => $attachmentPath,
            'attachment_name' => $attachmentName,
            'status'          => $_POST['status'] ?? 'open',
        ]);

        ActivityLogModel::record('ASSIGNMENT_CREATE', "Created assignment: {$_POST['title']}.", 'assignment', $assignmentId);
        Flash::set('success', 'Assignment created successfully.');
        $this->redirect('teacher/assignments');
    }

    public function updateAssignment(): void
    {
        $this->requirePost();
        $assignmentId = (int) ($_POST['assignment_id'] ?? 0);
        $assignmentModel = new AssignmentModel();
        $existing = $assignmentModel->findById($assignmentId);

        if (!$existing || (int) $existing['teacher_id'] !== $this->teacherId()) {
            $this->abortForbidden('You cannot edit this assignment.');
        }

        $courseId = (int) ($_POST['course_id'] ?? 0);
        $this->verifyCourseOwnership($courseId);

        $validator = new Validator($_POST);
        $validator
            ->required('title', 'Assignment Title')
            ->required('description', 'Instructions')
            ->numericRange('max_marks', 1, 1000, 'Maximum Marks')
            ->dateAfterOrEqual('issue_date', 'due_date', 'Issue Date', 'Due Date');

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('teacher/assignments', ['edit' => $assignmentId]);
        }

        $_POST['allow_late'] = isset($_POST['allow_late']) ? 1 : 0;
        $assignmentModel->update($assignmentId, $_POST);

        ActivityLogModel::record('ASSIGNMENT_UPDATE', "Updated assignment ID #{$assignmentId}: {$_POST['title']}.", 'assignment', $assignmentId);
        Flash::set('success', 'Assignment updated.');
        $this->redirect('teacher/assignments');
    }

    public function deleteAssignment(): void
    {
        $this->requirePost();
        $assignmentId = (int) ($_POST['assignment_id'] ?? 0);
        $assignmentModel = new AssignmentModel();
        $existing = $assignmentModel->findById($assignmentId);

        if (!$existing || (int) $existing['teacher_id'] !== $this->teacherId()) {
            $this->abortForbidden('You cannot delete this assignment.');
        }

        // Protect evaluated academic records from accidental loss
        $subs = (new SubmissionModel())->getAll(['assignment_id' => $assignmentId]);
        if (!empty($subs)) {
            Flash::set('warning', 'Cannot delete this assignment because student submissions are already recorded against it. You may close it instead.');
            $this->redirect('teacher/assignments');
        }

        $assignmentModel->delete($assignmentId);
        ActivityLogModel::record('ASSIGNMENT_DELETE', "Deleted assignment: {$existing['title']}.", 'assignment', $assignmentId);
        Flash::set('info', 'Assignment deleted.');
        $this->redirect('teacher/assignments');
    }

    public function submissions(): void
    {
        $tid = $this->teacherId();
        $filters = [
            'teacher_id'    => $tid,
            'course_id'     => (int) ($_GET['course_id'] ?? 0),
            'assignment_id' => (int) ($_GET['assignment_id'] ?? 0),
            'status'        => trim((string) ($_GET['status'] ?? '')),
            'search'        => trim((string) ($_GET['q'] ?? '')),
        ];

        $this->render('teacher/submissions', [
            'pageTitle'   => 'Student Submissions & Evaluation',
            'submissions' => (new SubmissionModel())->getAll($filters),
            'courses'     => (new CourseModel())->getAll(['teacher_id' => $tid]),
            'assignments' => (new AssignmentModel())->getAll(['teacher_id' => $tid]),
            'filters'     => $filters,
        ]);
    }

    public function evaluateSubmission(): void
    {
        $this->requirePost();
        $submissionId = (int) ($_POST['submission_id'] ?? 0);
        $submissionModel = new SubmissionModel();
        $submission = $submissionModel->findById($submissionId);

        if (!$submission || (int) $submission['teacher_id'] !== $this->teacherId()) {
            $this->abortForbidden('You are not authorized to evaluate this submission.');
        }

        $maxMarks = (float) $submission['max_marks'];
        $validator = new Validator($_POST);
        $validator->numericRange('marks', 0.0, $maxMarks, "Marks (Max {$maxMarks})");

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('teacher/submissions');
        }

        $marks = round((float) $_POST['marks'], 2);
        $feedback = trim((string) ($_POST['feedback'] ?? ''));
        $publish = ($_POST['eval_action'] ?? 'publish') === 'publish';

        $submissionModel->evaluate($submissionId, $marks, $feedback, $this->teacherId(), $publish);

        // Recalculate consolidated student result
        ResultCalculationService::recalculateForStudentCourse((int) $submission['student_id'], (int) $submission['course_id']);

        ActivityLogModel::record(
            'SUBMISSION_EVALUATE',
            sprintf('Evaluated submission #%d for %s (%s/%s marks, %s).', $submissionId, $submission['student_name'], $marks, $maxMarks, $publish ? 'published' : 'saved'),
            'submission',
            $submissionId
        );

        Flash::set('success', sprintf('Evaluation saved (%s / %s marks) for %s.', $marks, $maxMarks, $submission['student_name']));
        $this->redirect('teacher/submissions');
    }

    // ------------------------------------------------------------------------
    // QUIZ MANAGEMENT & QUESTION BANK
    // ------------------------------------------------------------------------
    public function quizzes(): void
    {
        $tid = $this->teacherId();
        $filters = [
            'teacher_id' => $tid,
            'course_id'  => (int) ($_GET['course_id'] ?? 0),
            'search'     => trim((string) ($_GET['q'] ?? '')),
        ];

        $quizModel = new QuizModel();
        $editQuiz = null;
        if (!empty($_GET['edit'])) {
            $q = $quizModel->findById((int) $_GET['edit']);
            if ($q && (int) $q['teacher_id'] === $tid) {
                $editQuiz = $q;
            }
        }

        $selectedQuizAttempts = [];
        $selectedQuiz = null;
        if (!empty($_GET['attempts_quiz_id'])) {
            $qz = $quizModel->findById((int) $_GET['attempts_quiz_id']);
            if ($qz && (int) $qz['teacher_id'] === $tid) {
                $selectedQuiz = $qz;
                $selectedQuizAttempts = (new AttemptModel())->getAll(['quiz_id' => (int) $qz['quiz_id']]);
            }
        }

        $this->render('teacher/quizzes', [
            'pageTitle'            => 'Online Quiz Management',
            'quizzes'              => $quizModel->getAll($filters),
            'courses'              => (new CourseModel())->getAll(['teacher_id' => $tid]),
            'filters'              => $filters,
            'editQuiz'             => $editQuiz,
            'selectedQuiz'         => $selectedQuiz,
            'selectedQuizAttempts' => $selectedQuizAttempts,
        ]);
    }

    public function storeQuiz(): void
    {
        $this->requirePost();
        $courseId = (int) ($_POST['course_id'] ?? 0);
        $this->verifyCourseOwnership($courseId);

        $validator = new Validator($_POST);
        $validator
            ->required('title', 'Quiz Title')
            ->numericRange('duration_minutes', 1, 300, 'Duration (minutes)')
            ->numericRange('allowed_attempts', 1, 10, 'Allowed Attempts')
            ->required('start_time', 'Start Date/Time')
            ->required('end_time', 'End Date/Time')
            ->dateAfterOrEqual('start_time', 'end_time', 'Start Time', 'End Time');

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('teacher/quizzes');
        }

        $quizId = (new QuizModel())->create([
            'course_id'         => $courseId,
            'created_by'        => $this->teacherId(),
            'title'             => $_POST['title'],
            'description'       => $_POST['description'] ?? '',
            'total_marks'       => 0,
            'duration_minutes'  => (int) $_POST['duration_minutes'],
            'start_time'        => date('Y-m-d H:i:s', strtotime((string) $_POST['start_time'])),
            'end_time'          => date('Y-m-d H:i:s', strtotime((string) $_POST['end_time'])),
            'allowed_attempts'  => (int) $_POST['allowed_attempts'],
            'is_published'      => isset($_POST['is_published']) ? 1 : 0,
            'results_published' => isset($_POST['results_published']) ? 1 : 0,
        ]);

        ActivityLogModel::record('QUIZ_CREATE', "Created quiz: {$_POST['title']}.", 'quiz', $quizId);
        Flash::set('success', 'Quiz created. You can now add multiple-choice questions to it.');
        $this->redirect('teacher/questions', ['quiz_id' => $quizId, 'course_id' => $courseId]);
    }

    public function updateQuiz(): void
    {
        $this->requirePost();
        $quizId = (int) ($_POST['quiz_id'] ?? 0);
        $quizModel = new QuizModel();
        $quiz = $quizModel->findById($quizId);
        if (!$quiz || (int) $quiz['teacher_id'] !== $this->teacherId()) {
            $this->abortForbidden('You cannot edit this quiz.');
        }

        $courseId = (int) ($_POST['course_id'] ?? 0);
        $this->verifyCourseOwnership($courseId);

        $quizModel->update($quizId, [
            'course_id'         => $courseId,
            'title'             => $_POST['title'],
            'description'       => $_POST['description'] ?? '',
            'duration_minutes'  => (int) $_POST['duration_minutes'],
            'start_time'        => date('Y-m-d H:i:s', strtotime((string) $_POST['start_time'])),
            'end_time'          => date('Y-m-d H:i:s', strtotime((string) $_POST['end_time'])),
            'allowed_attempts'  => (int) $_POST['allowed_attempts'],
            'is_published'      => isset($_POST['is_published']) ? 1 : 0,
            'results_published' => isset($_POST['results_published']) ? 1 : 0,
        ]);

        Flash::set('success', 'Quiz configuration updated.');
        $this->redirect('teacher/quizzes');
    }

    public function deleteQuiz(): void
    {
        $this->requirePost();
        $quizId = (int) ($_POST['quiz_id'] ?? 0);
        $quizModel = new QuizModel();
        $quiz = $quizModel->findById($quizId);
        if (!$quiz || (int) $quiz['teacher_id'] !== $this->teacherId()) {
            $this->abortForbidden('You cannot delete this quiz.');
        }

        $quizModel->delete($quizId);
        ActivityLogModel::record('QUIZ_DELETE', "Deleted quiz: {$quiz['title']}.", 'quiz', $quizId);
        Flash::set('info', 'Quiz deleted.');
        $this->redirect('teacher/quizzes');
    }

    public function questions(): void
    {
        $tid = $this->teacherId();
        $filters = [
            'teacher_id' => $tid,
            'course_id'  => (int) ($_GET['course_id'] ?? 0),
            'quiz_id'    => (int) ($_GET['quiz_id'] ?? 0),
            'search'     => trim((string) ($_GET['q'] ?? '')),
        ];

        $this->render('teacher/questions', [
            'pageTitle' => 'Question Bank & Quiz Questions',
            'questions' => (new QuestionModel())->getQuestionBank($filters),
            'courses'   => (new CourseModel())->getAll(['teacher_id' => $tid]),
            'quizzes'   => (new QuizModel())->getAll(['teacher_id' => $tid]),
            'filters'   => $filters,
        ]);
    }

    public function storeQuestion(): void
    {
        $this->requirePost();
        $courseId = (int) ($_POST['course_id'] ?? 0);
        $quizId   = !empty($_POST['quiz_id']) ? (int) $_POST['quiz_id'] : null;

        $this->verifyCourseOwnership($courseId);
        if ($quizId !== null) {
            $quiz = (new QuizModel())->findById($quizId);
            if (!$quiz || (int) $quiz['course_id'] !== $courseId) {
                Flash::set('danger', 'Selected quiz does not belong to the chosen course.');
                $this->redirect('teacher/questions');
            }
        }

        $validator = new Validator($_POST);
        $validator
            ->required('question_text', 'Question Text')
            ->required('option_a', 'Option A')
            ->required('option_b', 'Option B')
            ->required('option_c', 'Option C')
            ->required('option_d', 'Option D')
            ->inList('correct_option', ['A', 'B', 'C', 'D'], 'Correct Option')
            ->numericRange('marks', 0.5, 100.0, 'Question Marks');

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('teacher/questions', ['quiz_id' => $quizId, 'course_id' => $courseId]);
        }

        $qId = (new QuestionModel())->createWithOptions([
            'quiz_id'        => $quizId,
            'course_id'      => $courseId,
            'created_by'     => $this->teacherId(),
            'topic'          => $_POST['topic'] ?? 'General',
            'question_text'  => $_POST['question_text'],
            'marks'          => (float) $_POST['marks'],
            'correct_option' => $_POST['correct_option'],
            'explanation'    => $_POST['explanation'] ?? '',
            'sort_order'     => (int) ($_POST['sort_order'] ?? 1),
        ], [
            'A' => $_POST['option_a'],
            'B' => $_POST['option_b'],
            'C' => $_POST['option_c'],
            'D' => $_POST['option_d'],
        ]);

        ActivityLogModel::record('QUESTION_CREATE', "Added MCQ question #{$qId} to course ID #{$courseId}.", 'question', $qId);
        Flash::set('success', 'Multiple-choice question added and total quiz marks synchronized.');
        $this->redirect('teacher/questions', ['quiz_id' => $quizId, 'course_id' => $courseId]);
    }

    public function deleteQuestion(): void
    {
        $this->requirePost();
        $questionId = (int) ($_POST['question_id'] ?? 0);
        $questionModel = new QuestionModel();
        $q = $questionModel->findById($questionId);

        if (!$q || (int) $q['teacher_id'] !== $this->teacherId()) {
            $this->abortForbidden('You cannot delete this question.');
        }

        $questionModel->delete($questionId);
        Flash::set('info', 'Question removed from bank.');
        $this->redirect('teacher/questions');
    }

    // ------------------------------------------------------------------------
    // ATTENDANCE MANAGEMENT
    // ------------------------------------------------------------------------
    public function attendance(): void
    {
        $tid = $this->teacherId();
        $courses = (new CourseModel())->getAll(['teacher_id' => $tid]);
        $selectedCourseId = (int) ($_GET['course_id'] ?? ($courses[0]['course_id'] ?? 0));
        $classDate = trim((string) ($_GET['class_date'] ?? date('Y-m-d')));

        $enrolledStudents = [];
        $existingRecords  = [];
        $courseSummary    = [];

        if ($selectedCourseId > 0) {
            $this->verifyCourseOwnership($selectedCourseId);
            $enrolledStudents = (new EnrollmentModel())->getStudentsByCourse($selectedCourseId);
            $attModel = new AttendanceModel();
            $existingRecords = $attModel->getRecordsForCourseAndDate($selectedCourseId, $classDate);
            $courseSummary   = $attModel->getCourseAttendanceSummary($selectedCourseId);
        }

        $this->render('teacher/attendance', [
            'pageTitle'        => 'Course Attendance Management',
            'courses'          => $courses,
            'selectedCourseId' => $selectedCourseId,
            'classDate'        => $classDate,
            'enrolledStudents' => $enrolledStudents,
            'existingRecords'  => $existingRecords,
            'courseSummary'    => $courseSummary,
        ]);
    }

    public function storeAttendance(): void
    {
        $this->requirePost();
        $courseId  = (int) ($_POST['course_id'] ?? 0);
        $classDate = trim((string) ($_POST['class_date'] ?? ''));

        $this->verifyCourseOwnership($courseId);

        if ($classDate === '' || strtotime($classDate) === false) {
            Flash::set('danger', 'Please provide a valid class date.');
            $this->redirect('teacher/attendance', ['course_id' => $courseId]);
        }

        $statuses = $_POST['status'] ?? [];
        $remarks  = $_POST['remarks'] ?? [];

        if (empty($statuses) || !is_array($statuses)) {
            Flash::set('warning', 'No student attendance statuses were submitted.');
            $this->redirect('teacher/attendance', ['course_id' => $courseId, 'class_date' => $classDate]);
        }

        $attModel = new AttendanceModel();
        $attModel->saveBatchAttendance($courseId, $classDate, $statuses, is_array($remarks) ? $remarks : [], $this->teacherId());

        // Recalculate attendance % in consolidated results for each student
        foreach (array_keys($statuses) as $sid) {
            ResultCalculationService::recalculateForStudentCourse((int) $sid, $courseId);
        }

        ActivityLogModel::record('ATTENDANCE_RECORD', "Recorded attendance for course ID #{$courseId} on {$classDate}.", 'attendance', $courseId);
        Flash::set('success', "Attendance for {$classDate} saved and student summaries updated.");
        $this->redirect('teacher/attendance', ['course_id' => $courseId, 'class_date' => $classDate]);
    }

    // ------------------------------------------------------------------------
    // STUDENT RESULTS, NOTICES & REPORTS
    // ------------------------------------------------------------------------
    public function results(): void
    {
        $tid = $this->teacherId();
        $courseId = (int) ($_GET['course_id'] ?? 0);
        if ($courseId > 0) {
            $this->verifyCourseOwnership($courseId);
        }

        $filters = [
            'teacher_id' => $tid,
            'course_id'  => $courseId,
            'search'     => trim((string) ($_GET['q'] ?? '')),
        ];

        $this->render('teacher/results', [
            'pageTitle' => 'Student Academic Performance & Results',
            'results'   => (new ResultModel())->getAll($filters),
            'courses'   => (new CourseModel())->getAll(['teacher_id' => $tid]),
            'filters'   => $filters,
        ]);
    }

    public function notices(): void
    {
        $tid = $this->teacherId();
        $this->render('teacher/notices', [
            'pageTitle' => 'Course Notices & Announcements',
            'notices'   => (new NoticeModel())->getVisibleForTeacher($tid, ['search' => trim((string) ($_GET['q'] ?? ''))]),
            'courses'   => (new CourseModel())->getAll(['teacher_id' => $tid]),
        ]);
    }

    public function storeNotice(): void
    {
        $this->requirePost();
        $courseId = (int) ($_POST['course_id'] ?? 0);
        $this->verifyCourseOwnership($courseId);

        $validator = new Validator($_POST);
        $validator
            ->required('title', 'Notice Title')
            ->required('description', 'Announcement Message')
            ->inList('priority', ['normal', 'important', 'urgent'], 'Priority');

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('teacher/notices');
        }

        $noticeId = (new NoticeModel())->create([
            'title'       => $_POST['title'],
            'description' => $_POST['description'],
            'author_id'   => $this->teacherId(),
            'audience'    => 'course',
            'course_id'   => $courseId,
            'priority'    => $_POST['priority'] ?? 'normal',
            'status'      => 'published',
        ]);

        ActivityLogModel::record('COURSE_NOTICE_CREATE', "Published course notice: {$_POST['title']}.", 'notice', $noticeId);
        Flash::set('success', 'Course announcement published.');
        $this->redirect('teacher/notices');
    }

    public function reports(): void
    {
        $tid = $this->teacherId();
        $courseId = (int) ($_GET['course_id'] ?? 0);
        if ($courseId > 0) {
            $this->verifyCourseOwnership($courseId);
        }

        $results = (new ResultModel())->getAll([
            'teacher_id' => $tid,
            'course_id'  => $courseId,
        ]);

        if (!empty($_GET['export']) && $_GET['export'] === 'csv') {
            $headers = ['Course Code', 'Course Title', 'Enrolment No.', 'Student Name', 'Assignments', 'Quizzes', 'Attendance %', 'Overall %', 'Grade', 'Remarks'];
            $rows = [];
            foreach ($results as $r) {
                $rows[] = [
                    $r['course_code'],
                    $r['course_name'],
                    $r['enrollment_no'] ?: '—',
                    $r['student_name'],
                    $r['assignment_marks_obtained'] . ' / ' . $r['assignment_marks_max'],
                    $r['quiz_marks_obtained'] . ' / ' . $r['quiz_marks_max'],
                    $r['attendance_percentage'] . '%',
                    $r['overall_percentage'] . '%',
                    $r['grade'],
                    $r['remarks'] ?: '—',
                ];
            }
            CsvExporter::download('Teacher_Course_Performance_Report_' . date('Ymd') . '.csv', $headers, $rows);
        }

        $this->render('teacher/reports', [
            'pageTitle' => 'Course Performance Reports',
            'results'   => $results,
            'courses'   => (new CourseModel())->getAll(['teacher_id' => $tid]),
            'courseId'  => $courseId,
        ]);
    }
}
