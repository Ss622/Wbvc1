<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Flash;
use App\Models\ActivityLogModel;
use App\Models\UserModel;
use App\Validators\Validator;

/**
 * Handles Personal Profile Viewing, Editing, and Secure Password Changes for all roles.
 */
class ProfileController extends Controller
{
    public function index(): void
    {
        $userModel = new UserModel();
        $profile = $userModel->findById((int) Auth::id());
        if (!$profile) {
            $this->abortNotFound('User profile record not found.');
        }

        $this->render('profile/index', [
            'pageTitle' => 'My Profile & Account Security',
            'profile'   => $profile,
        ]);
    }

    public function update(): void
    {
        $this->requirePost();
        $userId = (int) Auth::id();

        $validator = new Validator($_POST);
        $validator
            ->required('name', 'Full Name')
            ->minLength('name', 3, 'Full Name')
            ->maxLength('name', 120, 'Full Name');

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('profile');
        }

        $userModel = new UserModel();
        $userModel->updateProfile($userId, [
            'name'          => $_POST['name'],
            'phone'         => $_POST['phone'] ?? '',
            'department'    => $_POST['department'] ?? '',
            'qualification' => $_POST['qualification'] ?? '',
        ]);

        $_SESSION['user_name']  = trim((string) $_POST['name']);
        $_SESSION['department'] = trim((string) ($_POST['department'] ?? ''));

        ActivityLogModel::record('PROFILE_UPDATE', 'Updated personal profile details.', 'user', $userId);
        Flash::set('success', 'Your profile information has been updated.');
        $this->redirect('profile');
    }

    public function changePassword(): void
    {
        $this->requirePost();
        $userId = (int) Auth::id();

        $currentPassword = (string) ($_POST['current_password'] ?? '');
        $newPassword     = (string) ($_POST['new_password'] ?? '');
        $confirmPassword = (string) ($_POST['confirm_password'] ?? '');

        if ($currentPassword === '' || $newPassword === '' || $confirmPassword === '') {
            Flash::set('danger', 'All password fields are required.');
            $this->redirect('profile');
        }

        if (strlen($newPassword) < 8) {
            Flash::set('danger', 'New password must be at least 8 characters long.');
            $this->redirect('profile');
        }

        if ($newPassword !== $confirmPassword) {
            Flash::set('danger', 'New password and confirmation password do not match.');
            $this->redirect('profile');
        }

        $userModel = new UserModel();
        $user = $userModel->findById($userId);
        if (!$user || !password_verify($currentPassword, (string) $user['password_hash'])) {
            Flash::set('danger', 'Your current password is incorrect.');
            $this->redirect('profile');
        }

        $userModel->updatePassword($userId, $newPassword);
        ActivityLogModel::record('PASSWORD_CHANGE', 'Changed account password.', 'user', $userId);

        Flash::set('success', 'Your password has been changed securely.');
        $this->redirect('profile');
    }
}
