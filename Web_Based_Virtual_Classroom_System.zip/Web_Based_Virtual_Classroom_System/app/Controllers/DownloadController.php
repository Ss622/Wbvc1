<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Models\AssignmentModel;
use App\Models\EnrollmentModel;
use App\Models\MaterialModel;
use App\Models\SubmissionModel;

/**
 * Protected File Streaming Controller.
 * Prevents direct unauthorized access or path traversal and enforces strict RBAC
 * before serving learning materials, assignment instructions, or student submissions.
 */
class DownloadController extends Controller
{
    public function material(): void
    {
        $materialId = (int) ($_GET['id'] ?? 0);
        if ($materialId <= 0) {
            $this->abortNotFound('Invalid material reference.');
        }

        $materialModel = new MaterialModel();
        $material = $materialModel->findById($materialId);
        if (!$material) {
            $this->abortNotFound('Learning material not found.');
        }

        $userId = (int) Auth::id();
        $courseId = (int) $material['course_id'];

        if (Auth::isTeacher()) {
            if ((int) $material['teacher_id'] !== $userId && (int) $material['uploaded_by'] !== $userId) {
                $this->abortForbidden('Teachers can only download materials belonging to their assigned courses.');
            }
        } elseif (Auth::isStudent()) {
            $enrollmentModel = new EnrollmentModel();
            if (!$enrollmentModel->isEnrolled($userId, $courseId)) {
                $this->abortForbidden('You must be enrolled in this course to download its learning materials.');
            }
        }

        $materialModel->incrementDownloadCount($materialId);
        $this->streamProtectedFile((string) $material['file_path'], (string) $material['original_name'], (string) $material['mime_type']);
    }

    public function assignmentAttachment(): void
    {
        $assignmentId = (int) ($_GET['id'] ?? 0);
        $assignment = (new AssignmentModel())->findById($assignmentId);
        if (!$assignment || empty($assignment['attachment_path'])) {
            $this->abortNotFound('Assignment reference document not found.');
        }

        $userId = (int) Auth::id();
        $courseId = (int) $assignment['course_id'];

        if (Auth::isTeacher() && (int) $assignment['teacher_id'] !== $userId) {
            $this->abortForbidden('You are not authorized to access attachments for this course.');
        }
        if (Auth::isStudent() && !(new EnrollmentModel())->isEnrolled($userId, $courseId)) {
            $this->abortForbidden('You must be enrolled in this course to download assignment files.');
        }

        $this->streamProtectedFile(
            (string) $assignment['attachment_path'],
            (string) ($assignment['attachment_name'] ?: basename((string) $assignment['attachment_path'])),
            'application/octet-stream'
        );
    }

    public function submissionAttachment(): void
    {
        $submissionId = (int) ($_GET['id'] ?? 0);
        $submission = (new SubmissionModel())->findById($submissionId);
        if (!$submission || empty($submission['file_path'])) {
            $this->abortNotFound('Submission attachment not found.');
        }

        $userId = (int) Auth::id();
        if (Auth::isStudent() && (int) $submission['student_id'] !== $userId) {
            $this->abortForbidden('Students are strictly prohibited from downloading another student submission.');
        }
        if (Auth::isTeacher() && (int) $submission['teacher_id'] !== $userId) {
            $this->abortForbidden('Teachers can only access submissions for their assigned courses.');
        }

        $this->streamProtectedFile(
            (string) $submission['file_path'],
            (string) ($submission['original_name'] ?: basename((string) $submission['file_path'])),
            'application/octet-stream'
        );
    }

    private function streamProtectedFile(string $relativeStoragePath, string $downloadName, string $mimeType): never
    {
        $storageRoot = realpath(dirname(__DIR__, 2) . '/storage/uploads');
        if ($storageRoot === false) {
            $this->abortNotFound('Protected storage directory is missing.');
        }

        $cleanRelative = ltrim(str_replace(['..', '\\'], ['', '/'], $relativeStoragePath), '/');
        $fullPath = realpath($storageRoot . DIRECTORY_SEPARATOR . $cleanRelative);

        // Enforce path traversal check: fullPath must reside inside storageRoot
        if ($fullPath === false || !str_starts_with($fullPath, $storageRoot) || !is_file($fullPath)) {
            $this->abortNotFound('The requested file does not exist on the server.');
        }

        $safeDownloadName = preg_replace('/[^a-zA-Z0-9._\- ]/', '_', $downloadName) ?: 'download.txt';

        header('Content-Description: File Transfer');
        header('Content-Type: ' . ($mimeType ?: 'application/octet-stream'));
        header('Content-Disposition: attachment; filename="' . $safeDownloadName . '"');
        header('Content-Length: ' . (string) filesize($fullPath));
        header('Cache-Control: private, must-revalidate');
        header('Pragma: public');

        readfile($fullPath);
        exit;
    }
}
