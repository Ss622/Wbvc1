<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Flash;
use App\Helpers\CsvExporter;
use App\Models\ActivityLogModel;
use App\Models\AssignmentModel;
use App\Models\CourseModel;
use App\Models\EnrollmentModel;
use App\Models\NoticeModel;
use App\Models\QuizModel;
use App\Models\ResultModel;
use App\Models\RoleModel;
use App\Models\SettingModel;
use App\Models\UserModel;
use App\Services\ResultCalculationService;
use App\Validators\Validator;

/**
 * Administrator Panel Controller.
 * Provides complete CRUD and management for Users, Students, Teachers, Courses,
 * Enrollments, Notices, Reports (with CSV/Print), Activity Logs, and Settings.
 */
class AdminController extends Controller
{
    public function dashboard(): void
    {
        $userModel       = new UserModel();
        $courseModel     = new CourseModel();
        $enrollmentModel = new EnrollmentModel();
        $assignmentModel = new AssignmentModel();
        $quizModel       = new QuizModel();
        $noticeModel     = new NoticeModel();
        $logModel        = new ActivityLogModel();

        $stats = [
            'total_students'    => $userModel->countByRoleSlug('STUDENT'),
            'total_teachers'    => $userModel->countByRoleSlug('TEACHER'),
            'total_admins'      => $userModel->countByRoleSlug('ADMIN'),
            'total_courses'     => $courseModel->countAll(),
            'published_courses' => $courseModel->countPublished(),
            'total_enrollments' => $enrollmentModel->countAllActive(),
            'total_assignments' => $assignmentModel->countAll(),
            'total_quizzes'     => $quizModel->countAll(),
        ];

        $recentNotices = array_slice($noticeModel->getAll(['status' => 'published']), 0, 5);
        $recentLogs    = $logModel->getRecent(8);
        $courses       = $courseModel->getAll();

        $this->render('admin/dashboard', [
            'pageTitle'     => 'Administrator Dashboard',
            'stats'         => $stats,
            'recentNotices' => $recentNotices,
            'recentLogs'    => $recentLogs,
            'courses'       => $courses,
        ]);
    }

    public function users(): void
    {
        $filters = [
            'role_slug' => trim((string) ($_GET['role'] ?? '')),
            'status'    => trim((string) ($_GET['status'] ?? '')),
            'search'    => trim((string) ($_GET['q'] ?? '')),
        ];

        $userModel = new UserModel();
        $roleModel = new RoleModel();

        $editUser = null;
        if (!empty($_GET['edit'])) {
            $editUser = $userModel->findById((int) $_GET['edit']);
        }

        $this->render('admin/users', [
            'pageTitle' => 'User Management',
            'users'     => $userModel->getAll($filters),
            'roles'     => $roleModel->getAll(),
            'filters'   => $filters,
            'editUser'  => $editUser,
        ]);
    }

    public function students(): void
    {
        $_GET['role'] = 'STUDENT';
        $filters = [
            'role_slug' => 'STUDENT',
            'status'    => trim((string) ($_GET['status'] ?? '')),
            'search'    => trim((string) ($_GET['q'] ?? '')),
        ];

        $userModel = new UserModel();
        $roleModel = new RoleModel();

        $this->render('admin/users', [
            'pageTitle'   => 'Student Management',
            'users'       => $userModel->getAll($filters),
            'roles'       => $roleModel->getAll(),
            'filters'     => $filters,
            'editUser'    => null,
            'lockedRole'  => 'STUDENT',
        ]);
    }

    public function teachers(): void
    {
        $_GET['role'] = 'TEACHER';
        $filters = [
            'role_slug' => 'TEACHER',
            'status'    => trim((string) ($_GET['status'] ?? '')),
            'search'    => trim((string) ($_GET['q'] ?? '')),
        ];

        $userModel = new UserModel();
        $roleModel = new RoleModel();

        $this->render('admin/users', [
            'pageTitle'   => 'Teacher Management',
            'users'       => $userModel->getAll($filters),
            'roles'       => $roleModel->getAll(),
            'filters'     => $filters,
            'editUser'    => null,
            'lockedRole'  => 'TEACHER',
        ]);
    }

    public function storeUser(): void
    {
        $this->requirePost();

        $validator = new Validator($_POST);
        $validator
            ->required('name', 'Full Name')
            ->required('email', 'Email Address')
            ->email('email', 'Email Address')
            ->required('password', 'Password')
            ->minLength('password', 8, 'Password')
            ->numericRange('role_id', 1, 3, 'Role')
            ->inList('status', ['active', 'inactive'], 'Account Status');

        $userModel = new UserModel();
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $enrollmentNo = trim((string) ($_POST['enrollment_no'] ?? ''));

        if ($userModel->emailExists($email)) {
            $validator->addError('email', 'A user account with this email address already exists.');
        }
        if ($enrollmentNo !== '' && $userModel->enrollmentNoExists($enrollmentNo)) {
            $validator->addError('enrollment_no', 'This Enrolment / Staff ID is already assigned to another user.');
        }

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('admin/users');
        }

        $newId = $userModel->create($_POST);
        ActivityLogModel::record('USER_CREATE', "Created user account: {$_POST['name']} ({$email})", 'user', $newId);
        Flash::set('success', "User account for {$_POST['name']} created successfully.");
        $this->redirect('admin/users');
    }

    public function updateUser(): void
    {
        $this->requirePost();
        $userId = (int) ($_POST['user_id'] ?? 0);
        $userModel = new UserModel();
        $existing = $userModel->findById($userId);

        if (!$existing) {
            $this->abortNotFound('User account not found.');
        }

        $validator = new Validator($_POST);
        $validator
            ->required('name', 'Full Name')
            ->required('email', 'Email Address')
            ->email('email', 'Email Address')
            ->numericRange('role_id', 1, 3, 'Role')
            ->inList('status', ['active', 'inactive'], 'Account Status');

        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $enrollmentNo = trim((string) ($_POST['enrollment_no'] ?? ''));

        if ($userModel->emailExists($email, $userId)) {
            $validator->addError('email', 'Another user is already using this email address.');
        }
        if ($enrollmentNo !== '' && $userModel->enrollmentNoExists($enrollmentNo, $userId)) {
            $validator->addError('enrollment_no', 'Another user is already using this Enrolment / Staff ID.');
        }

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('admin/users', ['edit' => $userId]);
        }

        $userModel->update($userId, $_POST);

        // Optional administrative password reset
        $newPass = trim((string) ($_POST['new_password'] ?? ''));
        if ($newPass !== '') {
            if (strlen($newPass) < 8) {
                Flash::set('warning', 'User details updated, but password reset was skipped because password was shorter than 8 characters.');
                $this->redirect('admin/users');
            }
            $userModel->updatePassword($userId, $newPass);
        }

        ActivityLogModel::record('USER_UPDATE', "Updated user account ID #{$userId} ({$_POST['name']}).", 'user', $userId);
        Flash::set('success', "User account {$_POST['name']} updated successfully.");
        $this->redirect('admin/users');
    }

    public function toggleUserStatus(): void
    {
        $this->requirePost();
        $userId = (int) ($_POST['user_id'] ?? 0);
        if ($userId === (int) Auth::id()) {
            Flash::set('warning', 'You cannot deactivate your own active administrator session.');
            $this->redirect('admin/users');
        }

        $userModel = new UserModel();
        $user = $userModel->findById($userId);
        if (!$user) {
            $this->abortNotFound('User account not found.');
        }

        $userModel->toggleStatus($userId);
        ActivityLogModel::record('USER_STATUS_TOGGLE', "Toggled account status for {$user['name']} (ID #{$userId}).", 'user', $userId);
        Flash::set('success', "Updated account status for {$user['name']}.");
        $this->redirect('admin/users');
    }

    public function deleteUser(): void
    {
        $this->requirePost();
        $userId = (int) ($_POST['user_id'] ?? 0);
        if ($userId === (int) Auth::id()) {
            Flash::set('danger', 'You cannot delete your own administrator account.');
            $this->redirect('admin/users');
        }

        $userModel = new UserModel();
        $user = $userModel->findById($userId);
        if (!$user) {
            $this->abortNotFound('User not found.');
        }

        $userModel->delete($userId);
        ActivityLogModel::record('USER_DELETE', "Deleted user account: {$user['name']} ({$user['email']}).", 'user', $userId);
        Flash::set('success', "User account {$user['name']} has been removed.");
        $this->redirect('admin/users');
    }

    // ------------------------------------------------------------------------
    // COURSE MANAGEMENT
    // ------------------------------------------------------------------------
    public function courses(): void
    {
        $filters = [
            'status'     => trim((string) ($_GET['status'] ?? '')),
            'teacher_id' => (int) ($_GET['teacher_id'] ?? 0),
            'search'     => trim((string) ($_GET['q'] ?? '')),
        ];

        $courseModel = new CourseModel();
        $userModel   = new UserModel();

        $editCourse = null;
        if (!empty($_GET['edit'])) {
            $editCourse = $courseModel->findById((int) $_GET['edit']);
        }

        $this->render('admin/courses', [
            'pageTitle'  => 'Course Management',
            'courses'    => $courseModel->getAll($filters),
            'teachers'   => $userModel->getActiveTeachers(),
            'filters'    => $filters,
            'editCourse' => $editCourse,
        ]);
    }

    public function storeCourse(): void
    {
        $this->requirePost();

        $validator = new Validator($_POST);
        $validator
            ->required('course_code', 'Course Code')
            ->required('course_name', 'Course Title')
            ->required('description', 'Course Description')
            ->numericRange('credits', 1, 12, 'Credits')
            ->inList('status', ['draft', 'published', 'archived'], 'Course Status');

        $courseModel = new CourseModel();
        $code = strtoupper(trim((string) ($_POST['course_code'] ?? '')));
        if ($courseModel->codeExists($code)) {
            $validator->addError('course_code', "Course code {$code} already exists.");
        }

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('admin/courses');
        }

        $_POST['created_by'] = Auth::id();
        $courseId = $courseModel->create($_POST);

        ActivityLogModel::record('COURSE_CREATE', "Created course {$code}: {$_POST['course_name']}.", 'course', $courseId);
        Flash::set('success', "Course {$code} ({$_POST['course_name']}) created successfully.");
        $this->redirect('admin/courses');
    }

    public function updateCourse(): void
    {
        $this->requirePost();
        $courseId = (int) ($_POST['course_id'] ?? 0);
        $courseModel = new CourseModel();
        $existing = $courseModel->findById($courseId);
        if (!$existing) {
            $this->abortNotFound('Course not found.');
        }

        $validator = new Validator($_POST);
        $validator
            ->required('course_code', 'Course Code')
            ->required('course_name', 'Course Title')
            ->required('description', 'Course Description')
            ->numericRange('credits', 1, 12, 'Credits')
            ->inList('status', ['draft', 'published', 'archived'], 'Course Status');

        $code = strtoupper(trim((string) ($_POST['course_code'] ?? '')));
        if ($courseModel->codeExists($code, $courseId)) {
            $validator->addError('course_code', "Course code {$code} is already used by another course.");
        }

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('admin/courses', ['edit' => $courseId]);
        }

        $courseModel->update($courseId, $_POST);
        ActivityLogModel::record('COURSE_UPDATE', "Updated course {$code}: {$_POST['course_name']}.", 'course', $courseId);
        Flash::set('success', "Course {$code} updated successfully.");
        $this->redirect('admin/courses');
    }

    public function deleteCourse(): void
    {
        $this->requirePost();
        $courseId = (int) ($_POST['course_id'] ?? 0);
        $courseModel = new CourseModel();
        $course = $courseModel->findById($courseId);
        if (!$course) {
            $this->abortNotFound('Course not found.');
        }

        $courseModel->delete($courseId);
        ActivityLogModel::record('COURSE_DELETE', "Deleted course {$course['course_code']}.", 'course', $courseId);
        Flash::set('success', "Course {$course['course_code']} has been deleted.");
        $this->redirect('admin/courses');
    }

    // ------------------------------------------------------------------------
    // ENROLLMENT MANAGEMENT
    // ------------------------------------------------------------------------
    public function enrollments(): void
    {
        $filters = [
            'course_id'  => (int) ($_GET['course_id'] ?? 0),
            'student_id' => (int) ($_GET['student_id'] ?? 0),
            'search'     => trim((string) ($_GET['q'] ?? '')),
        ];

        $enrollmentModel = new EnrollmentModel();
        $courseModel     = new CourseModel();
        $userModel       = new UserModel();

        $this->render('admin/enrollments', [
            'pageTitle'   => 'Enrollment Management',
            'enrollments' => $enrollmentModel->getAll($filters),
            'courses'     => $courseModel->getAll(),
            'students'    => $userModel->getActiveStudents(),
            'filters'     => $filters,
        ]);
    }

    public function storeEnrollment(): void
    {
        $this->requirePost();
        $studentId = (int) ($_POST['student_id'] ?? 0);
        $courseId  = (int) ($_POST['course_id'] ?? 0);

        if ($studentId <= 0 || $courseId <= 0) {
            Flash::set('danger', 'Please select both a valid student and a course.');
            $this->redirect('admin/enrollments');
        }

        $userModel   = new UserModel();
        $courseModel = new CourseModel();
        $student     = $userModel->findById($studentId);
        $course      = $courseModel->findById($courseId);

        if (!$student || $student['role_slug'] !== 'STUDENT') {
            Flash::set('danger', 'Selected user is not a valid student account.');
            $this->redirect('admin/enrollments');
        }
        if (!$course) {
            Flash::set('danger', 'Selected course does not exist.');
            $this->redirect('admin/enrollments');
        }

        $enrollmentModel = new EnrollmentModel();
        if ($enrollmentModel->isEnrolled($studentId, $courseId)) {
            Flash::set('warning', "{$student['name']} is already enrolled in {$course['course_code']}. Duplicate enrollments are prevented.");
            $this->redirect('admin/enrollments');
        }

        $enrollmentId = $enrollmentModel->enroll($studentId, $courseId, (int) Auth::id());
        ResultCalculationService::recalculateForStudentCourse($studentId, $courseId);

        ActivityLogModel::record(
            'ENROLLMENT_CREATE',
            "Enrolled student {$student['name']} ({$student['enrollment_no']}) into {$course['course_code']}.",
            'enrollment',
            $enrollmentId
        );

        Flash::set('success', "{$student['name']} has been enrolled in {$course['course_code']} — {$course['course_name']}.");
        $this->redirect('admin/enrollments');
    }

    public function removeEnrollment(): void
    {
        $this->requirePost();
        $enrollmentId = (int) ($_POST['enrollment_id'] ?? 0);
        $enrollmentModel = new EnrollmentModel();
        $enrollmentModel->remove($enrollmentId);

        ActivityLogModel::record('ENROLLMENT_REMOVE', "Removed enrollment record ID #{$enrollmentId}.", 'enrollment', $enrollmentId);
        Flash::set('info', 'Student enrollment record removed.');
        $this->redirect('admin/enrollments');
    }

    // ------------------------------------------------------------------------
    // NOTICE MANAGEMENT
    // ------------------------------------------------------------------------
    public function notices(): void
    {
        $filters = [
            'audience' => trim((string) ($_GET['audience'] ?? '')),
            'priority' => trim((string) ($_GET['priority'] ?? '')),
            'search'   => trim((string) ($_GET['q'] ?? '')),
        ];

        $noticeModel = new NoticeModel();
        $courseModel = new CourseModel();

        $editNotice = null;
        if (!empty($_GET['edit'])) {
            $editNotice = $noticeModel->findById((int) $_GET['edit']);
        }

        $this->render('admin/notices', [
            'pageTitle'  => 'Notices & Announcements',
            'notices'    => $noticeModel->getAll($filters),
            'courses'    => $courseModel->getAll(),
            'filters'    => $filters,
            'editNotice' => $editNotice,
        ]);
    }

    public function storeNotice(): void
    {
        $this->requirePost();

        $validator = new Validator($_POST);
        $validator
            ->required('title', 'Notice Title')
            ->required('description', 'Notice Content')
            ->inList('audience', ['all', 'students', 'teachers', 'course'], 'Target Audience')
            ->inList('priority', ['normal', 'important', 'urgent'], 'Priority')
            ->inList('status', ['draft', 'published'], 'Publication Status');

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('admin/notices');
        }

        $_POST['author_id'] = Auth::id();
        $noticeId = (new NoticeModel())->create($_POST);

        ActivityLogModel::record('NOTICE_CREATE', "Published notice: {$_POST['title']}.", 'notice', $noticeId);
        Flash::set('success', 'Announcement saved successfully.');
        $this->redirect('admin/notices');
    }

    public function updateNotice(): void
    {
        $this->requirePost();
        $noticeId = (int) ($_POST['notice_id'] ?? 0);
        $noticeModel = new NoticeModel();
        if (!$noticeModel->findById($noticeId)) {
            $this->abortNotFound('Notice not found.');
        }

        $validator = new Validator($_POST);
        $validator
            ->required('title', 'Notice Title')
            ->required('description', 'Notice Content');

        if ($validator->fails()) {
            Flash::set('danger', $validator->firstError());
            $this->redirect('admin/notices', ['edit' => $noticeId]);
        }

        $noticeModel->update($noticeId, $_POST);
        ActivityLogModel::record('NOTICE_UPDATE', "Updated notice ID #{$noticeId}: {$_POST['title']}.", 'notice', $noticeId);
        Flash::set('success', 'Announcement updated successfully.');
        $this->redirect('admin/notices');
    }

    public function deleteNotice(): void
    {
        $this->requirePost();
        $noticeId = (int) ($_POST['notice_id'] ?? 0);
        (new NoticeModel())->delete($noticeId);

        ActivityLogModel::record('NOTICE_DELETE', "Deleted notice ID #{$noticeId}.", 'notice', $noticeId);
        Flash::set('info', 'Announcement deleted.');
        $this->redirect('admin/notices');
    }

    // ------------------------------------------------------------------------
    // INSTITUTIONAL REPORTS & CSV EXPORT
    // ------------------------------------------------------------------------
    public function reports(): void
    {
        $reportType = trim((string) ($_GET['type'] ?? 'performance'));
        $courseId   = (int) ($_GET['course_id'] ?? 0);
        $exportCsv  = !empty($_GET['export']) && $_GET['export'] === 'csv';

        $courseModel     = new CourseModel();
        $userModel       = new UserModel();
        $enrollmentModel = new EnrollmentModel();
        $assignmentModel = new AssignmentModel();
        $AttemptModel    = new \App\Models\AttemptModel();
        $resultModel     = new ResultModel();
        $db              = Database::getConnection();

        $headers = [];
        $rows    = [];
        $title   = '';

        switch ($reportType) {
            case 'students':
                $title = 'Student Directory & Enrollment Summary Report';
                $headers = ['Enrolment No.', 'Student Name', 'Email', 'Phone', 'Department / Study Centre', 'Status', 'Last Login'];
                foreach ($userModel->getAll(['role_slug' => 'STUDENT']) as $s) {
                    $rows[] = [
                        $s['enrollment_no'] ?: '—',
                        $s['name'],
                        $s['email'],
                        $s['phone'] ?: '—',
                        $s['department'] ?: '—',
                        strtoupper($s['status']),
                        $s['last_login_at'] ?: 'Never',
                    ];
                }
                break;

            case 'teachers':
                $title = 'Faculty / Teacher Assignment Report';
                $headers = ['Staff ID', 'Teacher Name', 'Email', 'Qualification', 'Department', 'Status'];
                foreach ($userModel->getAll(['role_slug' => 'TEACHER']) as $t) {
                    $rows[] = [
                        $t['enrollment_no'] ?: '—',
                        $t['name'],
                        $t['email'],
                        $t['qualification'] ?: '—',
                        $t['department'] ?: '—',
                        strtoupper($t['status']),
                    ];
                }
                break;

            case 'courses':
                $title = 'Course Catalogue & Resource Summary Report';
                $headers = ['Course Code', 'Course Title', 'Semester', 'Credits', 'Assigned Teacher', 'Enrolled Students', 'Materials', 'Assignments', 'Quizzes', 'Status'];
                foreach ($courseModel->getAll() as $c) {
                    $rows[] = [
                        $c['course_code'],
                        $c['course_name'],
                        $c['semester'],
                        $c['credits'],
                        $c['teacher_name'] ?: 'Unassigned',
                        $c['enrolled_count'],
                        $c['material_count'],
                        $c['assignment_count'],
                        $c['quiz_count'],
                        strtoupper($c['status']),
                    ];
                }
                break;

            case 'enrollments':
                $title = 'Course Enrollment Registry Report';
                $headers = ['Course Code', 'Course Title', 'Enrolment No.', 'Student Name', 'Student Email', 'Status', 'Enrolled On'];
                foreach ($enrollmentModel->getAll($courseId ? ['course_id' => $courseId] : []) as $e) {
                    $rows[] = [
                        $e['course_code'],
                        $e['course_name'],
                        $e['enrollment_no'] ?: '—',
                        $e['student_name'],
                        $e['student_email'],
                        strtoupper($e['enrollment_status']),
                        $e['enrolled_at'],
                    ];
                }
                break;

            case 'attendance':
                $title = 'Course-Wise Attendance Summary Report';
                $headers = ['Course Code', 'Enrolment No.', 'Student Name', 'Total Classes', 'Present', 'Absent', 'Attendance %'];
                $sql = "SELECT c.course_code, u.enrollment_no, u.name AS student_name,
                               COUNT(a.attendance_id) AS total_classes,
                               SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_classes,
                               SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_classes
                        FROM enrollments e
                        INNER JOIN courses c ON e.course_id = c.course_id
                        INNER JOIN users u ON e.student_id = u.user_id
                        LEFT JOIN attendance a ON a.course_id = e.course_id AND a.student_id = e.student_id
                        WHERE e.enrollment_status = 'active'";
                $params = [];
                if ($courseId > 0) {
                    $sql .= ' AND e.course_id = :cid';
                    $params['cid'] = $courseId;
                }
                $sql .= ' GROUP BY c.course_code, u.enrollment_no, u.name ORDER BY c.course_code ASC, u.name ASC';
                $stmt = $db->prepare($sql);
                $stmt->execute($params);
                foreach ($stmt->fetchAll() as $r) {
                    $tot = (int) $r['total_classes'];
                    $pres = (int) $r['present_classes'];
                    $pct = $tot > 0 ? round(($pres / $tot) * 100, 2) : 0.00;
                    $rows[] = [
                        $r['course_code'],
                        $r['enrollment_no'] ?: '—',
                        $r['student_name'],
                        $tot,
                        $pres,
                        (int) $r['absent_classes'],
                        $pct . '%',
                    ];
                }
                break;

            case 'assignments':
                $title = 'Assignment & Submission Evaluation Report';
                $headers = ['Course Code', 'Assignment Title', 'Issue Date', 'Due Date', 'Max Marks', 'Submissions', 'Enrolled Students', 'Status'];
                foreach ($assignmentModel->getAll($courseId ? ['course_id' => $courseId] : []) as $a) {
                    $rows[] = [
                        $a['course_code'],
                        $a['title'],
                        $a['issue_date'],
                        $a['due_date'],
                        $a['max_marks'],
                        $a['submission_count'],
                        $a['enrolled_count'],
                        strtoupper($a['status']),
                    ];
                }
                break;

            case 'quizzes':
                $title = 'Online Quiz Attempt & Score Report';
                $headers = ['Course Code', 'Quiz Title', 'Enrolment No.', 'Student Name', 'Attempt #', 'Score', 'Total Marks', 'Percentage', 'Submitted At'];
                foreach ($AttemptModel->getAll($courseId ? ['course_id' => $courseId] : []) as $atp) {
                    $rows[] = [
                        $atp['course_code'],
                        $atp['quiz_title'],
                        $atp['enrollment_no'] ?: '—',
                        $atp['student_name'],
                        $atp['attempt_number'],
                        $atp['score'],
                        $atp['total_marks'],
                        $atp['percentage'] . '%',
                        $atp['submitted_at'],
                    ];
                }
                break;

            case 'performance':
            default:
                $reportType = 'performance';
                $title = 'Consolidated Academic Performance & Result Report';
                $headers = ['Course Code', 'Course Title', 'Enrolment No.', 'Student Name', 'Assignment Marks', 'Quiz Marks', 'Attendance %', 'Overall %', 'Grade', 'Remarks'];
                foreach ($resultModel->getAll($courseId ? ['course_id' => $courseId] : []) as $res) {
                    $rows[] = [
                        $res['course_code'],
                        $res['course_name'],
                        $res['enrollment_no'] ?: '—',
                        $res['student_name'],
                        $res['assignment_marks_obtained'] . ' / ' . $res['assignment_marks_max'],
                        $res['quiz_marks_obtained'] . ' / ' . $res['quiz_marks_max'],
                        $res['attendance_percentage'] . '%',
                        $res['overall_percentage'] . '%',
                        $res['grade'],
                        $res['remarks'] ?: '—',
                    ];
                }
                break;
        }

        if ($exportCsv) {
            CsvExporter::download("BCSP064_{$reportType}_report_" . date('Ymd') . '.csv', $headers, $rows);
        }

        $this->render('admin/reports', [
            'pageTitle'   => 'Institutional Academic Reports',
            'reportType'  => $reportType,
            'reportTitle' => $title,
            'headers'     => $headers,
            'rows'        => $rows,
            'courses'     => $courseModel->getAll(),
            'courseId'    => $courseId,
        ]);
    }

    public function activityLogs(): void
    {
        $search = trim((string) ($_GET['q'] ?? ''));
        $logs = (new ActivityLogModel())->getRecent(100, $search);

        $this->render('admin/activity_logs', [
            'pageTitle' => 'System Audit & Activity Logs',
            'logs'      => $logs,
            'search'    => $search,
        ]);
    }

    public function settings(): void
    {
        $settingModel = new SettingModel();
        $this->render('admin/settings', [
            'pageTitle' => 'Institutional & Grading Settings',
            'settings'  => $settingModel->getAllKeyed(),
        ]);
    }

    public function updateSettings(): void
    {
        $this->requirePost();
        $allowedKeys = [
            'institution_name',
            'academic_session',
            'project_code',
            'min_attendance_percent',
            'pass_percentage',
            'grading_scale_info',
        ];
        $payload = [];
        foreach ($allowedKeys as $key) {
            if (isset($_POST[$key])) {
                $payload[$key] = $_POST[$key];
            }
        }

        (new SettingModel())->updateSettings($payload);
        ActivityLogModel::record('SETTINGS_UPDATE', 'Updated institutional portal settings.', 'settings', 1);
        Flash::set('success', 'System settings updated successfully.');
        $this->redirect('admin/settings');
    }
}
