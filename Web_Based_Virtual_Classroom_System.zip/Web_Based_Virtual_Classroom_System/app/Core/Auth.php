<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Authentication & Role Helper Facade.
 */
class Auth
{
    public static function check(): bool
    {
        return !empty($_SESSION['user_id']) && !empty($_SESSION['role_slug']);
    }

    public static function id(): ?int
    {
        return isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null;
    }

    public static function role(): ?string
    {
        return $_SESSION['role_slug'] ?? null;
    }

    public static function user(): array
    {
        return [
            'user_id'       => $_SESSION['user_id'] ?? null,
            'name'          => $_SESSION['user_name'] ?? 'Guest',
            'email'         => $_SESSION['user_email'] ?? '',
            'role_id'       => $_SESSION['role_id'] ?? null,
            'role_slug'     => $_SESSION['role_slug'] ?? null,
            'role_name'     => $_SESSION['role_name'] ?? '',
            'enrollment_no' => $_SESSION['enrollment_no'] ?? '',
            'department'    => $_SESSION['department'] ?? '',
        ];
    }

    public static function loginUser(array $user): void
    {
        Session::regenerate();
        $_SESSION['user_id']       = (int) $user['user_id'];
        $_SESSION['user_name']     = (string) $user['name'];
        $_SESSION['user_email']    = (string) $user['email'];
        $_SESSION['role_id']       = (int) $user['role_id'];
        $_SESSION['role_slug']     = (string) $user['role_slug'];
        $_SESSION['role_name']     = (string) $user['role_name'];
        $_SESSION['enrollment_no'] = (string) ($user['enrollment_no'] ?? '');
        $_SESSION['department']    = (string) ($user['department'] ?? '');
        $_SESSION['last_activity'] = time();
    }

    public static function logoutUser(): void
    {
        Session::destroy();
    }

    public static function isAdmin(): bool
    {
        return self::role() === 'ADMIN';
    }

    public static function isTeacher(): bool
    {
        return self::role() === 'TEACHER';
    }

    public static function isStudent(): bool
    {
        return self::role() === 'STUDENT';
    }

    public static function dashboardRoute(): string
    {
        return match (self::role()) {
            'ADMIN'   => 'admin/dashboard',
            'TEACHER' => 'teacher/dashboard',
            'STUDENT' => 'student/dashboard',
            default   => 'login',
        };
    }
}
