<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Secure Session Manager with inactivity timeout and session fixation protection.
 */
class Session
{
    public static function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        $appConfig = require dirname(__DIR__, 2) . '/config/app.php';
        $cookieName = $appConfig['session_cookie'] ?? 'vc_session_id';
        $lifetime = (int) ($appConfig['session_lifetime'] ?? 1800);
        $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

        session_name($cookieName);
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $isSecure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);

        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.cookie_httponly', '1');

        session_start();

        // Check inactivity timeout for authenticated sessions
        if (isset($_SESSION['user_id'], $_SESSION['last_activity'])) {
            $elapsed = time() - (int) $_SESSION['last_activity'];
            if ($elapsed > $lifetime) {
                self::destroy();
                session_start();
                Flash::set('warning', 'Your session expired due to inactivity. Please sign in again.');
                return;
            }
        }

        $_SESSION['last_activity'] = time();
    }

    public static function regenerate(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
            $_SESSION['last_activity'] = time();
        }
    }

    public static function set(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    public static function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    public static function remove(string $key): void
    {
        unset($_SESSION[$key]);
    }

    public static function destroy(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                (bool) $params['secure'],
                (bool) $params['httponly']
            );
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
    }
}
