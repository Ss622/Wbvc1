<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/**
 * Template View Renderer with layout wrapping and output buffering.
 */
class View
{
    public static function render(string $template, array $data = [], ?string $layout = 'layouts/app'): void
    {
        $viewsRoot = dirname(__DIR__) . '/Views/';
        $templateFile = $viewsRoot . ltrim($template, '/') . '.php';

        if (!is_file($templateFile)) {
            throw new RuntimeException("View template not found: {$template}");
        }

        extract($data, EXTR_SKIP);

        ob_start();
        require $templateFile;
        $content = ob_get_clean();

        if ($layout === null) {
            echo $content;
            return;
        }

        $layoutFile = $viewsRoot . ltrim($layout, '/') . '.php';
        if (!is_file($layoutFile)) {
            throw new RuntimeException("Layout template not found: {$layout}");
        }

        require $layoutFile;
    }
}
