<?php
declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOException;
use RuntimeException;

/**
 * Singleton PDO Database Connection Manager.
 * Uses prepared statements, strict error modes, and disabled emulated prepares.
 */
class Database
{
    private static ?PDO $instance = null;

    private function __construct()
    {
    }

    public static function getConnection(): PDO
    {
        if (self::$instance !== null) {
            return self::$instance;
        }

        $config = require dirname(__DIR__, 2) . '/config/database.php';
        $driver = strtolower($config['driver'] ?? 'mysql');

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            if ($driver === 'sqlite') {
                $dsn = 'sqlite:' . $config['sqlite_path'];
                self::$instance = new PDO($dsn, null, null, $options);
                self::$instance->exec('PRAGMA foreign_keys = ON;');
            } else {
                $dsn = sprintf(
                    'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                    $config['host'],
                    $config['port'],
                    $config['database'],
                    $config['charset']
                );
                self::$instance = new PDO($dsn, $config['username'], $config['password'], $options);
            }
        } catch (PDOException $e) {
            Logger::error('Database connection failed: ' . $e->getMessage());
            throw new RuntimeException(
                'Unable to connect to the academic database. Please verify that MySQL is running in XAMPP and database/schema.sql has been imported.'
            );
        }

        return self::$instance;
    }

    /**
     * Allows injecting a custom PDO connection during automated testing.
     */
    public static function setConnection(PDO $pdo): void
    {
        self::$instance = $pdo;
    }
}
