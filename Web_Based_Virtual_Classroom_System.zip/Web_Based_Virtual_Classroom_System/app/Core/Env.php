<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Lightweight .env parser and environment variable accessor.
 */
class Env
{
    private static array $variables = [];
    private static bool $loaded = false;

    public static function load(string $filePath): void
    {
        if (self::$loaded) {
            return;
        }
        self::$loaded = true;

        if (!is_file($filePath) || !is_readable($filePath)) {
            return;
        }

        $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) {
            return;
        }

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }
            if (!str_contains($line, '=')) {
                continue;
            }
            [$name, $value] = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);

            if (
                (str_starts_with($value, '"') && str_ends_with($value, '"')) ||
                (str_starts_with($value, "'") && str_ends_with($value, "'"))
            ) {
                $value = substr($value, 1, -1);
            }

            self::$variables[$name] = $value;
            if (getenv($name) === false) {
                putenv("{$name}={$value}");
                $_ENV[$name] = $value;
            }
        }
    }

    public static function get(string $key, string $default = ''): string
    {
        if (isset(self::$variables[$key])) {
            return self::$variables[$key];
        }
        if (isset($_ENV[$key])) {
            return (string) $_ENV[$key];
        }
        $val = getenv($key);
        return $val !== false ? (string) $val : $default;
    }
}
