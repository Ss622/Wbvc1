<?php
declare(strict_types=1);

namespace App\Core;

use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;
use App\Middleware\CsrfMiddleware;

/**
 * Front-Controller Route Dispatcher supporting both query-string (?r=...)
 * and clean PATH_INFO / mod_rewrite routing for zero-config XAMPP compatibility.
 */
class Router
{
    private array $routes = [];

    public function add(string $method, string $path, array $handler, array $roles = []): void
    {
        $normPath = trim($path, '/');
        if ($normPath === '') {
            $normPath = '/';
        }
        $this->routes[strtoupper($method)][$normPath] = [
            'handler' => $handler,
            'roles'   => $roles,
        ];
    }

    public function get(string $path, array $handler, array $roles = []): void
    {
        $this->add('GET', $path, $handler, $roles);
    }

    public function post(string $path, array $handler, array $roles = []): void
    {
        $this->add('POST', $path, $handler, $roles);
    }

    public static function currentRoute(): string
    {
        if (!empty($_GET['r'])) {
            $r = trim((string) $_GET['r'], '/');
            return $r === '' ? '/' : $r;
        }

        $uriPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
        $scriptDir = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');

        if ($scriptName !== '' && str_starts_with($uriPath, $scriptName)) {
            $uriPath = substr($uriPath, strlen($scriptName));
        } elseif ($scriptDir !== '' && $scriptDir !== '/' && str_starts_with($uriPath, $scriptDir)) {
            $uriPath = substr($uriPath, strlen($scriptDir));
        }

        $route = trim($uriPath, '/');
        if ($route === '' || $route === 'index.php') {
            return '/';
        }
        return $route;
    }

    public function dispatch(): void
    {
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $route = self::currentRoute();

        if ($route === '/') {
            if (Auth::check()) {
                header('Location: ' . route_url(Auth::dashboardRoute()));
                exit;
            }
            $route = 'login';
        }

        if (!isset($this->routes[$method][$route])) {
            http_response_code(404);
            $layout = Auth::check() ? 'layouts/app' : 'layouts/auth';
            View::render('errors/404', [
                'pageTitle' => '404 — Page Not Found',
                'message'   => "The requested route '{$route}' does not exist in this portal.",
            ], $layout);
            return;
        }

        $routeConfig = $this->routes[$method][$route];
        $roles = $routeConfig['roles'];

        // Verify CSRF on all POST requests
        if ($method === 'POST') {
            CsrfMiddleware::handle();
        }

        // Enforce authentication & role authorization if route requires roles
        if (!empty($roles)) {
            AuthMiddleware::handle();
            RoleMiddleware::handle($roles);
        }

        [$controllerClass, $action] = $routeConfig['handler'];
        $controller = new $controllerClass();
        $controller->{$action}();
    }
}
