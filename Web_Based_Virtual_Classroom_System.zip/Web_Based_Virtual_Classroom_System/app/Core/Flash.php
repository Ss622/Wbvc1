<?php
declare(strict_types=1);

namespace App\Core;

/**
 * One-time Session Flash Notification Manager.
 */
class Flash
{
    public static function set(string $type, string $message): void
    {
        $_SESSION['_flash'][] = [
            'type'    => $type,
            'message' => $message,
        ];
    }

    public static function getAll(): array
    {
        $messages = $_SESSION['_flash'] ?? [];
        unset($_SESSION['_flash']);
        return $messages;
    }

    public static function has(): bool
    {
        return !empty($_SESSION['_flash']);
    }
}
