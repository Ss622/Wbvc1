<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Safe Application File Logger (never logs plaintext passwords or secrets).
 */
class Logger
{
    public static function log(string $level, string $message): void
    {
        $logDir = dirname(__DIR__, 2) . '/storage/logs';
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }
        $logFile = $logDir . '/application.log';
        $timestamp = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'CLI';
        $line = sprintf("[%s] [%s] [IP:%s] %s%s", $timestamp, strtoupper($level), $ip, $message, PHP_EOL);
        @file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
    }

    public static function info(string $message): void
    {
        self::log('INFO', $message);
    }

    public static function warning(string $message): void
    {
        self::log('WARNING', $message);
    }

    public static function error(string $message): void
    {
        self::log('ERROR', $message);
    }
}
