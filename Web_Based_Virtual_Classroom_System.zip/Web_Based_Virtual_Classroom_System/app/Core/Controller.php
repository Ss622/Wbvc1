<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Base Controller providing view rendering, redirects, and flash helpers.
 */
abstract class Controller
{
    protected function render(string $template, array $data = [], ?string $layout = 'layouts/app'): void
    {
        View::render($template, $data, $layout);
    }

    protected function redirect(string $route, array $query = []): never
    {
        $url = route_url($route, $query);
        header('Location: ' . $url);
        exit;
    }

    protected function requirePost(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            http_response_code(405);
            View::render('errors/403', [
                'pageTitle' => 'Method Not Allowed',
                'message'   => 'This operation requires a valid form submission (HTTP POST).',
            ], 'layouts/auth');
            exit;
        }
    }

    protected function abortForbidden(string $message = 'You are not authorized to access this academic resource or operation.'): never
    {
        http_response_code(403);
        $layout = Auth::check() ? 'layouts/app' : 'layouts/auth';
        View::render('errors/403', [
            'pageTitle' => '403 — Access Denied',
            'message'   => $message,
        ], $layout);
        exit;
    }

    protected function abortNotFound(string $message = 'The requested record or page could not be found.'): never
    {
        http_response_code(404);
        $layout = Auth::check() ? 'layouts/app' : 'layouts/auth';
        View::render('errors/404', [
            'pageTitle' => '404 — Not Found',
            'message'   => $message,
        ], $layout);
        exit;
    }
}
