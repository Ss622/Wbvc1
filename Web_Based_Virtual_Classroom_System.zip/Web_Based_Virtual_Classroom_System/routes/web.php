<?php
declare(strict_types=1);

use App\Controllers\AdminController;
use App\Controllers\AuthController;
use App\Controllers\DownloadController;
use App\Controllers\ProfileController;
use App\Controllers\StudentController;
use App\Controllers\TeacherController;
use App\Core\Router;

/**
 * Registers all application routes and their server-side Role-Based Access Control (RBAC) guards.
 */
return static function (Router $router): void {
    // Public / Authentication Routes
    $router->get('login', [AuthController::class, 'showLogin']);
    $router->post('login', [AuthController::class, 'login']);
    $router->post('logout', [AuthController::class, 'logout']);
    $router->get('logout', [AuthController::class, 'logout']);

    // Shared Authenticated Profile Routes (All 3 Roles)
    $allRoles = ['ADMIN', 'TEACHER', 'STUDENT'];
    $router->get('profile', [ProfileController::class, 'index'], $allRoles);
    $router->post('profile/update', [ProfileController::class, 'update'], $allRoles);
    $router->post('profile/password', [ProfileController::class, 'changePassword'], $allRoles);

    // Protected File Download Routes (Controller enforces fine-grained course/student ownership)
    $router->get('download/material', [DownloadController::class, 'material'], $allRoles);
    $router->get('download/assignment', [DownloadController::class, 'assignmentAttachment'], $allRoles);
    $router->get('download/submission', [DownloadController::class, 'submissionAttachment'], $allRoles);

    // ------------------------------------------------------------------------
    // 1. ADMINISTRATOR PANEL ROUTES (Strictly ADMIN Role)
    // ------------------------------------------------------------------------
    $adminRole = ['ADMIN'];
    $router->get('admin/dashboard', [AdminController::class, 'dashboard'], $adminRole);
    $router->get('admin/users', [AdminController::class, 'users'], $adminRole);
    $router->get('admin/students', [AdminController::class, 'students'], $adminRole);
    $router->get('admin/teachers', [AdminController::class, 'teachers'], $adminRole);
    $router->post('admin/users/store', [AdminController::class, 'storeUser'], $adminRole);
    $router->post('admin/users/update', [AdminController::class, 'updateUser'], $adminRole);
    $router->post('admin/users/toggle-status', [AdminController::class, 'toggleUserStatus'], $adminRole);
    $router->post('admin/users/delete', [AdminController::class, 'deleteUser'], $adminRole);

    $router->get('admin/courses', [AdminController::class, 'courses'], $adminRole);
    $router->post('admin/courses/store', [AdminController::class, 'storeCourse'], $adminRole);
    $router->post('admin/courses/update', [AdminController::class, 'updateCourse'], $adminRole);
    $router->post('admin/courses/delete', [AdminController::class, 'deleteCourse'], $adminRole);

    $router->get('admin/enrollments', [AdminController::class, 'enrollments'], $adminRole);
    $router->post('admin/enrollments/store', [AdminController::class, 'storeEnrollment'], $adminRole);
    $router->post('admin/enrollments/remove', [AdminController::class, 'removeEnrollment'], $adminRole);

    $router->get('admin/notices', [AdminController::class, 'notices'], $adminRole);
    $router->post('admin/notices/store', [AdminController::class, 'storeNotice'], $adminRole);
    $router->post('admin/notices/update', [AdminController::class, 'updateNotice'], $adminRole);
    $router->post('admin/notices/delete', [AdminController::class, 'deleteNotice'], $adminRole);

    $router->get('admin/reports', [AdminController::class, 'reports'], $adminRole);
    $router->get('admin/activity-logs', [AdminController::class, 'activityLogs'], $adminRole);
    $router->get('admin/settings', [AdminController::class, 'settings'], $adminRole);
    $router->post('admin/settings/update', [AdminController::class, 'updateSettings'], $adminRole);

    // ------------------------------------------------------------------------
    // 2. TEACHER PANEL ROUTES (Strictly TEACHER Role)
    // ------------------------------------------------------------------------
    $teacherRole = ['TEACHER'];
    $router->get('teacher/dashboard', [TeacherController::class, 'dashboard'], $teacherRole);
    $router->get('teacher/courses', [TeacherController::class, 'courses'], $teacherRole);

    $router->get('teacher/materials', [TeacherController::class, 'materials'], $teacherRole);
    $router->post('teacher/materials/store', [TeacherController::class, 'storeMaterial'], $teacherRole);
    $router->post('teacher/materials/update', [TeacherController::class, 'updateMaterial'], $teacherRole);
    $router->post('teacher/materials/delete', [TeacherController::class, 'deleteMaterial'], $teacherRole);

    $router->get('teacher/assignments', [TeacherController::class, 'assignments'], $teacherRole);
    $router->post('teacher/assignments/store', [TeacherController::class, 'storeAssignment'], $teacherRole);
    $router->post('teacher/assignments/update', [TeacherController::class, 'updateAssignment'], $teacherRole);
    $router->post('teacher/assignments/delete', [TeacherController::class, 'deleteAssignment'], $teacherRole);

    $router->get('teacher/submissions', [TeacherController::class, 'submissions'], $teacherRole);
    $router->post('teacher/submissions/evaluate', [TeacherController::class, 'evaluateSubmission'], $teacherRole);

    $router->get('teacher/quizzes', [TeacherController::class, 'quizzes'], $teacherRole);
    $router->post('teacher/quizzes/store', [TeacherController::class, 'storeQuiz'], $teacherRole);
    $router->post('teacher/quizzes/update', [TeacherController::class, 'updateQuiz'], $teacherRole);
    $router->post('teacher/quizzes/delete', [TeacherController::class, 'deleteQuiz'], $teacherRole);

    $router->get('teacher/questions', [TeacherController::class, 'questions'], $teacherRole);
    $router->post('teacher/questions/store', [TeacherController::class, 'storeQuestion'], $teacherRole);
    $router->post('teacher/questions/delete', [TeacherController::class, 'deleteQuestion'], $teacherRole);

    $router->get('teacher/attendance', [TeacherController::class, 'attendance'], $teacherRole);
    $router->post('teacher/attendance/store', [TeacherController::class, 'storeAttendance'], $teacherRole);

    $router->get('teacher/results', [TeacherController::class, 'results'], $teacherRole);
    $router->get('teacher/notices', [TeacherController::class, 'notices'], $teacherRole);
    $router->post('teacher/notices/store', [TeacherController::class, 'storeNotice'], $teacherRole);
    $router->get('teacher/reports', [TeacherController::class, 'reports'], $teacherRole);

    // ------------------------------------------------------------------------
    // 3. STUDENT PANEL ROUTES (Strictly STUDENT Role)
    // ------------------------------------------------------------------------
    $studentRole = ['STUDENT'];
    $router->get('student/dashboard', [StudentController::class, 'dashboard'], $studentRole);
    $router->get('student/courses', [StudentController::class, 'courses'], $studentRole);
    $router->get('student/materials', [StudentController::class, 'materials'], $studentRole);
    $router->get('student/assignments', [StudentController::class, 'assignments'], $studentRole);
    $router->post('student/assignments/submit', [StudentController::class, 'submitAssignment'], $studentRole);
    $router->get('student/submissions', [StudentController::class, 'submissions'], $studentRole);
    $router->get('student/quizzes', [StudentController::class, 'quizzes'], $studentRole);
    $router->get('student/quizzes/take', [StudentController::class, 'startQuiz'], $studentRole);
    $router->post('student/quizzes/submit', [StudentController::class, 'submitQuiz'], $studentRole);
    $router->get('student/quiz-results', [StudentController::class, 'quizResults'], $studentRole);
    $router->get('student/attendance', [StudentController::class, 'attendance'], $studentRole);
    $router->get('student/results', [StudentController::class, 'results'], $studentRole);
    $router->get('student/notices', [StudentController::class, 'notices'], $studentRole);
};
