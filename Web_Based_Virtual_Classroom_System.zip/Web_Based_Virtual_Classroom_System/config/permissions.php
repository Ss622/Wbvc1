<?php
declare(strict_types=1);

/**
 * Role-Based Access Control (RBAC) Permission Matrix
 * Defines permitted route prefixes and capabilities per role.
 */
return [
    'roles' => [
        'ADMIN'   => 1,
        'TEACHER' => 2,
        'STUDENT' => 3,
    ],
    'capabilities' => [
        'ADMIN' => [
            'admin.dashboard',
            'admin.users',
            'admin.students',
            'admin.teachers',
            'admin.courses',
            'admin.enrollments',
            'admin.notices',
            'admin.reports',
            'admin.logs',
            'admin.settings',
            'profile.manage',
            'material.download',
            'submission.download',
        ],
        'TEACHER' => [
            'teacher.dashboard',
            'teacher.courses',
            'teacher.materials',
            'teacher.assignments',
            'teacher.submissions',
            'teacher.quizzes',
            'teacher.questions',
            'teacher.attendance',
            'teacher.results',
            'teacher.notices',
            'teacher.reports',
            'profile.manage',
            'material.download',
            'submission.download',
        ],
        'STUDENT' => [
            'student.dashboard',
            'student.courses',
            'student.materials',
            'student.assignments',
            'student.submissions',
            'student.quizzes',
            'student.quiz_results',
            'student.attendance',
            'student.results',
            'student.notices',
            'profile.manage',
            'material.download',
            'submission.download',
        ],
    ],
];
