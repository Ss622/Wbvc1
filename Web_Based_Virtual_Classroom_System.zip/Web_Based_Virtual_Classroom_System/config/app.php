<?php
declare(strict_types=1);

use App\Core\Env;

return [
    'name'               => Env::get('APP_NAME', 'Web-Based Virtual Classroom System'),
    'short_name'         => Env::get('APP_SHORT_NAME', 'IGNOU Virtual Classroom'),
    'project_code'       => Env::get('APP_CODE', 'BCSP-064'),
    'env'                => Env::get('APP_ENV', 'local'),
    'debug'              => filter_var(Env::get('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOLEAN),
    'url'                => rtrim(Env::get('APP_URL', ''), '/'),
    'timezone'           => Env::get('APP_TIMEZONE', 'Asia/Kolkata'),
    'session_lifetime'   => (int) Env::get('SESSION_LIFETIME', '1800'),
    'session_cookie'     => Env::get('SESSION_COOKIE_NAME', 'vc_session_id'),
    'max_login_attempts' => (int) Env::get('MAX_LOGIN_ATTEMPTS', '5'),
    'lockout_minutes'    => (int) Env::get('LOGIN_LOCKOUT_MINUTES', '15'),
    'max_upload_mb'      => (int) Env::get('MAX_UPLOAD_SIZE_MB', '10'),
    'allowed_extensions' => array_map('trim', explode(',', strtolower(Env::get(
        'ALLOWED_EXTENSIONS',
        'pdf,doc,docx,ppt,pptx,xls,xlsx,txt,jpg,jpeg,png'
    )))),
    'allowed_mimes'      => [
        'pdf'  => ['application/pdf'],
        'doc'  => ['application/msword', 'application/octet-stream'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip'],
        'ppt'  => ['application/vnd.ms-powerpoint', 'application/octet-stream'],
        'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/zip'],
        'xls'  => ['application/vnd.ms-excel', 'application/octet-stream'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip'],
        'txt'  => ['text/plain', 'text/x-Algol68', 'application/octet-stream'],
        'jpg'  => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png'  => ['image/png'],
    ],
];
