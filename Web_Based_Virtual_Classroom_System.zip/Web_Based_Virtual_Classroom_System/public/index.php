<?php
declare(strict_types=1);

/**
 * Web-Based Virtual Classroom System (IGNOU BCA Project: BCSP-064)
 * Front Controller Entry Point (public/index.php)
 */

use App\Core\Autoloader;
use App\Core\Env;
use App\Core\Logger;
use App\Core\Router;
use App\Core\Session;
use App\Core\View;

$rootPath = dirname(__DIR__);

require_once $rootPath . '/app/Core/Autoloader.php';
Autoloader::register();

// Load .env configuration (falls back to .env.example defaults if .env does not exist yet)
$envFile = is_file($rootPath . '/.env') ? ($rootPath . '/.env') : ($rootPath . '/.env.example');
Env::load($envFile);

$appConfig = require $rootPath . '/config/app.php';
date_default_timezone_set($appConfig['timezone'] ?? 'Asia/Kolkata');

// Configure error reporting safely (disable raw error display in production mode)
if (!empty($appConfig['debug'])) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL);
}

// Security response headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

require_once $rootPath . '/app/Helpers/functions.php';

try {
    Session::start();

    $router = new Router();
    $registerRoutes = require $rootPath . '/routes/web.php';
    $registerRoutes($router);
    $router->dispatch();
} catch (\Throwable $e) {
    Logger::error($e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    View::render('errors/500', [
        'pageTitle' => 'Application Error',
        'message'   => !empty($appConfig['debug'])
            ? $e->getMessage()
            : 'An unexpected error occurred while processing your request. Please verify your database connection or contact the administrator.',
    ], 'layouts/auth');
}
