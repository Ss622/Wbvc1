/**
 * Web-Based Virtual Classroom System (IGNOU BCA Project: BCSP-064)
 * Client-Side UI Controller (ES6+)
 */
document.addEventListener('DOMContentLoaded', () => {
    // 1. Mobile Sidebar Toggle
    const menuBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.getElementById('appSidebar');
    if (menuBtn && sidebar) {
        menuBtn.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
    }

    // 2. Show / Hide Password Toggle
    document.querySelectorAll('[data-toggle-password]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const targetId = btn.getAttribute('data-toggle-password');
            const input = document.getElementById(targetId);
            if (!input) return;
            if (input.type === 'password') {
                input.type = 'text';
                btn.textContent = 'Hide';
            } else {
                input.type = 'password';
                btn.textContent = 'Show';
            }
        });
    });

    // 3. Quick Fill Demo Credentials on Login Screen
    document.querySelectorAll('[data-fill-login]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const email = btn.getAttribute('data-email');
            const pass = btn.getAttribute('data-pass');
            const idInput = document.getElementById('identifier');
            const pwInput = document.getElementById('password');
            if (idInput && pwInput) {
                idInput.value = email;
                pwInput.value = pass;
                idInput.focus();
            }
        });
    });

    // 4. Confirmation Dialog for Destructive Operations
    document.querySelectorAll('form[data-confirm]').forEach((form) => {
        form.addEventListener('submit', (e) => {
            const message = form.getAttribute('data-confirm') || 'Are you sure you want to proceed?';
            if (!window.confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // 5. Notice Audience Course Selector Toggle
    const audienceSelect = document.getElementById('noticeAudienceSelect');
    const courseGroup = document.getElementById('noticeCourseGroup');
    if (audienceSelect && courseGroup) {
        const syncCourseVisibility = () => {
            courseGroup.style.display = (audienceSelect.value === 'course') ? 'block' : 'none';
        };
        audienceSelect.addEventListener('change', syncCourseVisibility);
        syncCourseVisibility();
    }

    // 6. Online Quiz Countdown Timer
    const timerDisplay = document.getElementById('quizTimerDisplay');
    const quizForm = document.getElementById('quizAttemptForm');
    if (timerDisplay && quizForm) {
        let remaining = parseInt(timerDisplay.getAttribute('data-remaining-seconds') || '0', 10);
        const formatTime = (secs) => {
            const m = Math.floor(secs / 60);
            const s = secs % 60;
            return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
        };
        timerDisplay.textContent = formatTime(remaining);

        const interval = setInterval(() => {
            remaining -= 1;
            if (remaining <= 0) {
                clearInterval(interval);
                timerDisplay.textContent = '00:00 (Submitting...)';
                quizForm.submit();
            } else {
                timerDisplay.textContent = formatTime(remaining);
                if (remaining <= 60) {
                    timerDisplay.style.color = '#fca5a5';
                }
            }
        }, 1000);
    }
});
