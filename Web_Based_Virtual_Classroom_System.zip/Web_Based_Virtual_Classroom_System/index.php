<?php
declare(strict_types=1);
/**
 * Root Entry Redirector
 * Redirects requests from project root to the public/ front controller
 * so XAMPP users visiting http://localhost/Web_Based_Virtual_Classroom_System/
 * automatically land on the application.
 */
header('Location: public/index.php');
exit;
