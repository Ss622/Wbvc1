# Web-Based Virtual Classroom System (`BCSP-064`)

**Academic Programme:** Bachelor of Computer Applications (BCA)  
**University:** Indira Gandhi National Open University (IGNOU)  
**Course Code:** `BCSP-064` (Final Semester Project)  
**Learner:** Sahil Alam (`Enrolment No.: 2200080265`)  
**Regional Centre:** Patna | **Study Centre:** `0500`  
**Project Guide:** Krishan Dev Mishra (`B.Tech`)  
**Academic Session:** `2026–2027`

---

## 1. Project Introduction
The **Web-Based Virtual Classroom System** is a complete, centralized, role-based educational management and e-learning web application built with **PHP 8.2+ (MVC architecture)** and **MySQL 8.0 / MariaDB (PDO prepared statements)**.

Designed specifically around the approved **IGNOU BCA BCSP-064 Project Proposal**, the platform connects **Administrators**, **Teachers (Academic Counsellors)**, and **Students (Learners)** around a unified relational database. It replaces fragmented spreadsheets, paper registers, and disconnected messaging groups with an integrated workflow:
`Course -> Enrollment -> Learning Material -> Assignment / Quiz / Attendance -> Evaluation -> Consolidated Result & Report`.

---

## 2. Project Objectives
1. Provide secure session-based authentication (`password_hash()` / `password_verify()`) and strict server-side Role-Based Access Control (RBAC).
2. Enable Administrators to manage users, teachers, students, courses, enrollments, notices, institutional settings, and CSV/printable reports.
3. Enable Teachers to manage assigned courses, upload validated learning materials, create assignments, evaluate student submissions, build objective multiple-choice quizzes, manage a reusable question bank, and record date-wise attendance.
4. Enable Students to access enrolled courses, download protected learning materials, submit assignments, take timed online quizzes with automated server-side scoring, monitor attendance percentages, and view published results.
5. Enforce relational database normalization (3NF) with primary keys, foreign keys, unique constraints, and transactional data integrity.

---

## 3. Core Functional Modules & Features
- **Authentication & Security Module:** Login via Email or Enrolment/Staff ID, show/hide password toggle, brute-force rate limiting (`login_attempts`), session regeneration (`session_regenerate_id(true)`), inactivity timeout, and synchronizer CSRF tokens on all POST forms.
- **Administrator Panel:** Live database-driven statistics dashboard, User Management (Add, Edit, Search, Filter, Activate/Deactivate, Delete, Reset Password), Student & Teacher Directories, Course Management (Create, Edit, Publish, Draft, Archive, Assign Teacher), Enrollment Management (`UNIQUE(student_id, course_id)`), Institutional Notice Board, 8 Dynamic Reports with one-click CSV Export & Print view, Audit Activity Logs, and System Settings.
- **Teacher Panel:** Faculty dashboard, Assigned Course Roster, Protected Learning Material Upload & Metadata Management, Assignment Creation & Deadline Management, Student Submission Grading & Mark Publication, Online Objective Quiz Builder, Course Question Bank (MCQ Options A/B/C/D), Date-Wise Attendance Recording (`UNIQUE(course_id, student_id, class_date)`), Course Announcements, and Performance Reports.
- **Student Panel:** Personal Learning Dashboard, Enrolled Course Classroom View, Protected Material Downloads, Assignment Submission (Text + File Attachment with server-side deadline & late validation), Timed Online Quiz Interface with live countdown timer and server-side transactional scoring, Quiz Result & Answer Key Review, Course-Wise Attendance Summary & History, and Printable Academic Grade Card.

---

## 4. Technology Stack
| Layer | Technology |
| :--- | :--- |
| **Frontend** | HTML5, CSS3 (Custom SaaS LMS Design System + Responsive Grid), JavaScript ES6+ |
| **Backend** | PHP 8.2+ (Strict Types, Object-Oriented MVC Architecture, Sessions) |
| **Database** | MySQL 8.0+ / MariaDB 10.4+ via PHP PDO with Prepared Statements |
| **Local Server** | XAMPP (Apache 2.4 + PHP + MySQL/MariaDB + phpMyAdmin) |
| **Browsers** | Google Chrome, Microsoft Edge, Mozilla Firefox |

---

## 5. Project Directory Structure
```text
Web_Based_Virtual_Classroom_System/
├── README.md
├── SECURITY.md
├── LICENSE.txt
├── composer.json
├── .env.example
├── .gitignore
├── index.php                       # Root convenience redirector to public/index.php
├── .htaccess
├── app/
│   ├── Core/                       # Autoloader, Env, Database, Session, Csrf, Router, Controller, View, Auth, Flash, Logger
│   ├── Controllers/                # AuthController, AdminController, TeacherController, StudentController, ProfileController, DownloadController
│   ├── Models/                     # 16 PDO Models (User, Role, Course, Enrollment, Material, Assignment, Submission, Quiz, Question, Attempt, Attendance, Notice, Result, ActivityLog, Setting)
│   ├── Services/                   # QuizScoringService, ResultCalculationService
│   ├── Middleware/                 # AuthMiddleware, RoleMiddleware, CsrfMiddleware
│   ├── Helpers/                    # functions.php, FileUpload.php, CsvExporter.php
│   ├── Validators/                 # Validator.php
│   └── Views/                      # Layouts, Partials, Auth, Profile, Admin, Teacher, Student, Errors
├── config/
│   ├── app.php
│   ├── database.php
│   └── permissions.php
├── public/
│   ├── index.php                   # Application Front Controller
│   ├── .htaccess
│   └── assets/
│       ├── css/style.css
│       ├── js/app.js
│       └── images/logo.svg
├── routes/
│   └── web.php                     # Complete Route & RBAC definitions (71 routes)
├── database/
│   ├── schema.sql                  # Full 18-table relational DDL schema
│   ├── seed.sql                    # Rich demonstration accounts & IGNOU BCA records
│   └── README.md
├── storage/
│   ├── .htaccess                   # Denies direct public web access
│   ├── uploads/                    # Protected storage for materials, assignments, submissions
│   └── logs/                       # Application & error logs
├── tests/
│   ├── run.php                     # Automated CLI test runner
│   ├── unit/UnitTestSuite.php
│   └── integration/WorkflowTestSuite.php
├── docs/
│   ├── PROJECT_DOCUMENTATION.md    # Complete IGNOU BCSP-064 Academic Project Report
│   ├── USER_GUIDE.md               # Step-by-step manual for Admin, Teacher, and Student
│   ├── TEST_REPORT.md              # Executed Test Case Report
│   ├── architecture/               # 11 Editable Mermaid (.mmd) System Diagrams
│   └── screenshots/
└── installation/
    └── INSTALLATION_GUIDE.md
```

---

## 6. System Requirements
- **Operating System:** Windows 10/11, Linux, or macOS
- **Local Server Package:** XAMPP (with Apache 2.4+, PHP 8.1/8.2+, and MySQL 8.0 / MariaDB 10.4+)
- **PHP Extensions (Enabled by default in XAMPP):** `pdo_mysql`, `mbstring`, `fileinfo`, `session`
- **Hardware:** Dual-Core Processor, 4 GB RAM (8 GB recommended), 1366×768 or higher display

---

## 7. Step-by-Step Installation & Startup Guide (XAMPP)

1. **Extract the Archive:**
   Extract `Web_Based_Virtual_Classroom_System.zip` and copy the `Web_Based_Virtual_Classroom_System` folder into your XAMPP `htdocs` directory:
   ```text
   C:\xampp\htdocs\Web_Based_Virtual_Classroom_System
   ```
2. **Start Apache and MySQL:**
   Open the **XAMPP Control Panel** and click **Start** next to both **Apache** and **MySQL**.
3. **Import the Database Schema & Seed Data:**
   - Open your browser and visit `http://localhost/phpmyadmin`.
   - Click the **Import** tab at the top.
   - Click **Choose File**, select `database/schema.sql`, and click **Import** (this automatically creates `virtual_classroom_db` and all 18 tables).
   - Select `virtual_classroom_db` in the left sidebar, click **Import** again, select `database/seed.sql`, and click **Import**.
4. **Configure Database Connection (Optional if using default XAMPP):**
   - By default, the application connects to `127.0.0.1`, port `3306`, database `virtual_classroom_db`, username `root`, and an empty password `""` (standard XAMPP defaults).
   - If your MySQL `root` user has a custom password, copy `.env.example` to `.env` and set `DB_PASSWORD="your_password"`.
5. **Open the Application in Your Browser:**
   Visit either:
   - `http://localhost/Web_Based_Virtual_Classroom_System/public/`
   - or `http://localhost/Web_Based_Virtual_Classroom_System/` (automatically redirects to `public/index.php`)
6. **Sign In:**
   Use any of the demonstration accounts below (or click the **Quick-Fill** buttons directly on the login page).

---

## 8. Demonstration Login Credentials

All demonstration accounts are pre-populated via `database/seed.sql` using genuine PHP `password_hash()` bcrypt hashes:

| Role | Name | Login Email | Enrolment / Staff ID | Password | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Administrator** | Dr. Arvind Narayan | `admin@ignou-vc.edu.in` | `ADM-0500-01` | `Admin@123` | Active |
| **Teacher 1** | Prof. Krishan Dev Mishra | `krishan.mishra@ignou-vc.edu.in` | `FAC-0500-101` | `Teacher@123` | Active |
| **Teacher 2** | Dr. Shalini Verma | `shalini.verma@ignou-vc.edu.in` | `FAC-0500-102` | `Teacher@123` | Active |
| **Teacher 3** | Mr. Rakesh Kumar Sharma | `rakesh.sharma@ignou-vc.edu.in` | `FAC-0500-103` | `Teacher@123` | Active |
| **Student 1** | Sahil Alam | `sahil.alam@ignou-vc.edu.in` | `2200080265` | `Student@123` | Active |
| **Student 2** | Priya Kumari | `priya.kumari@ignou-vc.edu.in` | `2200080266` | `Student@123` | Active |
| **Student 3** | Rohit Kumar Sinha | `rohit.sinha@ignou-vc.edu.in` | `2200080267` | `Student@123` | Active |
| **Student 4** | Ananya Gupta | `ananya.gupta@ignou-vc.edu.in` | `2200080268` | `Student@123` | Active |
| **Student 5** | Vikram Aditya Patel | `vikram.patel@ignou-vc.edu.in` | `2200080269` | `Student@123` | Active |
| **Student 6** | Neha Singh | `neha.singh@ignou-vc.edu.in` | `2200080270` | `Student@123` | Inactive (Demo) |

> **Changing Demonstration Passwords After Installation:**  
> Any user can change their password after signing in via **My Profile & Account Security -> Change Account Password**, or the Administrator can reset any user's password via **User Management -> Edit**.

---

## 9. Troubleshooting Common Issues
- **Apache Port 80 Conflict:** If Apache fails to start in XAMPP, check if IIS or Skype is using port 80, or change Apache's port in `httpd.conf` (e.g., `Listen 8080`) and access `http://localhost:8080/Web_Based_Virtual_Classroom_System/public/`.
- **MySQL Connection Failure:** Verify MySQL is running in XAMPP Control Panel and that `database/schema.sql` was imported into phpMyAdmin.
- **File Upload Permission Errors (Linux/macOS):** Ensure the web server user has write permissions on `storage/uploads/` and `storage/logs/` (`chmod -R 755 storage`).
- **Missing PHP `fileinfo` Extension:** In XAMPP `php.ini`, ensure `extension=fileinfo` and `extension=pdo_mysql` are uncommented (no leading `;`).

---

## 10. Running Automated Tests
Open a terminal or XAMPP Shell in the project root directory and run:
```bash
php tests/run.php
```
See [`docs/TEST_REPORT.md`](docs/TEST_REPORT.md) for the complete verification log.
